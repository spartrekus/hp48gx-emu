/*
 *   display.c
 *
 *   This file is part of Emu48
 *
 *   Copyright (C) 1995 Sebastien Carlier
 *
 */

#include "engine.h"
#include "emu48.h"

void Engine::UpdateContrast(TUint8 byContrast)
{
#if 0
	TUint32 c = byContrast;
	TUint32 b = byContrast + 0x20;

	if (nLcdDoubled == 1)
	{
		TUint16 i,j;
		for (i=0; i<16; ++i)
		{
			Pattern[i] = 0;
			for (j=8; j>0; j>>=1)
			{
				Pattern[i] = (Pattern[i] << 8) | ((i&j) ? c : b);
			}
		}
	}

	c = (c<<8) | c;
	b = (b<<8) | b;

	if (nLcdDoubled == 2)
	{
		Pattern[0] = (b<<16)|b;
		Pattern[1] = (b<<16)|c;
		Pattern[2] = (c<<16)|b;
		Pattern[3] = (c<<16)|c;
	}

	c = (c<<16) | c;
	b = (b<<16) | b;

	if (nLcdDoubled == 4)
	{
		Pattern[0] = b;
		Pattern[1] = c;
	}
#endif

	if(nLcdDoubled == 1)
	{
		//if(DEBUG) fileLogs.Write(_L8("UpdateContrast 1 Pattern2.\n"));
		Pattern2[0] = 0xFFFFFFFF;
		Pattern2[1] = 0xFFFFFF00;
		Pattern2[2] = 0xFFFF00FF;
		Pattern2[3] = 0xFFFF0000;
		Pattern2[4] = 0xFF00FFFF;
		Pattern2[5] = 0xFF00FF00;
		Pattern2[6] = 0xFF0000FF;
		Pattern2[7] = 0xFF000000;
		Pattern2[8] = 0x00FFFFFF;
		Pattern2[9] = 0x00FFFF00;
		Pattern2[10] = 0x00FF00FF;
		Pattern2[11] = 0x00FF0000;
		Pattern2[12] = 0x0000FFFF;
		Pattern2[13] = 0x0000FF00;
		Pattern2[14] = 0x000000FF;
		Pattern2[15] = 0x00000000;
	}
	else
	{
		//if(DEBUG) fileLogs.Write(_L8("UpdateContrast 2 Pattern2.\n"));
		Pattern2[0] = 0xFFFFFFFF;
		Pattern2[1] = 0xFFFF0000;
		Pattern2[2] = 0x0000FFFF;
		Pattern2[3] = 0x00000000;
		Pattern2[4] = 0xFF00FFFF;
		Pattern2[5] = 0xFF00FF00;
		Pattern2[6] = 0xFF0000FF;
		Pattern2[7] = 0xFF000000;
		Pattern2[8] = 0x00FFFFFF;
		Pattern2[9] = 0x00FFFF00;
		Pattern2[10] = 0x00FF00FF;
		Pattern2[11] = 0x00FF0000;
		Pattern2[12] = 0x0000FFFF;
		Pattern2[13] = 0x0000FF00;
		Pattern2[14] = 0x000000FF;
		Pattern2[15] = 0x00000000;
	}
	if(nLcdDoubled == 1)
	{
		//if(DEBUG) fileLogs.Write(_L8("UpdateContrast 1 Pattern.\n"));
		Pattern[0] = 0xFFFF;
		Pattern[1] = 0xFFF0;
		Pattern[2] = 0xFF0F;
		Pattern[3] = 0xFF00;
		Pattern[4] = 0xF0FF;
		Pattern[5] = 0xF0F0;
		Pattern[6] = 0xF00F;
		Pattern[7] = 0xF000;
		Pattern[8] = 0x0FFF;
		Pattern[9] = 0x0FF0;
		Pattern[10] = 0x0F0F;
		Pattern[11] = 0x0F00;
		Pattern[12] = 0x00FF;
		Pattern[13] = 0x00F0;
		Pattern[14] = 0x000F;
		Pattern[15] = 0x0000;
	}
	else
	{
		//if(DEBUG) fileLogs.Write(_L8("UpdateContrast 2 Pattern.\n"));
		Pattern[0] = 0xFFFF;
		Pattern[1] = 0xFF00;
		Pattern[2] = 0x00FF;
		Pattern[3] = 0x0000;
		Pattern[4] = 0xF0FF;
		Pattern[5] = 0xF0F0;
		Pattern[6] = 0xF00F;
		Pattern[7] = 0xF000;
		Pattern[8] = 0x0FFF;
		Pattern[9] = 0x0FF0;
		Pattern[10] = 0x0F0F;
		Pattern[11] = 0x0F00;
		Pattern[12] = 0x00FF;
		Pattern[13] = 0x00F0;
		Pattern[14] = 0x000F;
		Pattern[15] = 0x0000;
	}
	//if(DEBUG) fileLogs.Write(_L8("UpdateContrast Ok.\n"));
	return;
}

void Engine::UpdateDisplayPointers()
{
	// 09.09.98 cg, bugfix, calculate display width

	Chipset.width = (34 + Chipset.loffset + (Chipset.boffset / 4) * 2) & 0xFFFFFFFE;
	Chipset.end1 = Chipset.start1 + (Chipset.lcounter + 1) * Chipset.width;
	if (Chipset.end1 < Chipset.start1)
	{
		// 09.09.98 cg, bugfix, calculate first address of main display
		Chipset.start12 = Chipset.end1 - Chipset.width;

		// 09.09.98 cg, bugfix, calculate last address of main display
		Chipset.end1 = Chipset.start1 - Chipset.width;
	}
	else
	{
		Chipset.start12 = Chipset.start1;
	}
	Chipset.end2 = Chipset.start2 + (63 - Chipset.lcounter) * 34;
}


void Engine::UpdateMainDisplay(TBool Update)
{
	TUint x, y;
	TUint32 nLines;
	TUint32 d = Chipset.start1;
	TUint8 *p;
	TUint8 *p0;
	TUint32 val32;
	TUint16 val16;

	//if(DEBUG) fileLogs.Write(_L8("UpdateMainDisplay.\n"));

	if(RedrawMode == 3) // avec FrameBuffer
	{
		p = FBLcd;
#if 0
		if(DispMode == 2) // testNetbook
		{
			hLcdBitmapUtil2->Begin(TPoint(0,0));
			FBAdr=(TUint8*)(hLcdBitmap2->DataAddress());
			FBLcd = FBAdr + (iView->MainY + iView->LcdY0)*nFBX + iView->MainX + iView->LcdX0;
			p = FBLcd;
		}
#endif
	}
	else
	{
		hLcdBitmapUtil->Begin(TPoint(0,0));
		pbyLcd=(TUint8*)(hLcdBitmap->DataAddress());
		p = pbyLcd;
	}


	if (!Chipset.dispon)
	{
		//if(DEBUG) fileLogs.Write(_L8("   UpdateMainDisplay !Chipset.dispon.\n"));
		nLines = 64;
		if (!bScreenIsClean)
		{
			bScreenIsClean = ETrue;

			if(RedrawMode == 3 && FBAffiche && Focus) // avec FrameBuffer
			{
				nLines = 64*nLcdDoubled;
				if(DispMode == 2) // 8bpp
				{
					for (y=0; y < nLines; y++)
					{
						Mem::Fill(p, 131 * nLcdDoubled, 0xff);
						p += nFBX;
					}
				}
				else // 4bpp
				{
					for (y=0; y<nLines; y++)
					{
						Mem::Fill(p, 65 * nLcdDoubled, 0xff);
						*(p+65)=( (*(p+65))&0xf0) | 0x0f;
						p += n2FBX;
					}
				}
			}
			if(RedrawMode == 1 || RedrawMode == 2) // avec Bitmap
			{
				if(DispMode == 2) Mem::Fill(pbyLcd, 144 * nLcdDoubled * nLines * nLcdDoubled, 0xff);
				else Mem::Fill(pbyLcd, 72 * nLcdDoubled * nLines * nLcdDoubled, 0xff);

			}
			//if(DEBUG) fileLogs.Write(_L8("   UpdateMainDisplay !bScreenIsClean Ok.\n"));
		}
		nLines = 64;
	}
	else
	{
		nLines = Chipset.lcounter + 1;
		bScreenIsClean = EFalse;
		if (nLcdDoubled == 2)				// 24.08.98 cg, new var type
		{
			if(RedrawMode == 3 && FBAffiche && Focus) // avec FrameBuffer
			{
				if(DispMode == 2) // 8bpp
				{
					//if(DEBUG) fileLogs.Write(_L8("UMDisp 2 mode 3 8bpp.\n"));
					for (y=0; y<=Chipset.lcounter; y++)
					{
						p0 = p;
						Npeek(Buf,d,36);
						for (x=0; x<32; x++)
						{
							// *((TUint32*)p)=Pattern2[Buf[x]&3]; // Arm Word Alignment !!!
							val32 = Pattern2[Buf[x]&3];
							Mem::Copy(p,&val32,4);
							p+=4;

							// *((TUint32*)p)=Pattern2[Buf[x]>>2];
							val32 = Pattern2[Buf[x]>>2];
							Mem::Copy(p,&val32,4);
							p+=4;
						}
						// *((TUint32*)p)=Pattern2[Buf[32]&3];
						val32 = Pattern2[Buf[32]&3];
						Mem::Copy(p,&val32,4);
						p+=4;

						// *((TUint16*)p)=(TUint16)Pattern2[Buf[32]>>2];
						val32 = Pattern2[Buf[32]>>2];
						Mem::Copy(p,&val32,2);

						d+=Chipset.width;
						Mem::Copy(p0+nFBX, p0, 262);
						//p+=LCD2_ROW;
						p = p0 + (nFBX<<1);
					}
					//if(DEBUG) fileLogs.Write(_L8("UMDisp3 8bpp ok.\n"));
				}
				else // 4bpp
				{
					//if(DEBUG) fileLogs.Write(_L8("UMDisp mode 3 4bpp.\n"));
					for (y=0; y<=Chipset.lcounter; y++)
					{
						p0 = p;
						Npeek(Buf,d,36);
						for (x=0; x<32; x++)
						{
							// *((TUint16*)p)=Pattern[Buf[x]&3];
							val16 = Pattern[Buf[x]&3];
							Mem::Copy(p,&val16,2);
							p+=2;

							// *((TUint16*)p)=Pattern[Buf[x]>>2];
							val16 = Pattern[Buf[x]>>2];
							Mem::Copy(p,&val16,2);
							p+=2;
						}
						// *((TUint16*)p)=Pattern[Buf[32]&3];
						val16 = Pattern[Buf[32]&3];
						Mem::Copy(p,&val16,2);
						p+=2;

						// *p=(TUint8)Pattern[Buf[32]>>2];
						val16 = Pattern[Buf[32]>>2];
						Mem::Copy(p,&val16,1);

						Mem::Copy(p0+n2FBX, p0, 131);
						d+=Chipset.width;
						p = p0 + nFBX;
					}
				}
			}
			if(RedrawMode == 1 || RedrawMode == 2) // avec Bitmap
			{
				if(DispMode == 2) // 8bpp
				{
					//if(DEBUG) fileLogs.Write(_L8("UMDisp mode 12 8bpp.\n"));
					for (y=0; y<=Chipset.lcounter; y++)
					{
						Npeek(Buf,d,36);
						for (x=0; x<36; x++)
						{
							// *((TUint32*)p)=Pattern2[Buf[x]&3];
							val32 = Pattern2[Buf[x]&3];
							Mem::Copy(p,&val32,4);
							p+=4;

							// *((TUint32*)p)=Pattern2[Buf[x]>>2];
							val32 = Pattern2[Buf[x]>>2];
							Mem::Copy(p,&val32,4);
							p+=4;
						}
						Mem::Copy(p, p-LCD2_ROW, LCD2_ROW);
						p+=LCD2_ROW;
						d+=Chipset.width;
					}
				}
				else // 4bpp
				{
					//if(DEBUG) fileLogs.Write(_L8("UMDisp mode 12 4bpp.\n"));
					for (y=0; y<=Chipset.lcounter; y++)
					{
						Npeek(Buf,d,36);
						for (x=0; x<36; x++)
						{
							// *((TUint16*)p)=Pattern[Buf[x]&3];
							val16 = Pattern[Buf[x]&3];
							Mem::Copy(p,&val16,2);
							p+=2;

							// *((TUint16*)p)=Pattern[Buf[x]>>2];
							val16 = Pattern[Buf[x]>>2];
							Mem::Copy(p,&val16,2);
							p+=2;
						}
						Mem::Copy(p, p-LCD1_ROW, LCD1_ROW);
							p+=LCD1_ROW;
						d+=Chipset.width;
					}
				}
			}
		}
		if (nLcdDoubled == 1)				// 24.08.98 cg, new var type
		{
			if(RedrawMode == 3 && FBAffiche && Focus) // avec FrameBuffer
			{
				if(DispMode == 2) // 8bpp
				{
					//if(DEBUG) fileLogs.Write(_L8("UMDisp 1 mode 3 8bpp.\n"));
					for (y=0; y<=Chipset.lcounter; y++)
					{
						p0 = p;
						Npeek(Buf,d,36);
						for (x=0; x<32; x++)
						{
							// *((TUint32*)p)=Pattern2[Buf[x]];
							val32 = Pattern2[Buf[x]];
							Mem::Copy(p,&val32,4);
							p+=4;
						}
						// *((TUint16*)p)=(TUint16)Pattern2[Buf[32]];
						val32 = Pattern2[Buf[32]];
						Mem::Copy(p,&val32,2);
						p+=2;

						// *p=(TUint8)(Pattern2[Buf[32]] >> 16);
						val32 = (Pattern2[Buf[32]] >> 16);
						Mem::Copy(p,&val32,1);

						d+=Chipset.width;
						p = p0 + nFBX;
					}
					//if(DEBUG) fileLogs.Write(_L8("UMDisp3 8bpp ok.\n"));
				}
				else // 4bpp
				{

					//if(DEBUG) fileLogs.Write(_L8("UMDisp mode 3 4bpp.\n"));
					for (y=0; y<=Chipset.lcounter; y++)
					{
						p0 = p;
						Npeek(Buf,d,36);
						for (x=0; x<32; x++)
						{
							// *((TUint16*)p)=Pattern[Buf[x]];
							val16 = Pattern[Buf[x]];
							Mem::Copy(p,&val16,2);
							p+=2;
						}
						// *((TUint16*)p)=((*((TUint16*)p))&0xf000) | (Pattern[Buf[32]]&0x0fff);
						Mem::Copy(&val16,p,2);
						val16 = (val16 & 0xf000) | (Pattern[Buf[32]]&0x0fff);
						Mem::Copy(p,&val16,2);

						d+=Chipset.width;
						p = p0 + n2FBX;
					}
				}
			}
			if(RedrawMode == 1 || RedrawMode == 2) // avec Bitmap
			{
				if(DispMode == 2) // 8bpp
				{
					//if(DEBUG) fileLogs.Write(_L8("UMDisp mode 12 8bpp.\n"));
					for (y=0; y<=Chipset.lcounter; y++)
					{
						Npeek(Buf,d,36);
						for (x=0; x<36; x++)
						{
							// *((TUint32*)p)=Pattern2[Buf[x]];
							val32 = Pattern2[Buf[x]];
							Mem::Copy(p,&val32,4);
							p+=4;
						}
						d+=Chipset.width;
					}
				}
				else
				{
					//if(DEBUG) fileLogs.Write(_L8("UMDisp mode 12 4bpp.\n"));
					for (y=0; y<=Chipset.lcounter; y++)
					{
						Npeek(Buf,d,36);
						for (x=0; x<36; x++)
						{
							// *((TUint16*)p)=Pattern[Buf[x]];
							val16 = Pattern[Buf[x]];
							Mem::Copy(p,&val16,2);
							p+=2;
						}
						d+=Chipset.width;
					}
				}
			}
		}
	}
	if(RedrawMode != 3)
	{
		hLcdBitmapUtil->End();
		if(RedrawMode == 2 && Update) iView->UpdateWindow(hLcdBitmap,0,0,nLcdX,nLines*nLcdDoubled,0,0);
		if(RedrawMode == 1 && Update) iView->UpdateWindow(hLcdBitmap,0,0,131*nLcdDoubled,nLines*nLcdDoubled,Chipset.boffset*nLcdDoubled,0);
	}
	//if(DEBUG) fileLogs.Write(_L8("UpdateMainDisplay Ok.\n"));
	return;
}


void Engine::UpdateMenuDisplay(TBool Update)
{
	TUint x, y;
	TUint8 *p;
	TUint8 *p0;
	TUint32 d = Chipset.start2;
	TUint32 val32;
	TUint16 val16;

	//if(DEBUG) fileLogs.Write(_L8("UpdateMenuDisplay.\n"));


	if (!Chipset.dispon) return;
	if (Chipset.lcounter==0x3F) return;		// menu disabled

	if(RedrawMode == 3) // avec FrameBuffer
	{
		if(DispMode == 2) // 8bpp
		{
			p = FBLcd + (Chipset.lcounter+1)*nFBX*nLcdDoubled;
		}
		else
		{
			p = FBLcd + (Chipset.lcounter+1)*n2FBX*nLcdDoubled;
		}
	}
	else
	{
		hLcdBitmapUtil->Begin(TPoint(0,0));
		pbyLcd=(TUint8*)(hLcdBitmap->DataAddress());
		if(DispMode == 2) // 8bpp
		{
			p = pbyLcd + ((Chipset.lcounter+1)*nLcdDoubled*144*nLcdDoubled);
		}
		else // 4bpp
		{
			p = pbyLcd + ((Chipset.lcounter+1)*nLcdDoubled*72*nLcdDoubled);
		}
	}

	if (nLcdDoubled == 2)					// 24.08.98 cg, new var type
	{
		if(RedrawMode == 3 && FBAffiche && Focus) // avec FrameBuffer
		{
			if(DispMode == 2) // 8bpp
			{
				//if(DEBUG) fileLogs.Write(_L8("UMenuDisp mode 3 8bpp.\n"));
				for (y=Chipset.lcounter+1; y<64; y++)
				{
					p0 = p;
					Npeek(Buf,d,34);				// 01.02.99 cg, only 34 nibbles are viewed
					for (x=0; x<32; x++)
					{
						// *((TUint32*)p)=Pattern2[Buf[x]&3];
						val32 = Pattern2[Buf[x]&3];
						Mem::Copy(p,&val32,4);
						p+=4;

						// *((TUint32*)p)=Pattern2[Buf[x]>>2];
						val32 = Pattern2[Buf[x]>>2];
						Mem::Copy(p,&val32,4);
						p+=4;
					}
					// *((TUint32*)p)=Pattern2[Buf[32]&3];
					val32 = Pattern2[Buf[32]&3];
					Mem::Copy(p,&val32,4);
					p+=4;

					// *((TUint16*)p)=(TUint16)Pattern2[Buf[32]>>2];
					val32 = Pattern2[Buf[32]>>2];
					Mem::Copy(p,&val32,2);

					//Mem::Copy(p, p-LCD2_ROW, LCD2_ROW);
					Mem::Copy(p0+nFBX, p0, 262);
					//p+=LCD2_ROW;
					p = p0 + (nFBX<<1);
					d+=34;
				}
			}
			else // 4bpp
			{
				//if(DEBUG) fileLogs.Write(_L8("UMenuDisp mode 3 4bpp.\n"));
				for (y=Chipset.lcounter+1; y<64; y++)
				{
					p0 = p;
					Npeek(Buf,d,34);
					for (x=0; x<32; x++)
					{
						// *((TUint16*)p)=Pattern[Buf[x]&3];
						val16 = Pattern[Buf[x]&3];
						Mem::Copy(p,&val16,2);
						p+=2;

						// *((TUint16*)p)=Pattern[Buf[x]>>2];
						val16 = Pattern[Buf[x]>>2];
						Mem::Copy(p,&val16,2);
						p+=2;
					}
					// *((TUint16*)p)=Pattern[Buf[32]&3];
					val16 = Pattern[Buf[32]&3];
					Mem::Copy(p,&val16,2);
					p+=2;

					// *p=(TUint8)Pattern[Buf[32]>>2];
					val16 = Pattern[Buf[32]>>2];
					Mem::Copy(p,&val16,1);

					Mem::Copy(p0+n2FBX, p0, 131);
					d+=34;
					p = p0 + nFBX;
				}
			}
		}
		if(RedrawMode == 1 || RedrawMode == 2) // avec Bitmap
		{
			if(DispMode == 2) // 8bpp
			{
				//if(DEBUG) fileLogs.Write(_L8("UMenuDisp mode 12 8bpp.\n"));
				for (y=Chipset.lcounter+1; y<64; y++)
				{
					Npeek(Buf,d,34);				// 01.02.99 cg, only 34 nibbles are viewed
					for (x=0; x<36; x++)
					{
						// *((TUint32*)p)=Pattern2[Buf[x]&3];
						val32 = Pattern2[Buf[x]&3];
						Mem::Copy(p,&val32,4);
						p+=4;

						// *((TUint32*)p)=Pattern2[Buf[x]>>2];
						val32 = Pattern2[Buf[x]>>2];
						Mem::Copy(p,&val32,4);
						p+=4;
					}
					Mem::Copy(p, p-LCD2_ROW, LCD2_ROW);
					p+=LCD2_ROW;
					d+=34;
				}
			}
			else // 4bpp
			{
				//if(DEBUG) fileLogs.Write(_L8("UMenuDisp mode 12 4bpp.\n"));
				for (y=Chipset.lcounter+1; y<64; y++)
				{
					Npeek(Buf,d,34);				// 01.02.99 cg, only 34 nibbles are viewed
					for (x=0; x<36; x++)
					{
						// *((TUint16*)p)=Pattern[Buf[x]&3];
						val16 = Pattern[Buf[x]&3];
						Mem::Copy(p,&val16,2);
						p+=2;

						// *((TUint16*)p)=Pattern[Buf[x]>>2];
						val16 = Pattern[Buf[x]>>2];
						Mem::Copy(p,&val16,2);
						p+=2;
					}
					Mem::Copy(p, p-LCD1_ROW, LCD1_ROW);
					p+=LCD1_ROW;
					d+=34;
				}
			}
		}
	}
	
	if (nLcdDoubled == 1)					// 24.08.98 cg, new var type
	{
		if(RedrawMode == 3 && FBAffiche && Focus) // avec FrameBuffer
		{
			if(DispMode == 2) // 8bpp
			{
				//if(DEBUG) fileLogs.Write(_L8("UMenuDisp mode 3 8bpp.\n"));
				for (y=Chipset.lcounter+1; y<64; y++)
				{
					p0 = p;
					Npeek(Buf,d,34);				// 01.02.99 cg, only 34 nibbles are viewed
					for (x=0; x<32; x++) 
					{
						// *((TUint32*)p)=Pattern2[Buf[x]];
						val32 = Pattern2[Buf[x]];
						Mem::Copy(p,&val32,4);
						p+=4;
					}
					// *((TUint16*)p)=(TUint16)Pattern2[Buf[32]];
					val32 = Pattern2[Buf[32]];
					Mem::Copy(p,&val32,2);
					p+=2;

					// *p=(TUint8)(Pattern2[Buf[32]] >> 16);
					val32 = Pattern2[Buf[32]] >> 16;
					Mem::Copy(p,&val32,1);

					d+=34;
					p = p0 + nFBX;
				}
			}
			else // 4bpp
			{
				//if(DEBUG) fileLogs.Write(_L8("UMenuDisp mode 3 4bpp.\n"));
				for (y=Chipset.lcounter+1; y<64; y++)
				{
					p0 = p;
					Npeek(Buf,d,34);
					for (x=0; x<32; x++)
					{
						// *((TUint16*)p)=Pattern[Buf[x]];
						val16 = Pattern[Buf[x]];
						Mem::Copy(p,&val16,2);
						p+=2;
					}
					// *((TUint16*)p)=((*((TUint16*)p))&0xf000) | (Pattern[Buf[32]]&0x0fff);
					Mem::Copy(&val16,p,2);
					val16 = (val16 & 0xf000) | (Pattern[Buf[32]]&0x0fff);
					Mem::Copy(p,&val16,2);

					d+=34;
					p = p0 + n2FBX;
				}
			}
		}
		if(RedrawMode == 1 || RedrawMode == 2) // avec Bitmap
		{
			if(DispMode == 2) // 8bpp
			{
				//if(DEBUG) fileLogs.Write(_L8("UMenuDisp mode 12 8bpp.\n"));
				for (y=Chipset.lcounter+1; y<64; y++)
				{
					Npeek(Buf,d,34);				// 01.02.99 cg, only 34 nibbles are viewed
					for (x=0; x<36; x++) 
					{
						// *((TUint32*)p)=Pattern2[Buf[x]];
						val32 = Pattern2[Buf[x]];
						Mem::Copy(p,&val32,4);
						p+=4;
					}
					d+=34;
				}
			}
			else // 4bpp
			{
				//if(DEBUG) fileLogs.Write(_L8("UMenuDisp mode 12 4bpp.\n"));
				for (y=Chipset.lcounter+1; y<64; y++)
				{
					Npeek(Buf,d,34);				// 01.02.99 cg, only 34 nibbles are viewed
					for (x=0; x<36; x++) 
					{
						// *((TUint16*)p)=Pattern[Buf[x]];
						val16 = Pattern[Buf[x]];
						Mem::Copy(p,&val16,2);
						p+=2;
					}
					d+=34;
				}
			}
		}
	}

	if(RedrawMode != 3)
	{
		hLcdBitmapUtil->End();
		if(Update) iView->UpdateWindow(hLcdBitmap,0,(Chipset.lcounter+1)*nLcdDoubled,131*nLcdDoubled,(63-Chipset.lcounter)*nLcdDoubled,0,(Chipset.lcounter+1)*nLcdDoubled);
	}
	//if(DEBUG) fileLogs.Write(_L8("UpdateMenuDisplay Ok.\n"));
	return;

}

void Engine::WriteToMainDisplay(TUint8* a, TUint32 d, TUint s)
{
	// 09.09.98 cg, new bugfixed implementation

	// 09.03.99 cg, removed calculated corresponding source memory address

	TInt    x0, x;
	TInt    y0, y;
	TUint8  *p;
	TUint32 val32;
	TUint16 val16;

	//if(DEBUG) fileLogs.Write(_L8("WTMD.\n"));

	TInt lWidth = Abs(Chipset.width);		// display width

	d -= Chipset.start1;					// nibble offset to DISPADDR (start of display)
	d += 64 * lWidth;						// make positive offset
	y0 = Abs((TInt) d / lWidth - 64);		// bitmap row
	x0 = (TInt) d % lWidth;					// bitmap coloumn
	y = y0; x = x0;							// load loop variables

	if(RedrawMode == 3 && FBAffiche && Focus) // avec FrameBuffer
	{
		if(DispMode == 2) // 8bpp
		{
			//if(DEBUG) fileLogs.Write(_L8("WTMD 3 8bpp.\n"));
			// calculate memory position in LCD bitmap
			p = (FBLcd + y0*nFBX*nLcdDoubled + x0*4*nLcdDoubled);
			while (s--)								// loop for nibbles to write
			{
				if (x<32)							// only fill visible area
				{
					if (nLcdDoubled == 2)
					{
						// p2[n4FBX] = p2[0] = Pattern2[(*a)&3];
						val32 = Pattern2[(*a)&3];
						Mem::Copy(p,&val32,4);
						Mem::Copy(p+nFBX,&val32,4);

						// p2[n4FBX+1] = p2[1] = Pattern2[(*a)>>2];
						val32 = Pattern2[(*a)>>2];
						Mem::Copy(p+4,&val32,4);
						Mem::Copy(p+nFBX+4,&val32,4);
					}
					if (nLcdDoubled == 1)
					{
						// *p2 = Pattern2[*a];
						val32 = Pattern2[*a];
						Mem::Copy(p,&val32,4);
					}
				}
				if(x == 32)
				{
					if (nLcdDoubled == 2)
					{
						// p2[n4FBX] = p2[0] = Pattern2[(*a)&3];
						val32 = Pattern2[(*a)&3];
						Mem::Copy(p,&val32,4);
						Mem::Copy(p+nFBX,&val32,4);

						// *(((TUint16*)p2)+n2FBX+2) = *(((TUint16*)p2)+2) = (TUint16)Pattern2[(*a)>>2];
						val32 = Pattern2[(*a)>>2];
						Mem::Copy(p+4,&val32,2);
						Mem::Copy(p+nFBX+4,&val32,2);
					}
					if (nLcdDoubled == 1)
					{
						// *((TUint16*)p2) = (TUint16)Pattern2[*a];
						val32 = Pattern2[*a];
						Mem::Copy(p,&val32,2);

						// *(((TUint8*)p2)+2) = (TUint8)(Pattern2[*a] >> 16);
						val32 = Pattern2[*a] >> 16;
						Mem::Copy(p+2,&val32,1);
					}
				}
				++a;								// next value to write
				++x;								// next x position
				if ((x==lWidth)&&s)					// end of display line
				{
					//if(DEBUG) fileLogs.Write(_L8("end\n"));
					// end of main display area
					if (y == (TInt) Chipset.lcounter) break;

					x = 0;							// first coloumn
					++y;							// next row
					// recalculate bitmap memory position of new line
					p = (FBLcd + y*nFBX*nLcdDoubled);
				}
				else 
					p += nLcdDoubled * 4;				// next x position in bitmap
			}
		}
		else // 4bpp
		{
			//if(DEBUG) fileLogs.Write(_L8("WTMD 3 4bpp.\n"));
			if (nLcdDoubled == 2)
			{
				p = (FBLcd + y0*nFBX + (x0<<2));
				while (s--)								// loop for nibbles to write
				{
					if (x<32)							// only fill visible area
					{
						// p[n4FBX] = p[0] = Pattern[(*a)&3];
						val16 = Pattern[(*a)&3];
						Mem::Copy(p,&val16,2);
						Mem::Copy(p+n2FBX,&val16,2);

						// p[n4FBX+1] = p[1] = Pattern[(*a)>>2];
						val16 = Pattern[(*a)>>2];
						Mem::Copy(p+2,&val16,2);
						Mem::Copy(p+n2FBX+2,&val16,2);
					}
					if (x==32)
					{
						// p[n4FBX] = p[0] = Pattern[(*a)&3];
						val16 = Pattern[(*a)&3];
						Mem::Copy(p,&val16,2);
						Mem::Copy(p+n2FBX,&val16,2);

						// *((TUint8*)p+n2FBX+2) = *((TUint8*)p+2) = (TUint8)Pattern[(*a)>>2];
						val16 = Pattern[(*a)>>2];
						Mem::Copy(p+2,&val16,1);
						Mem::Copy(p+n2FBX+2,&val16,1);
					}
					++a;								// next value to write
					++x;								// next x position
					if ((x==lWidth)&&s)					// end of display line
					{
						// end of main display area
						if (y == (TInt) Chipset.lcounter) break;
	
						x = 0;							// first coloumn
						++y;							// next row
						// recalculate bitmap memory position of new line
						p = (FBLcd + y*nFBX);
					}
					else 
						p += 4;				// next x position in bitmap
				}
			}
			if (nLcdDoubled == 1)
			{
				p = (FBLcd + y0*(n2FBX) + (x0<<1));
				while (s--)								// loop for nibbles to write
				{

					if (x<32)
					{
						// *p = Pattern[*a];
						val16 = Pattern[*a];
						Mem::Copy(p,&val16,2);
					}
					if (x==32)
					{
						*p=((*p)&0xf000) | (Pattern[*a]&0x0fff);
						Mem::Copy(&val16,p,2);
						val16 = (val16 & 0xf000) | (Pattern[*a]&0x0fff);
						Mem::Copy(p,&val16,2);
					}
					++a;								// next value to write
					++x;								// next x position
					if ((x==lWidth)&&s)					// end of display line
					{
						// end of main display area
						if (y == (TInt) Chipset.lcounter) break;
	
						x = 0;							// first coloumn
						++y;							// next row
						// recalculate bitmap memory position of new line
						p = (FBLcd + y*(n2FBX));
					}
					else p+=2;
				}

			}
		}
	}
	if(RedrawMode == 1) // Bitmap reel
	{
		hLcdBitmapUtil->Begin(TPoint(0,0));
		pbyLcd=(TUint8*)(hLcdBitmap->DataAddress());
		if(DispMode == 2) // 8bpp
		{
			//if(DEBUG) fileLogs.Write(_L8("WTMD 1 8bpp.\n"));
			// calculate memory position in LCD bitmap
			p = (pbyLcd + y0*144*nLcdDoubled*nLcdDoubled + x0*4*nLcdDoubled);
			while (s--)								// loop for nibbles to write
			{
				if (x<36)							// only fill visible area
				{
					if (nLcdDoubled == 2)
					{
						// p2[72] = p2[0] = Pattern2[(*a)&3];
						val32 = Pattern2[(*a)&3];
						Mem::Copy(p,&val32,4);
						Mem::Copy(p+288,&val32,4);

						// p2[73] = p2[1] = Pattern2[(*a)>>2];
						val32 = Pattern2[(*a)>>2];
						Mem::Copy(p+4,&val32,4);
						Mem::Copy(p+288+4,&val32,4);
					}
					if (nLcdDoubled == 1)
					{
						// *p2 = Pattern2[*a];
						val32 = Pattern2[*a];
						Mem::Copy(p,&val32,4);
					}
				}
				++a;								// next value to write
				++x;								// next x position
				if ((x==lWidth)&&s)					// end of display line
				{
					// end of main display area
					if (y == (TInt) Chipset.lcounter) break;

					x = 0;							// first coloumn
					++y;							// next row
					// recalculate bitmap memory position of new line
					p = (pbyLcd+y*144*nLcdDoubled*nLcdDoubled);
				}
				else 
					p += nLcdDoubled * 4;				// next x position in bitmap
			}
		}
		else // 4bpp
		{
			p = (pbyLcd + y0*72*nLcdDoubled*nLcdDoubled + x0*2*nLcdDoubled);
			while (s--)								// loop for nibbles to write
			{
				if (x<36)							// only fill visible area
				{
					if (nLcdDoubled == 2)
					{
						// p[72] = p[0] = Pattern[(*a)&3];
						val16 = Pattern[(*a)&3];
						Mem::Copy(p,&val16,2);
						Mem::Copy(p+144,&val16,2);

						// p[73] = p[1] = Pattern[(*a)>>2];
						val16 = Pattern[(*a)>>2];
						Mem::Copy(p+2,&val16,2);
						Mem::Copy(p+144+2,&val16,2);
					}
					if (nLcdDoubled == 1)
					{
						// *p = Pattern[*a];
						val16 = Pattern[*a];
						Mem::Copy(p,&val16,2);
					}
				}
				++a;								// next value to write
				++x;								// next x position
				if ((x==lWidth)&&s)					// end of display line
				{
					// end of main display area
					if (y == (TInt) Chipset.lcounter) break;
						x = 0;							// first coloumn
					++y;							// next row
					// recalculate bitmap memory position of new line
					p = (pbyLcd+y*72*nLcdDoubled*nLcdDoubled);
				}
				else 
					p += nLcdDoubled*2;				// next x position in bitmap
			}
		}

		// update window region
		if (y0 != y)							// changed more than one line
		{
			x0 = 0;								// no x-position offset
			x  = 131;							// redraw complete lines
	
			++y;								// redraw this line as well
		}
		else
	
		{
			x0 <<= 2; x <<= 2;					// x-position in pixel
			x -= x0;							// number of pixels to update
	
			x0 -= Chipset.boffset;				// adjust x-position with left margin
			if (x0 < 0) x0 = 0;
					
			if (x0   > 131) x0 = 131;			// cut right borders
			if (x+x0 > 131) x  = 131 - x0;
	
			y = y0 + 1;							// draw one line
		}
	
		x0 <<= nLcdDoubled / 2;					// adjust dimensions to pixel size
			x  <<= nLcdDoubled / 2;
		y0 <<= nLcdDoubled / 2;
		y  <<= nLcdDoubled / 2;
	

		hLcdBitmapUtil->End();
		iView->UpdateWindow(hLcdBitmap,x0,y0,x,y-y0,x0+Chipset.boffset*nLcdDoubled, y0);
	}
	//if(DEBUG) fileLogs.Write(_L8("WTMD Ok.\n"));
	return;
}

void Engine::WriteToMenuDisplay(TUint8* a, TUint32 d, TUint s)

{
	TInt x0, x;
	TInt y0, y;
	TUint8  *p;
	TUint32 val32;
	TUint16 val16;

	//if(DEBUG) fileLogs.Write(_L8("WTMenuD.\n"));

	// if (Chipset.width<0) return;			// 09.09.98 cg, bugfix, allow menu update
	if (Chipset.lcounter==0x3F) return;		// menu disabled
	d -= Chipset.start2;
	y0 = y = (d / 34) + (Chipset.lcounter+1);
	x0 = x = d % 34;
	if (x0 > 32) return;					// 01.02.99 cg, changed, position out of viewed area

	if(RedrawMode == 3 && FBAffiche && Focus) // avec FrameBuffer
	{
		if(DispMode == 2) // 8bpp
		{
			//if(DEBUG) fileLogs.Write(_L8("WTMenuD 3 8bpp.\n"));
			// calculate memory position in LCD bitmap

			p = (FBLcd + y0*nFBX*nLcdDoubled + x0*4*nLcdDoubled);
			while (s--)								// loop for nibbles to write
			{
				if (x<32)							// only fill visible area
				{
					if (nLcdDoubled == 2)
					{
						// p2[n4FBX] = p2[0] = Pattern2[(*a)&3];
						val32 = Pattern2[(*a)&3];
						Mem::Copy(p,&val32,4);
						Mem::Copy(p+nFBX,&val32,4);

						// p2[n4FBX+1] = p2[1] = Pattern2[(*a)>>2];
						val32 = Pattern2[(*a)>>2];
						Mem::Copy(p+4,&val32,4);
						Mem::Copy(p+nFBX+4,&val32,4);
					}
					if (nLcdDoubled == 1)
					{
						// *p2 = Pattern2[*a];
						val32 = Pattern2[*a];
						Mem::Copy(p,&val32,4);
					}
				}
				if(x == 32)
				{
					if (nLcdDoubled == 2)
					{
						// p2[n4FBX] = p2[0] = Pattern2[(*a)&3];
						val32 = Pattern2[(*a)&3];
						Mem::Copy(p,&val32,4);
						Mem::Copy(p+nFBX,&val32,4);

						// *(((TUint16*)p2)+n2FBX+2) = *(((TUint16*)p2)+2) = (TUint16)Pattern2[(*a)>>2];
						val32 = Pattern2[(*a)>>2];
						Mem::Copy(p+4,&val32,2);
						Mem::Copy(p+nFBX+4,&val32,2);
					}
					if (nLcdDoubled == 1)
					{
						// *((TUint16*)p2) = (TUint16)Pattern2[*a];
						val32 = Pattern2[*a];
						Mem::Copy(p,&val32,2);
						// *(((TUint8*)p2)+2) = (TUint8)(Pattern2[*a] >> 16);
						val32 = Pattern2[*a] >> 16;
						Mem::Copy(p+2,&val32,1);
					}
				}
				++a;								// next value to write
				++x;								// next x position
				if ((x==34)&&s)					// end of display line
				{
					// end of main display area
					if (y == (TInt) Chipset.lcounter) break;

					x = 0;							// first coloumn
					++y;							// next row
					if (y==64) break;
					// recalculate bitmap memory position of new line
					p = (FBLcd + y*nFBX*nLcdDoubled);
				}
				else 
					p += nLcdDoubled*4;				// next x position in bitmap
			}
		}
		else // 4bpp
		{
			//if(DEBUG) fileLogs.Write(_L8("WTMenuD 3 4bpp.\n"));
			if (nLcdDoubled == 2)					// 24.08.98 cg, new var type
			{
				p = (FBLcd + y0*nFBX + (x0<<2));
				while (s--)
				{
					if (x<32)							// only fill visible area
					{
						// p[n4FBX] = p[0] = Pattern[(*a)&3];
						val16 = Pattern[(*a)&3];
						Mem::Copy(p,&val16,2);
						Mem::Copy(p+n2FBX,&val16,2);

						// p[n4FBX+1] = p[1] = Pattern[(*a)>>2];
						val16 = Pattern[(*a)>>2];
						Mem::Copy(p+2,&val16,2);
						Mem::Copy(p+n2FBX+2,&val16,2);
					}
					if (x==32)
					{
						// p[n4FBX] = p[0] = Pattern[(*a)&3];
						val16 = Pattern[(*a)&3];
						Mem::Copy(p,&val16,2);
						Mem::Copy(p+n2FBX,&val16,2);

						// *((TUint8*)p+n2FBX+2) = *((TUint8*)p+2) = (TUint8)Pattern[(*a)>>2];
						val16 = Pattern[(*a)>>2];
						Mem::Copy(p+2,&val16,1);
						Mem::Copy(p+n2FBX+2,&val16,1);
					}
					a++;
					x++;
					if ((x==34)&&s)
					{
						x=0;
						y++;
						if (y==64) break;
						p = (FBLcd + y*nFBX);
					} else p+=4;
				}
			}
			if (nLcdDoubled == 1)					// 24.08.98 cg, new var type
			{
				p = (FBLcd + y0*(nFBX>>1) + (x0<<1));
				while (s--)
				{
					if (x<32)
					{
						// *p = Pattern[*a];
						val16 = Pattern[*a];
						Mem::Copy(p,&val16,2);
					}
					if (x==32)
					{
						*p=((*p)&0xf000) | (Pattern[*a]&0x0fff);
						Mem::Copy(&val16,p,2);
						val16 = (val16 & 0xf000) | (Pattern[*a]&0x0fff);
						Mem::Copy(p,&val16,2);
					}
					a++;
					x++;
					if ((x==34)&&s)
					{
						x=0;
						y++;
						if (y==64) break;
						p = (FBLcd + y*(nFBX>>1));
					} else p+=2;
				}
			}
		}
	}
	if(RedrawMode == 1) // Bitmap reel
	{
		hLcdBitmapUtil->Begin(TPoint(0,0));
		pbyLcd=(TUint8*)(hLcdBitmap->DataAddress());
		if(DispMode == 2) // 8bpp
		{
			//if(DEBUG) fileLogs.Write(_L8("WTMenuD 1 8bpp.\n"));
			if (nLcdDoubled == 2)					// 24.08.98 cg, new var type
			{
				p  = (pbyLcd + y0*LCD2_ROW*2 + x0*8);
				while (s--)
				{
					if (x<34)
					{
						// p2[72] = p2[0] = Pattern2[(*a)&3];
						val32 = Pattern2[(*a)&3];
						Mem::Copy(p,&val32,4);
						Mem::Copy(p+288,&val32,4);

						// p2[73] = p2[1] = Pattern2[(*a)>>2];
						val32 = Pattern2[(*a)>>2];
						Mem::Copy(p+4,&val32,4);
						Mem::Copy(p+288+4,&val32,4);
					}
					a++;
					x++;
					if ((x==34)&&s)
					{
						x=0;
						y++;
						if (y==64) break;
						p=(pbyLcd+y*LCD2_ROW*2);
					} else p+=8;
				}
				{
					if (y0!=y)
					{
						y0<<=1; y<<=1;
						if(RedrawMode == 1) iView->UpdateWindow(hLcdBitmap,0,y0,262, y-y0+2, 0, y0);
					}
					else
					{
						x0<<=3; x<<=3;
						y0<<=1; y<<=1;
						if (x>262) x=262;
						if(RedrawMode == 1) iView->UpdateWindow(hLcdBitmap,x0,y0,x-x0, y-y0+2, x0, y0);
					}
				}
			}
			if (nLcdDoubled == 1)					// 24.08.98 cg, new var type
			{
				p  = (pbyLcd + y0*144 + x0*4);
				while (s--)
				{
					if (x<34)
					{
						// *p2 = Pattern2[*a];
						val32 = Pattern2[*a];
						Mem::Copy(p,&val32,4);
					}
					a++;
					x++;
					if ((x==34)&&s)
					{
						x=0;
						y++;
						if (y==64) break;
						p=(pbyLcd+y*144);
					} else p+=4;
				}
				{
					if (y0!=y)

					{
						if(RedrawMode == 1) iView->UpdateWindow(hLcdBitmap,0,y0,131, y-y0+1, 0, y0);
					}
					else
					{
						x0<<=2; x<<=2;
						if (x>131) x=131;
						if(RedrawMode == 1) iView->UpdateWindow(hLcdBitmap,x0,y0, x-x0, y-y0+1, x0, y0);
					}
				}
			}
		}
		else // 4bpp
		{
			if (nLcdDoubled == 2)					// 24.08.98 cg, new var type
			{

				p  = (pbyLcd + y0*LCD2_ROW + x0*4);
				while (s--)
				{
					if (x<34)
					{
						// p[72] = p[0] = Pattern[(*a)&3];
						val16 = Pattern[(*a)&3];
						Mem::Copy(p,&val16,2);
						Mem::Copy(p+144,&val16,2);

						// p[73] = p[1] = Pattern[(*a)>>2];
						val16 = Pattern[(*a)>>2];
						Mem::Copy(p+2,&val16,2);
						Mem::Copy(p+144+2,&val16,2);
					}
					a++;
					x++;
					if ((x==34)&&s)
						{
						x=0;

						y++;
						if (y==64) break;
						p=(pbyLcd+y*LCD2_ROW);
					} else p+=4;
				}
				{
					if (y0!=y)
					{
						y0<<=1; y<<=1;
						iView->UpdateWindow(hLcdBitmap,0,y0,262, y-y0+2, 0, y0);
					}
					else
					{
						x0<<=3; x<<=3;
						y0<<=1; y<<=1;
						if (x>262) x=262;
						iView->UpdateWindow(hLcdBitmap,x0,y0,x-x0, y-y0+2, x0, y0);
					}
				}
			}
			if (nLcdDoubled == 1)					// 24.08.98 cg, new var type
			{
				p  = (pbyLcd + y0*72 + x0*2);
				while (s--)
				{
					if (x<34)
					{
						// *p = Pattern[*a];
						val16 = Pattern[*a];
						Mem::Copy(p,&val16,2);
					}
					a++;
					x++;
					if ((x==34)&&s)
					{
						x=0;
						y++;
						if (y==64) break;
						p=(pbyLcd+y*72);
					} else p+=2;
				}
				{
					if (y0!=y)
					{
						iView->UpdateWindow(hLcdBitmap,0,y0,131, y-y0+1, 0, y0);
					}
					else
					{
						x0<<=2; x<<=2;
						if (x>131) x=131;
						iView->UpdateWindow(hLcdBitmap,x0,y0, x-x0, y-y0+1, x0, y0);
					}
				}
			}
		}
		hLcdBitmapUtil->End();
	}
	//if(DEBUG) fileLogs.Write(_L8("WTMenuD Ok.\n"));
	return;
}

void Engine::UpdateAnnunciators(TBool Update)
{
	TUint8 c;

	//if(DEBUG) fileLogs.Write(_L8("      UpdateAnnunciators.\n"));
	
	c = (TUint8)(Chipset.IORam[0xB] | (Chipset.IORam[0xC]<<4));
	if (!(c&0x80)) c=0;
	if(Update)
	{
		DrawAnnunciator(1,c&0x01); // shift_Left
		DrawAnnunciator(2,c&0x02); // shift_right
		DrawAnnunciator(3,c&0x04); // alpha
		DrawAnnunciator(4,c&0x08);
		DrawAnnunciator(5,c&0x10);
		DrawAnnunciator(6,c&0x20);
	}
	iView->ButtonMode = 0;
	if(zoom == 2)
	{
		if(c&0x04)
		{
			iView->ButtonMode = 3;
		}
		else
		{
			if(c&0x01) iView->ButtonMode = 1;
			if(c&0x02) iView->ButtonMode = 2;
		}
	}
	return;
}

void Engine::DrawAnnunciator(TUint nId, TBool bOn)
{
	nId--;
	if (nId>=6) return;
	if (bOn)
	{
		pAnnunciator[nId].disp = ETrue;
		iView->UpdateAnnunc(hAnnuncBitmap,pAnnunciator[nId].destX,pAnnunciator[nId].destY,11,10,pAnnunciator[nId].srcX,pAnnunciator[nId].srcY);
	}
	else
	{
		pAnnunciator[nId].disp = EFalse;
		iView->UpdateAnnunc(hAnnuncBitmap,pAnnunciator[nId].destX,pAnnunciator[nId].destY,11,10,94,0);
	}
	return;
}


