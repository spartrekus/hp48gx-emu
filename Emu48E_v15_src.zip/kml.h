/*
 *   kml.h
 *
 *   This file is part of Emu48
 *
 *   Copyright (C) 1995 Sebastien Carlier
 *
 */

#include <w32std.h>


typedef struct Annunciator
{
	TUint srcX, srcY;
	TUint destX, destY;
	TBool disp;
} Annunciator;
