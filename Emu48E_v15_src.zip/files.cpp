#include "engine.h"

inline TUint MIN(TUint a, TUint b)
{
	return (a<b)?a:b;
}

//################
//#
//#    ROM
//#
//################

TBool Engine::MapRom()
{
	RFs fs;
	TBuf8<256> Buff1;
	TInt result;
	TUint pos;
	TInt i;

	pbyRom = NULL;
	bBackup = EFalse;
	dwRomSize=0;

	if(fs.Connect() != KErrNone)
	{
		if(DEBUG) fileLogs.Write(_L8("Connection impossible a FileServer !\n"));
		return EFalse;
	}

	RFile fileRom;
	//filename = DefaultDrive;
	//filename += KFicRomGx;
	if(fileRom.Open(fs,RomFileName,EFileShareReadersOnly) == KErrNone)
	{
		if(DEBUG) fileLogs.Write(_L8("Fichier Rom.\n"));
	}
	else
	{
		fs.Close();
		if(DEBUG) fileLogs.Write(_L8("Fichier sx, gx ou 49g.rom introuvable !\n"));
		User::InfoPrint(_L("Fichier sx, gx ou 49g.rom introuvable"));
		return EFalse;
	}
	if (fileRom.Size(dwRomSize) != KErrNone)
	{
		fileRom.Close();
		fs.Close();
		dwRomSize = 0;
		if(DEBUG) fileLogs.Write(_L8("Erreur fileRom.Open !\n"));
		return EFalse;
	}
	if(DEBUG) fileLogs.Write(_L8("fileRom.Open Ok.\n"));

	dwRomSize *=2;
	if (hRomMap.CreateLocal(dwRomSize,dwRomSize) != KErrNone)
	{
		fileRom.Close();
		fs.Close();
		dwRomSize = 0;
		if(DEBUG) fileLogs.Write(_L8("Erreur RChunk, pas assez de memoire !\n"));
		User::InfoPrint(_L("Memory Error"));
		return EFalse;
	}
	if(DEBUG) fileLogs.Write(_L8("RChunk Ok.\n"));
	pbyRom=hRomMap.Base();

	Buff1.SetLength(256);
	pos=0;
	result=fileRom.Read(Buff1);
	while(Buff1.Length() > 0)
	{
		// hRomMap.Write(pos,Buff1);
		for(i=0;i<Buff1.Length();i++)
		{
			*pbyRom = Buff1[i] & 0x0f;
			pbyRom += 1;
			*pbyRom = Buff1[i]>>4;
			pbyRom += 1;
		}
		result=fileRom.Read(Buff1);
	}
	pbyRom=hRomMap.Base();
#if 0
	// verif => Ok.
	TInt fin = dwRomSize;
	pos = 0;
	Buff1.SetLength(1);
	while (pos < fin) {
		Buff1[0] = *(pbyRom+pos);
		if(DEBUG) fileLogs.Write(Buff1);
		pos++;
	}
#endif
	fileRom.Close();
	fs.Close();
	if(DEBUG) fileLogs.Write(_L8("MapRom Ok.\n"));
	return ETrue;
}

void Engine::UnmapRom()
{
	if (pbyRom==NULL) return;
	pbyRom = NULL;
	dwRomSize = 0;
	hRomMap.Close();
	if(DEBUG) fileLogs.Write(_L8("hRomMap.Close Ok.\n"));
	return;
}

TUint16 Engine::CrcPort2()
{
	TUint32 dwCount;
	TUint16 wCrc = 0;

	if (pbyPort2==NULL) return wCrc;		// port2 isn't available
	for (dwCount = 0;dwCount < dwPort2Size; ++dwCount)
	{
		wCrc = (wCrc >> 4) ^ (((wCrc ^ ((TUint16) pbyPort2[dwCount])) & 0xf) * 0x1081);
	}
	return wCrc;
}


TBool Engine::SaveP0()
{
	RFs fs;
	RFile fileRam;
	TBuf8<256> Buff1;
	TUint8* adr;
	TUint cpt;
	TUint taille;
	TInt i;
	TBool erreur;
	TInt err;

	if(DEBUG) fileLogs.Write(_L8("SaveP0.\n"));
	if(fs.Connect() != KErrNone)
	{
		if(DEBUG) fileLogs.Write(_L8("SaveP0 : Connection impossible a FileServer !\n"));
		return EFalse;
	}
	filename = DefaultDriveBak;
	filename += KFicRamP0;

#ifndef _UNICODE
	if(DEBUG)
	{
		fileLogs.Write(filename);
		fileLogs.Write(_L8(".\n"));
	}
#endif
	err = fileRam.Replace(fs,filename,EFileWrite);
	if(DEBUG)
	{
		fileLogs.Write(_L8("err = "));
		strnum.Num(err);
		fileLogs.Write(strnum);
		fileLogs.Write(_L8(".\n"));
	}
	if(err != KErrNone) 
	{
		fs.Close();
		if(DEBUG) fileLogs.Write(_L8("Erreur replace FicRamP0 !\n"));
		return EFalse;
	}

	adr = (TUint8*)adrCellP0;
	taille = Chipset.Port0Size * 1024;
	cpt = 0;
	erreur = EFalse;
	Buff1.SetLength(MIN(256,taille-cpt));
	while(cpt < taille && !erreur)
	{
		//Buff1.Copy(adr,Buff1.Length());
		for(i=0;i<Buff1.Length();i++)
		{
			Buff1[i] = (adr[1]<<4) ^ (adr[0]);
			adr+=2;
		}
		if(fileRam.Write(Buff1) != KErrNone) erreur = ETrue;
		cpt += Buff1.Length();
		Buff1.SetLength(MIN(256,taille-cpt));
	}
	fileRam.Close();
	fs.Close();
	if(erreur)
	{
		if(DEBUG) fileLogs.Write(_L8("SaveP0 : Erreur ecriture disk !. \n"));


		return EFalse;
	}
	if(DEBUG) fileLogs.Write(_L8("SaveP0 : Ok. \n"));
	return ETrue;
}

TBool Engine::SaveP1()
{
	RFs fs;
	RFile fileRam;
	TBuf8<256> Buff1;
	TUint8* adr;
	TUint cpt;
	TUint taille;
	TInt i;
	TBool vide;
	TBool erreur;
	TInt err;

	if(DEBUG) fileLogs.Write(_L8("SaveP1.\n"));
	if(fs.Connect() != KErrNone)
	{
		if(DEBUG) fileLogs.Write(_L8("SaveP1 : Connection impossible a FileServer !\n"));
		return EFalse;
	}
	filename = DefaultDriveBak;
	filename += KFicRamP1;
#ifndef _UNICODE
	if(DEBUG)
	{
		fileLogs.Write(filename);
		fileLogs.Write(_L8(".\n"));
	}
#endif
	err = fileRam.Replace(fs,filename,EFileWrite);
	if(DEBUG)
	{
		fileLogs.Write(_L8("err = "));
		strnum.Num(err);
		fileLogs.Write(strnum);
		fileLogs.Write(_L8(".\n"));
	}
	if(err != KErrNone) 
	{
		fs.Close();
		if(DEBUG) fileLogs.Write(_L8("Erreur replace FicRamP1 !\n"));
		return EFalse;
	}

	adr = (TUint8*)adrCellP1;
	taille = Chipset.Port1Size * 1024;
	cpt = 0;
	vide = ETrue;
	erreur = EFalse;
	Buff1.SetLength(MIN(256,taille-cpt));
	while(cpt < taille && !erreur)
	{
		//Buff1.Copy(adr,Buff1.Length());
		for(i=0;i<Buff1.Length();i++)
		{
			Buff1[i] = (adr[1]<<4) ^ (adr[0]);
			if(Buff1[i] != 0) vide = EFalse;
			adr+=2;
		}
		if(fileRam.Write(Buff1) != KErrNone) erreur = ETrue;
		cpt += Buff1.Length();
		Buff1.SetLength(MIN(256,taille-cpt));
	}
	fileRam.Close();
	if(erreur)
	{
		if(DEBUG) fileLogs.Write(_L8("SaveP1 : Erreur ecriture disk !. \n"));
		fs.Close();
		return EFalse;
	}
	if(vide)
	{
		filename = DefaultDriveBak;
		filename += KFicRamP1;
		fileRam.Replace(fs,filename,EFileWrite);
		Buff1.SetLength(1);

		Buff1[0] = 0;
		fileRam.Write(Buff1);
		fileRam.Close();


		if(DEBUG) fileLogs.Write(_L8("SaveP1 : vide Ok. \n"));
	}
	else
	{
		if(DEBUG) fileLogs.Write(_L8("SaveP1 : Ok. \n"));
	}
	fs.Close();
	return ETrue;
}

TBool Engine::SaveP2()
{
	RFs fs;
	RFile fileRam;
	TBuf8<256> Buff1;
	TUint8* adr;
	TUint cpt;
	TUint taille;
	TInt i;
	TBool vide;
	TBool erreur;
	TInt err;

	if(DEBUG) fileLogs.Write(_L8("SaveP2.\n"));
	if(!bPort2Plugged && !Chipset.Port2Size)
	{
		if(DEBUG) fileLogs.Write(_L8("SaveP2 : port2 non connecte.\n"));
		return ETrue;
	}
	if(fs.Connect() != KErrNone)
	{
		if(DEBUG) fileLogs.Write(_L8("SaveP2 : Connection impossible a FileServer !\n"));
		return EFalse;
	}
	filename = DefaultDriveBak;
	filename += KFicRamP2;
#ifndef _UNICODE
	if(DEBUG)
	{
		fileLogs.Write(filename);
		fileLogs.Write(_L8(".\n"));
	}
#endif
	err = fileRam.Replace(fs,filename,EFileWrite);
	if(err != KErrNone) 
	{
		fs.Close();
		if(DEBUG) fileLogs.Write(_L8("Erreur replace FicRamP2 !\n"));
		return EFalse;
	}

	if(bPort2Plugged)
	{
		taille = dwPort2Size * 1024;
		adr = pbyPort2;
	}
	else if(Chipset.Port2Size)
	{
		taille = Chipset.Port2Size * 1024;
		adr = Chipset.Port2;
	}
	else
	{
		taille = 0;
		adr = NULL;
	}

	cpt = 0;
	vide = ETrue;
	erreur = EFalse;
	Buff1.SetLength(MIN(256,taille-cpt));
	while(cpt < taille && !erreur)
	{
		//Buff1.Copy(adr,Buff1.Length());
		for(i=0;i<Buff1.Length();i++)
		{
			Buff1[i] = (adr[1]<<4) ^ (adr[0]);
			if(Buff1[i] != 0) vide = EFalse;
			adr+=2;
		}
		if(fileRam.Write(Buff1) != KErrNone) erreur = ETrue;
		cpt += Buff1.Length();
		Buff1.SetLength(MIN(256,taille-cpt));
	}
	fileRam.Close();
	if(erreur)
	{
		if(DEBUG) fileLogs.Write(_L8("SaveP2 : Erreur ecriture disk !. \n"));
		fs.Close();
		return EFalse;
	}
	if(vide)
	{
		filename = DefaultDriveBak;
		filename += KFicRamP2;
		fileRam.Replace(fs,filename,EFileWrite);
		Buff1.SetLength(1);

		Buff1[0] = 0;
		fileRam.Write(Buff1);
		fileRam.Close();
		if(DEBUG) fileLogs.Write(_L8("SaveP2 : vide Ok. \n"));
	}
	else
	{
		if(DEBUG) fileLogs.Write(_L8("SaveP2 : Ok. \n"));
	}
	fs.Close();
	return ETrue;
}

TBool Engine::SaveChipset()
{
	RFs fs;
	RFile fileRam;
	TBuf8<256> Buff1;
	TUint8* adr;
	TUint cpt;
	TUint taille;
	TBool erreur;
	TInt err;

	if(bPort2Plugged)	Chipset.wPort2Crc = CrcPort2();
	if(fs.Connect() != KErrNone)
	{
		if(DEBUG) fileLogs.Write(_L8("SaveChipset : Connection impossible a FileServer !\n"));
		return EFalse;
	}
	filename = DefaultDriveBak;
	filename += KFicChipset;
#ifndef _UNICODE
	if(DEBUG)
	{
		fileLogs.Write(filename);
		fileLogs.Write(_L8(".\n"));
	}
#endif
	err = fileRam.Replace(fs,filename,EFileWrite);
	if(DEBUG)
	{
		fileLogs.Write(_L8("err = "));
		strnum.Num(err);
		fileLogs.Write(strnum);
		fileLogs.Write(_L8(".\n"));
	}
	if(err != KErrNone) 
	{
		fs.Close();
		if(DEBUG) fileLogs.Write(_L8("Erreur replace FicChipset !\n"));
		return EFalse;
	}
	adr = (TUint8*)&Chipset;
	taille = sizeof(Chipset);
	cpt = 0;
	erreur = EFalse;
	Buff1.SetLength(MIN(256,taille-cpt));
	while(cpt < taille && !erreur)
	{
		Buff1.Copy(adr,Buff1.Length());
		if(fileRam.Write(Buff1) != KErrNone) erreur = ETrue;
		cpt += Buff1.Length();
		adr += Buff1.Length();
		Buff1.SetLength(MIN(256,taille-cpt));
	}
	fileRam.Close();
	fs.Close();
	if(erreur)
	{
		if(DEBUG) fileLogs.Write(_L8("SaveChipset : Erreur ecriture disk !. \n"));
		return EFalse;
	}
	if(DEBUG) fileLogs.Write(_L8("SaveChipset : Ok. \n"));
	return ETrue;
}

TBool Engine::SaveRom()
{
	RFs fs;
	RFile fileRam;
	TBuf8<256> Buff1;
	TUint8* adr;
	TUint cpt;
	TUint taille;
	TInt i;
	TBool erreur;
	TInt err;

	if(DEBUG) fileLogs.Write(_L8("SaveRom.\n"));
	if(cCurrentRomType != 3) return ETrue;

	if(fs.Connect() != KErrNone)
	{
		if(DEBUG) fileLogs.Write(_L8("SaveRom : Connection impossible a FileServer !\n"));
		return EFalse;
	}
	filename = DefaultDriveBak;
	filename += KFicRom49G;

	err = fileRam.Replace(fs,filename,EFileWrite);

	if(err != KErrNone) 
	{
		fs.Close();
		if(DEBUG) fileLogs.Write(_L8("Erreur replace FicRom !\n"));
		return EFalse;
	}

	adr = pbyRom;
	taille = dwRomSize/2;
	cpt = 0;
	erreur = EFalse;
	Buff1.SetLength(MIN(256,taille-cpt));
	while(cpt < taille && !erreur)
	{
		//Buff1.Copy(adr,Buff1.Length());
		for(i=0;i<Buff1.Length();i++)
		{
			Buff1[i] = (adr[1]<<4) ^ (adr[0]);
			adr+=2;
		}
		if(fileRam.Write(Buff1) != KErrNone) erreur = ETrue;
		cpt += Buff1.Length();
		Buff1.SetLength(MIN(256,taille-cpt));
	}
	fileRam.Close();
	fs.Close();
	if(erreur)
	{
		if(DEBUG) fileLogs.Write(_L8("SaveRom : Erreur ecriture disk !. \n"));


		return EFalse;
	}
	if(DEBUG) fileLogs.Write(_L8("SaveRom : Ok. \n"));
	return ETrue;
}


TBool Engine::LoadP0()
{
	RFs fs;
	TBuf8<256> Buff1;
	TUint8* adr;
	TUint8* adrBuff;
	TUint taille;
	TInt dwRamSize;
	TUint i;

	if(fs.Connect() != KErrNone)
	{
		if(DEBUG) fileLogs.Write(_L8("LoadP0 Connection impossible a FileServer !\n"));
		return EFalse;
	}

	RFile fileRam;
	filename = DefaultDriveBak;
	filename += KFicRamP0;
#ifndef _UNICODE
	if(DEBUG)
	{
		fileLogs.Write(filename);
		fileLogs.Write(_L8(".\n"));
	}
#endif
	if(fileRam.Open(fs,filename,EFileShareReadersOnly) != KErrNone)
	{
		fs.Close();
		if(DEBUG) fileLogs.Write(_L8("Fichier RamP0 introuvable !\n"));
		return EFalse;
	}
	if (fileRam.Size(dwRamSize) != KErrNone)
	{
		fileRam.Close();

		fs.Close();
		if(DEBUG) fileLogs.Write(_L8("Erreur RamP0 Open !\n"));
		return EFalse;
	}
	if (dwRamSize != (TInt)(Chipset.Port0Size * 1024))
	{
		fileRam.Close();
		fs.Close();
		if(DEBUG) fileLogs.Write(_L8("FicRamP0 taille invalide !\n"));
		return EFalse;
	}

	Buff1.SetLength(256);

	adrBuff = (TUint8*)Buff1.Ptr();
	adr = (TUint8*)adrCellP0;
	fileRam.Read(Buff1);
	taille = Buff1.Length();
	while(taille > 0) {
		//Mem::Copy(adr,adrBuff,taille);
		for(i=0; i<taille; i++)
		{
			*adr = Buff1[i] & 0x0f;
			adr += 1;
			*adr = Buff1[i]>>4;
			adr += 1;

		}
		//adr += taille;
		fileRam.Read(Buff1);
		taille = Buff1.Length();

	}
	fileRam.Close();
	fs.Close();
	if(DEBUG) fileLogs.Write(_L8("LoadP0 Ok.\n"));
	return ETrue;
}

TBool Engine::LoadP1()
{
	RFs fs;
	TBuf8<256> Buff1;
	TUint8* adr;
	TUint8* adrBuff;
	TUint taille;
	TInt dwRamSize;
	TUint i;

	if(fs.Connect() != KErrNone)
	{
		if(DEBUG) fileLogs.Write(_L8("LoadP1 Connection impossible a FileServer !\n"));
		return EFalse;
	}

	RFile fileRam;
	filename = DefaultDriveBak;
	filename += KFicRamP1;
	if(fileRam.Open(fs,filename,EFileShareReadersOnly) != KErrNone)
	{
		fs.Close();
		if(DEBUG) fileLogs.Write(_L8("Fichier RamP1 introuvable !\n"));
		return EFalse;
	}
	if (fileRam.Size(dwRamSize) != KErrNone)
	{
		fileRam.Close();
		fs.Close();
		if(DEBUG) fileLogs.Write(_L8("Erreur RamP1 Open !\n"));
		return EFalse;

	}
	if (dwRamSize != (TInt)(Chipset.Port1Size * 1024))
	{
		fileRam.Close();
		fs.Close();
		Mem::Fill(Chipset.Port1, Chipset.Port1Size*2048, 0x0);
		if(DEBUG) fileLogs.Write(_L8("FicRamP1 taille invalide => raz.\n"));
		return ETrue;
	}

	Buff1.SetLength(256);
	adrBuff = (TUint8*)Buff1.Ptr();
	adr = (TUint8*)adrCellP1;
	fileRam.Read(Buff1);
	taille = Buff1.Length();
	while(taille > 0) {
		//Mem::Copy(adr,adrBuff,taille);
		for(i=0; i<taille; i++)
		{
			*adr = Buff1[i] & 0x0f;
			adr += 1;
			*adr = Buff1[i]>>4;
			adr += 1;
		}
		//adr += taille;

		fileRam.Read(Buff1);
		taille = Buff1.Length();
	}
	fileRam.Close();
	fs.Close();
	if(DEBUG) fileLogs.Write(_L8("LoadP1 Ok.\n"));
	return ETrue;
}


TBool Engine::LoadP2()
{
	RFs fs;
	TBuf8<256> Buff1;
	TUint8* adr;
	TUint8* adrBuff;
	TUint taille;
	TInt dwRamSize;
	TInt Port2Size;
	TUint i;

	if(!bPort2Plugged && Chipset.Port2Size==0)
	{
		if(DEBUG) fileLogs.Write(_L8("LoadP2 port2 non present\n"));
		return ETrue;
	}
	if(fs.Connect() != KErrNone)
	{
		if(DEBUG) fileLogs.Write(_L8("LoadP2 Connection impossible a FileServer !\n"));
		return EFalse;
	}

	RFile fileRam;
	filename = DefaultDriveBak;
	filename += KFicRamP2;
	if(fileRam.Open(fs,filename,EFileShareReadersOnly) != KErrNone)
	{
		fs.Close();
		if(DEBUG) fileLogs.Write(_L8("Fichier RamP2 introuvable !\n"));
		return EFalse;
	}
	if (fileRam.Size(dwRamSize) != KErrNone)
	{
		fileRam.Close();
		fs.Close();
		if(DEBUG) fileLogs.Write(_L8("Erreur RamP2 Open !\n"));
		return EFalse;

	}
	if(bPort2Plugged)
	{
		Port2Size = dwPort2Size;
		adr = pbyPort2;
	}
	else if(Chipset.Port2Size > 0)
	{
		Port2Size = Chipset.Port2Size;
		adr = Chipset.Port2;
	}
	else
	{
		Port2Size = 0;
		adr = NULL;
	}
	if (dwRamSize != Port2Size * 1024)
	{
		fileRam.Close();
		fs.Close();
		Mem::Fill(adr, Port2Size*2048, 0x0);
		if(DEBUG) fileLogs.Write(_L8("FicRamP2 taille invalide => raz.\n"));
		return ETrue;
	}

	Buff1.SetLength(256);
	adrBuff = (TUint8*)Buff1.Ptr();
	fileRam.Read(Buff1);
	taille = Buff1.Length();
	while(taille > 0) {
		//Mem::Copy(adr,adrBuff,taille);
		for(i=0; i<taille; i++)
		{
			*adr = Buff1[i] & 0x0f;
			adr += 1;
			*adr = Buff1[i]>>4;
			adr += 1;
		}
		//adr += taille;

		fileRam.Read(Buff1);
		taille = Buff1.Length();
	}
	fileRam.Close();
	fs.Close();
	if(DEBUG) fileLogs.Write(_L8("LoadP2 Ok.\n"));
	return ETrue;
}


TBool Engine::LoadChipset()
{
	RFs fs;

	TBuf8<256> Buff1;
	TUint8* adr;
	TUint8* adrBuff;
	TUint taille;
	TInt dwRamSize;

	Chipset.type = cCurrentRomType;
	if(fs.Connect() != KErrNone)
	{
		if(DEBUG) fileLogs.Write(_L8("LoadChipset Connection impossible a FileServer !\n"));
		return EFalse;
	}

	RFile fileRam;
	filename = DefaultDriveBak;
	filename += KFicChipset;
	if(fileRam.Open(fs,filename,EFileShareReadersOnly) != KErrNone)
	{
		fs.Close();
		if(DEBUG) fileLogs.Write(_L8("Fichier chipset introuvable !\n"));
		return EFalse;
	}
	if (fileRam.Size(dwRamSize) != KErrNone)
	{
		fileRam.Close();
		fs.Close();
		if(DEBUG) fileLogs.Write(_L8("Erreur fichier Chipset Open !\n"));
		return EFalse;
	}
	if (dwRamSize != sizeof(Chipset))
	{
		fileRam.Close();
		fs.Close();
		if(DEBUG) fileLogs.Write(_L8("Fichier chipset taille invalide !\n"));
		return EFalse;
	}

	Buff1.SetLength(256);
	adrBuff = (TUint8*)Buff1.Ptr();
	adr = (TUint8*)&Chipset;
	fileRam.Read(Buff1);
	taille = Buff1.Length();
	while(taille > 0) {
		Mem::Copy(adr,adrBuff,taille);
		adr += taille;
		fileRam.Read(Buff1);
		taille = Buff1.Length();
	}
	fileRam.Close();
	fs.Close();
	if(DEBUG) fileLogs.Write(_L8("LoadChipset Ok.\n"));
	return ETrue;
}

TBool Engine::SuppSauvegarde()
{
	RFs fs;
	TInt err;
	if(fs.Connect() != KErrNone)
	{
		if(DEBUG) fileLogs.Write(_L8("Nouveau Connection impossible a FileServer !\n"));
		return EFalse;
	}

	filename = DefaultDriveBak;
	filename += KFicRamP0;
#ifndef _UNICODE
	if(DEBUG)
	{
		fileLogs.Write(filename);
		fileLogs.Write(_L8(".\n"));
	}
#endif
	err = fs.Delete(filename);
	if(DEBUG)
	{
		fileLogs.Write(_L8("err = "));

		strnum.Num(err);
		fileLogs.Write(strnum);
		fileLogs.Write(_L8(".\n"));
	}
	if(err != KErrNone && err != KErrNotFound)
	{
		fs.Close();
		if(DEBUG) fileLogs.Write(_L8("Erreur supp FicRamP0 !\n"));

		return EFalse;
	}

	filename = DefaultDriveBak;
	filename += KFicRamP1;
	err = fs.Delete(filename);
	if(err != KErrNone && err != KErrNotFound)
	{
		fs.Close();
		if(DEBUG) fileLogs.Write(_L8("Erreur supp FicRamP1 !\n"));
		return EFalse;
	}

	if(bPort2Plugged || Chipset.Port2Size>0)
	{
		filename = DefaultDriveBak;
		filename += KFicRamP2;
		err = fs.Delete(filename);
		if(err != KErrNone && err != KErrNotFound)
		{
			fs.Close();
			if(DEBUG) fileLogs.Write(_L8("Erreur supp FicRamP2 !\n"));
			return EFalse;
		}
	}

	filename = DefaultDriveBak;
	filename += KFicChipset;
	err = fs.Delete(filename);
	if(err != KErrNone && err != KErrNotFound)
	{
		fs.Close();
		fileLogs.Write(_L8("Erreur supp FicChipset !\n"));
		return EFalse;
	}
	fs.Close();
	if(DEBUG) fileLogs.Write(_L8("Supp FicRamP0 FicRamP1 FicChipset Ok.\n"));
	return ETrue;
}

TBool Engine::Recharger()
{
	nState = 1;
	nNextState = 0;

	bInterrupt = EFalse;
	if(!LoadChipset())
	{
		InitChipset();
	}
	if(LoadP0() && LoadP1() && LoadP2())
	{
		if(DEBUG) fileLogs.Write(_L8("LoadP0, P1, P2 Ok.\n"));
		if(cCurrentRomType==1 || cCurrentRomType==2)
		{
			if (Chipset.wPort2Crc != CrcPort2())// port2 changed
			{
				Chipset.HST |= 8;				// set Module Pulled
				Chipset.SoftInt = ETrue;			// set interrupt
				bInterrupt = ETrue;
			}
		}
		RomSwitch(Chipset.Bank_FF);				// reload ROM view of HP49G and map memory
		return ETrue;
	}
	else
	{
		if(DEBUG) fileLogs.Write(_L8("LoadP0, P1, P2 Erreur.\n"));
		return EFalse;
	}
	return EFalse;
}
