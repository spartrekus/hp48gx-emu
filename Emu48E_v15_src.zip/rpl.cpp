#include "engine.h"

inline TUint MIN(TUint a, TUint b)
{
	return (a<b)?a:b;
}

TUint32 Engine::RPL_SkipOb(TUint32 d)
{
	TUint8 X[8];
	TUint32 n, l;
	
	Npeek(X,d,5);
	n = Npack(X, 5); // read prolog
	switch (n)
	{
	case 0x026AC: l = (cCurrentRomType!=3) ? 5 : 12; break; // Flash PTR (HP49G)
	case 0x02911: l = 10; break; // System Binary
	case 0x02933: l = 21; break; // Real
	case 0x02955: l = 26; break; // Long Real
	case 0x02977: l = 37; break; // Complex
	case 0x0299D: l = 47; break; // Long Complex
	case 0x029BF: l =  7; break; // Character
	case 0x02BAA: l = 15; break; // Extended Pointer
	case 0x02E92: l = 11; break; // XLIB Name
	case 0x02686: // Symbolic matrix (HP49G)
		if (cCurrentRomType!=3)
		{
			l = 5;
			break;
		}
	case 0x02A74: // List
	case 0x02AB8: // Algebraic
	case 0x02ADA: // Unit
	case 0x02D9D: // Program
		n=d+5;
		do
		{
			d=n; n=RPL_SkipOb(d);
		} while (d!=n);
		return n+5;
	case 0x0312B: return d; // SEMI
	case 0x02E48: // Global Name
	case 0x02E6D: // Local Name
	case 0x02AFC: // Tagged
		Npeek(X,d+5,2); n = 7 + Npack(X,2)*2;
		return RPL_SkipOb(d+n);
	case 0x02A96: // Directory
		d+=8;
		n = Read5(d);
		if (n==0)
		{
			return d+5;
		}
		else
		{
			d+=n;
			Npeek(X,d,2);
			n = Npack(X,2)*2 + 4;
			return RPL_SkipOb(d+n);
		}
	case 0x02614: // Precision Integer (HP49G)
	case 0x026D5: // Aplet (HP49G)
	case 0x026FE: // Mini Font (HP49G)
		if (cCurrentRomType!=3)
		{
			l = 5;
			break;
		}
	case 0x029E8: // Array
	case 0x02A0A: // Linked Array
	case 0x02A2C: // String
	case 0x02A4E: // Binary Integer
	case 0x02B1E: // Graphic
	case 0x02B40: // Library
	case 0x02B62: // Backup
	case 0x02B88: // Library Data
	case 0x02BCC: // Reserved 1, Font (HP49G)
	case 0x02BEE: // Reserved 2
	case 0x02C10: // Reserved 3
	case 0x02DCC: // Code
		l = 5+Read5(d+5);
		break;
	case 0x0263A: // Precision Real (HP49G)
		l = 5;
		if (cCurrentRomType==3)
		{
			l += Read5(d+l);
			l += Read5(d+l);
		}
		break;
	case 0x02660: // Precision Complex (HP49G)
		l = 5;
		if (cCurrentRomType==3)
		{
			l += Read5(d+l);
			l += Read5(d+l);
			l += Read5(d+l);
			l += Read5(d+l);
		}
		break;
	default: return d+5;
	}
	return d+l;
}

TUint32 Engine::RPL_ObjectSize(TUint8 *o)
{
	TUint32 n, l = 0;
	
	n = Npack(o, 5); // read prolog
	switch (n)
	{
	case 0x026AC: l = (cCurrentRomType!=3) ? 5 : 12; break; // Flash PTR (HP49G)
	case 0x02911: l = 10; break; // System Binary
	case 0x02933: l = 21; break; // Real
	case 0x02955: l = 26; break; // Long Real
	case 0x02977: l = 37; break; // Complex
	case 0x0299D: l = 47; break; // Long Complex
	case 0x029BF: l =  7; break; // Character
	case 0x02BAA: l = 15; break; // Extended Pointer
	case 0x02E92: l = 11; break; // XLIB Name
	case 0x02686: // Symbolic matrix (HP49G)
		if (cCurrentRomType!=3)
		{
			l = 5;
			break;
		}
	case 0x02A74: // List
	case 0x02AB8: // Algebraic
	case 0x02ADA: // Unit
	case 0x02D9D: // Program
		n=5;
		do { l+=n; o+=n; n=RPL_ObjectSize(o); } while (n);
		l += 5;
		break;
	case 0x0312B: l =  0; break; // SEMI
	case 0x02E48: // Global Name
	case 0x02E6D: // Local Name
	case 0x02AFC: // Tagged
		n = 7 + Npack(o+5,2)*2;
		l = n + RPL_ObjectSize(o+n);
		break;
	case 0x02A96: // Directory
		n = Npack(o+8,5);
		if (n==0) // empty dir
		{
			l=13;
		}
		else
		{
			l = 8+n;
			n = Npack(o+l,2)*2 + 4;
			l += n;
			l += RPL_ObjectSize(o+l);
		}
		break;
	case 0x02614: // Precision Integer (HP49G)
	case 0x026D5: // Aplet (HP49G)
	case 0x026FE: // Mini Font (HP49G)
		if (cCurrentRomType!=3)
		{
			l = 5;
			break;
		}
	case 0x029E8: // Array
	case 0x02A0A: // Linked Array
	case 0x02A2C: // String
	case 0x02A4E: // Binary Integer
	case 0x02B1E: // Graphic
	case 0x02B40: // Library
	case 0x02B62: // Backup
	case 0x02B88: // Library Data
	case 0x02BCC: // Reserved 1, Font (HP49G)
	case 0x02BEE: // Reserved 2
	case 0x02C10: // Reserved 3
	case 0x02DCC: // Code
		l = 5 + Npack(o+5,5);
		break;
	case 0x0263A: // Precision Real (HP49G)
		l = 5;
		if (cCurrentRomType==3)
		{
			l += Npack(o+l,5);
			l += Npack(o+l,5);
		}
		break;
	case 0x02660: // Precision Complex (HP49G)
		l = 5;
		if (cCurrentRomType==3)
		{
			l += Npack(o+l,5);
			l += Npack(o+l,5);
			l += Npack(o+l,5);
			l += Npack(o+l,5);
		}
		break;
	default: l=5;
	}
	return l;
}

TUint32 Engine::RPL_CreateTemp(TUint32 l)
{
	TUint32 a, b, c;
	TUint8 *p;
	TAny* locAlloc;
	
	l += 6;
	a = Read5(TEMPTOP);
	b = Read5(RSKTOP);						// start of available mem
	c = Read5(DSKTOP);						// end of available mem
	if ((b+l)>c) return 0;					// check if there is enough memory
	Write5(TEMPTOP, a+l);					// adjust end of temporary objects
	Write5(RSKTOP,  b+l);					// adjust start of available mem
	Write5(AVMEM, (c-(b+l))/5);				// free memory (*5 nibbles)

	// p = (TUint8*)LocalAlloc(0,b-a);
	locAlloc = User::Alloc(b-a);
	if (locAlloc == NULL) return(0);
	p = (TUint8*)locAlloc;

	Npeek(p,a,b-a);
	Nwrite(p,a+l,b-a);

	//LocalFree(p);
	User::FreeZ(locAlloc);

	Write5(a+l-5,l);						// set temporary object length field
	return (a+1);							// return temporary object address
}

TUint32 Engine::RPL_Pick(TUint l)
{
	TUint32 stkp;

	//_ASSERT(l > 0);							// 12.11.98 cg, new, first stack elememt is one
	if (l==0) return 0;
	stkp = Read5(DSKTOP) + (l-1)*5;
	return Read5(stkp);
}

#if 0										// 12.11.98 cg, function not needed yet
void Engine::RPL_Replace(TUint32 n)
{
	TUint32 stkp;
	
	stkp = Read5(DSKTOP);
	Write5(stkp,n);
	return;
}
#endif

void Engine::RPL_Push(TUint32 n)
{
	TUint32 stkp, avmem;
	
	avmem = Read5(AVMEM);					// amount of free memory
	if (avmem==0) return;					// no memory free
	avmem--;								// fetch memory
	Write5(AVMEM,avmem);					// save new amount of free memory
	stkp = Read5(DSKTOP);					// get pointer to stack level 1
	stkp-=5;								// fetch new stack entry
	Write5(stkp,n);							// save pointer to new object on stack level 1
	Write5(DSKTOP,stkp);					// save new pointer to stack level 1
	return;
}


TUint16 Engine::WriteStack(TUint8* lpBuf,TUint32 dwSize)	// 11.05.98 cg, new, separated from LoadObject()
{
	TBool   bBinary;
	TUint32  dwAddress, i;

	if(DEBUG) fileLogs.Write(_L8("WriteStack debut.\n"));
	bBinary =  ((lpBuf[dwSize+0]=='H')
		&&  (lpBuf[dwSize+1]=='P')
		&&  (lpBuf[dwSize+2]=='H')
		&&  (lpBuf[dwSize+3]=='P')
		&&  (lpBuf[dwSize+4]=='4')
        &&  (lpBuf[dwSize+5]==((cCurrentRomType!=3) ? '8' : '9'))
		&&  (lpBuf[dwSize+6]=='-'));

	for (i=0; i<dwSize; i++)
	{
		TUint8 byTwoNibs = lpBuf[i+dwSize];
		lpBuf[i*2  ] = (TUint8)(byTwoNibs&0xF);
		lpBuf[i*2+1] = (TUint8)(byTwoNibs>>4);
	}

	if (bBinary)
	{ // load as binary
		if(DEBUG) fileLogs.Write(_L8("WriteStack binary.\n"));
		dwSize  = RPL_ObjectSize(lpBuf+16);
		dwAddress = RPL_CreateTemp(dwSize);
		if (dwAddress == 0) return S_ERR_BINARY;

		Nwrite(lpBuf+16, dwAddress, dwSize);
	}
	else
	{ // load as string
		if(DEBUG) fileLogs.Write(_L8("WriteStack string.\n"));
		TUint8 lpHead[5];
		dwSize *= 2;
		dwAddress = RPL_CreateTemp(dwSize+10);
		if (dwAddress == 0) return S_ERR_ASCII;

		Nunpack(lpHead,0x02A2C,5);
		Nwrite(lpHead,dwAddress,5);
		Nunpack(lpHead,dwSize+5,5);
		Nwrite(lpHead,dwAddress+5,5);
		Nwrite(lpBuf, dwAddress+10, dwSize);
	}
	RPL_Push(dwAddress);
	if(DEBUG) fileLogs.Write(_L8("WriteStack Ok.\n"));
	return S_ERR_NO;
}

void Engine::WriteStack(TReal value)
{
	TBuf8<23> strValue;
	TRealFormat realFormat;
	realFormat.iType = KRealFormatExponent | /*KUseSigFigs |*/ KAllowThreeDigitExp;
	realFormat.iWidth = 22;
	realFormat.iPlaces = 11;

	strValue.Num(value, realFormat);
	// const TText* ptr = strValue.PtrZ();
	TUint8* ptr = (TUint8*)strValue.PtrZ();

	TUint8 realData[3+12+1];

	// sign
	if(value < 0)
	{
		ptr++;
		realData[3+12] = 9;
	}
	else
		realData[3+12] = 0;

	// mantissa
	realData[3+11] = *ptr++ - '0';
	ptr++;
	realData[3+10] = *ptr++ - '0';
	realData[3+9]  = *ptr++ - '0';
	realData[3+8]  = *ptr++ - '0';
	realData[3+7]  = *ptr++ - '0';
	realData[3+6]  = *ptr++ - '0';
	realData[3+5]  = *ptr++ - '0';
	realData[3+4]  = *ptr++ - '0';
	realData[3+3]  = *ptr++ - '0';
	realData[3+2]  = *ptr++ - '0';
	realData[3+1]  = *ptr++ - '0';
	realData[3+0]  = *ptr++ - '0';

	// exponent
	ptr++;
	// TBool expNeg = (*ptr == '-')? ETrue : EFalse;
	TBool expNeg = (*ptr == '-');
	ptr++;
	TInt expData = *ptr++ - '0';
	expData = 10 * expData + *ptr++ - '0';
	if(*ptr)
		expData = 10 * expData + *ptr - '0';
	if(expNeg)
		expData = 1000 - expData;
	TBuf8<4> strExpNum;
	strExpNum.Num(expData);
	TBuf8<4+1> strExp;
	strExp.Justify(strExpNum, 4, ERight, '0');

	// const TText* expPtr = strExp.PtrZ();
	TUint8* expPtr = (TUint8*)strExp.PtrZ();
	expPtr++;
	realData[2] = *expPtr++ - '0';
	realData[1] = *expPtr++ - '0';
	realData[0] = *expPtr - '0';

	TUint32 dwLength, dwAddress;
	dwAddress = RPL_CreateTemp(5+3+12+1);
	TUint8 lpHead[5];
	Nunpack(lpHead,0x02933,5);
	Nwrite(lpHead,dwAddress,5);
	Nwrite(realData,dwAddress+5, 3+12+1);
	RPL_Push(dwAddress);
	if(DEBUG) fileLogs.Write(_L8("WriteStack real Ok.\n"));
}

TUint16 Engine::WriteStackInt(TUint8* lpBuf,TUint32 dwSize)
{
	TUint32  dwAddress, i;
	TBool Negatif = EFalse;

	if(DEBUG) fileLogs.Write(_L8("WriteStackInt debut.\n"));

	if(lpBuf[dwSize] == '-') Negatif = ETrue;
	for (i=0; i<dwSize; i++)
	{
		lpBuf[i] = lpBuf[dwSize+dwSize-i-1] - '0';
	}

	if(DEBUG) fileLogs.Write(_L8("WriteStack HP49 integer.\n"));
	TUint8 lpHead[5];

	if(Negatif) dwSize=dwSize-1;

	dwAddress = RPL_CreateTemp(dwSize+10+1);
	if (dwAddress == 0) return S_ERR_ASCII;
	Nunpack(lpHead,0x02614,5); // Integer
	Nwrite(lpHead,dwAddress,5);
	Nunpack(lpHead,dwSize+5+1,5);
	Nwrite(lpHead,dwAddress+5,5);
	Nwrite(lpBuf, dwAddress+10, dwSize);
	if(Negatif) Nunpack(lpHead,0x9,1); else Nunpack(lpHead,0x0,1);
	Nwrite(lpHead,dwAddress+10+dwSize,1);
	RPL_Push(dwAddress);
	if(DEBUG) fileLogs.Write(_L8("WriteStackInt Ok.\n"));
	return S_ERR_NO;
}

void Engine::ReadStack(TUint8* adr,TUint32 dwAddress,TUint32 dwSize)
{
	TUint8* lpData = adr;

	// copy data into clipboard buffer
	for (dwAddress += 5;dwSize-- > 0;dwAddress += 2,++lpData)
	{
		*lpData = Read2(dwAddress);
	}
	*lpData = 0;						// set end of string
}

void Engine::ReadStackInt(TUint8* adr,TUint32 dwAddress,TUint32 dwSize)
{
	TUint8* lpData = adr;

	dwAddress+=dwSize;
	dwAddress+=4;
	if(Read1(dwAddress)==9) *lpData='-'; else *lpData='+';
	dwAddress--;
	dwSize--;
	lpData++;
	for (;dwSize-- > 0;dwAddress--,++lpData)
	{
		*lpData = Read1(dwAddress)+'0';
	}
	*lpData = 0;		// set end of string
}

void Engine::ReadStack(TReal* realValue,TUint32 dwAddress)
{
	// 0123456789ABCDEF
	// EEEMMMMMMMMMMMMS

	TUint8 realData[3+12+1];
	Npeek(realData, dwAddress, 3+12+1);

	TReal sign = (realData[3+12] > 0)? -1 : 1;

	TReal mantissa = (TReal)realData[3+11];
	mantissa += (TReal)realData[3+10] / 1e01;
	mantissa += (TReal)realData[3+9]  / 1e02;
	mantissa += (TReal)realData[3+8]  / 1e03;
	mantissa += (TReal)realData[3+7]  / 1e04;
	mantissa += (TReal)realData[3+6]  / 1e05;
	mantissa += (TReal)realData[3+5]  / 1e06;
	mantissa += (TReal)realData[3+4]  / 1e07;
	mantissa += (TReal)realData[3+3]  / 1e08;
	mantissa += (TReal)realData[3+2]  / 1e09;
	mantissa += (TReal)realData[3+1]  / 1e10;
	mantissa += (TReal)realData[3+0]  / 1e11;

	TReal power = 10;
	TInt exponent = (TInt)realData[0];
	exponent += (TInt)realData[1] * 10;
	exponent += (TInt)realData[2] * 100;
	if(exponent > 499.0)
	{
		exponent = 1000 - exponent;
		power = 0.1;
	}
	for(;exponent > 0; --exponent)
		mantissa *= power;

	*realValue = sign * mantissa ;
}

void Engine::SkipTaggedData(TUint32* ptdwAddress)
{
	*ptdwAddress += Read2(*ptdwAddress) * 2 + 2; // length of tag string to skip
}

TBool Engine::IsRealString(TUint8* adr,TInt taille,TReal* value)
{
	if(DEBUG) fileLogs.Write(_L8("IsRealString.\n"));
	TBuf8<256> buffer;
	TInt size;

	//buffer.Zero();
	size = Min(255,taille);
	buffer.Copy(adr,size);
	buffer.SetLength(size);
	buffer.ZeroTerminate();
	//buffer.Trim();
	TLex8 lexer(buffer);
	return (lexer.Val(*value) == KErrNone) && lexer.Eos();
}


TUint Engine::LoadObject(TDesC& aFileName)
{
	RFs fs;
	RFile fileObject;
	TAny* adrAlloc;
	TBuf8<256> Buff1;
	TUint8* adr;
	TUint8* adrBuff;
	TUint taille;
	TInt dwObjectSize;
	TUint16   wError;

	if(fs.Connect() != KErrNone)
	{
		if(DEBUG) fileLogs.Write(_L8("LoadObject Connection impossible a FileServer !\n"));
		return 10;
	}

	if(fileObject.Open(fs,aFileName,EFileShareReadersOnly) != KErrNone)
	{
		fs.Close();
		if(DEBUG) fileLogs.Write(_L8("Fichier Objet introuvable !\n"));
		return 10;
	}
#ifndef _UNICODE
	if(DEBUG) fileLogs.Write(aFileName);
#endif
	if (fileObject.Size(dwObjectSize) != KErrNone)
	{
		fileObject.Close();
		fs.Close();
		if(DEBUG) fileLogs.Write(_L8("Erreur ouverture fichier objet !\n"));
		return 10;
	}

	adrAlloc = User::Alloc(dwObjectSize*2);
	if (adrAlloc == NULL) return 1;
	adr = (TUint8*)adrAlloc + dwObjectSize;

	Buff1.SetLength(256);
	adrBuff = (TUint8*)Buff1.Ptr();
	fileObject.Read(Buff1);
	taille = Buff1.Length();
	while(taille > 0) {
		Mem::Copy(adr,adrBuff,taille);
		adr += taille;
		fileObject.Read(Buff1);
		taille = Buff1.Length();
	}
	fileObject.Close();
	fs.Close();

	adr = (TUint8*)adrAlloc;
	wError = WriteStack(adr,dwObjectSize);
	User::FreeZ(adrAlloc);
	if (wError == S_ERR_BINARY)
	{
		if(DEBUG) fileLogs.Write(_L8("LoadObject : The HP48 has not enough free memory !\n"));
		return 2;
	}

	if (wError == S_ERR_ASCII)
	{
		if(DEBUG) fileLogs.Write(_L8("LoadObject : The HP48 has not enough free memory !\n"));
		return 2;
	}
	if(DEBUG) fileLogs.Write(_L8("LoadObject Ok.\n"));
	return 0;
}

TUint Engine::SaveObject(TDesC& aFileName)
{
	RFs fs;
	RFile fileObject;
	TBuf8<256> Buff1;
	TUint32   dwAddress;
	TUint32   dwLength;

	TUint cpt;
	TInt i;
	TBool erreur;
	_LIT8(KBinaryHeader48,"HPHP48-W");
	_LIT8(KBinaryHeader49,"HPHP49-W");

	dwAddress = RPL_Pick(1);
	if (dwAddress == 0)
	{
		return 1;
	}
	dwLength = (RPL_SkipOb(dwAddress) - dwAddress + 1) / 2;

	if(fs.Connect() != KErrNone)
	{
		if(DEBUG) fileLogs.Write(_L8("SaveObject : Connection impossible a FileServer !\n"));
		return 10;
	}
	fileObject.Replace(fs,aFileName,EFileWrite);

	if(cCurrentRomType!=3) fileObject.Write(KBinaryHeader48);
	else fileObject.Write(KBinaryHeader49);

	cpt = 0;
	erreur = EFalse;
	Buff1.SetLength(MIN(256,dwLength-cpt));
	while(cpt < dwLength && !erreur)
	{
		for(i=0;i<Buff1.Length();i++)
		{
			Buff1[i] = Read2(dwAddress);
			dwAddress+=2;
		}
		if(fileObject.Write(Buff1) != KErrNone) erreur = ETrue;
		cpt += Buff1.Length();
		Buff1.SetLength(MIN(256,dwLength-cpt));
	}
	fileObject.Close();
	fs.Close();
	if(erreur)
	{
		if(DEBUG) fileLogs.Write(_L8("SaveObject : Erreur ecriture disk !. \n"));
		return 10;
	}
	if(DEBUG) fileLogs.Write(_L8("SaveObject : Ok. \n"));

	return 0;
}


