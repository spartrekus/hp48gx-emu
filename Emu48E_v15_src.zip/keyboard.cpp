/*
 *   keyboard.c
 *
 *   This file is part of Emu48
 *
 *   Copyright (C) 1995 Sebastien Carlier
 *
 */

#include "engine.h"



TUint16 Engine::Keyboard_GetIR(void)			// 13.02.99 cg, make function static
{
	TUint16 r = 0;
	
	if (Chipset.out==0) return 0;
	if (Chipset.out&0x001) r|=Chipset.Keyboard_Row[0];
	if (Chipset.out&0x002) r|=Chipset.Keyboard_Row[1];
	if (Chipset.out&0x004) r|=Chipset.Keyboard_Row[2];
	if (Chipset.out&0x008) r|=Chipset.Keyboard_Row[3];
	if (Chipset.out&0x010) r|=Chipset.Keyboard_Row[4];
	if (Chipset.out&0x020) r|=Chipset.Keyboard_Row[5];
	if (Chipset.out&0x040) r|=Chipset.Keyboard_Row[6];
	if (Chipset.out&0x080) r|=Chipset.Keyboard_Row[7];
	if (Chipset.out&0x100) r|=Chipset.Keyboard_Row[8];
	return r;
}

void Engine::ScanKeyboard(TBool bReset)				// 02.09.98 cg, changed, add flag for key state reset
{
	// 02.09.98 cg, new, changed implementation
	// bReset = TRUE  -> Reset Chipset.in interrupt state register
	//          FALSE -> generate interrupt only for new pressed keys

	TBool bKbdInt;
	TUint16 wOldIn = Chipset.in;			// save old Chipset.in state

	//User::InfoPrint(_L("ScanKeyboard.\n"));

	UpdateKdnBit();						
	Chipset.dwKdnCycles = Chipset.cycles;

	// update keyboard only if timer is running
	if (Chipset.IORam[TIMER2_CTRL]&RUN)	// timer running
		Chipset.in = Keyboard_GetIR();	// update Chipset.in register
	else								// timer stopped, no keyboard update
		Chipset.in &= 0x1FF;			// IR[0:8], old keystate without ON key
	Chipset.in |= Chipset.IR15X;		// add ON key

	// interrrupt for any new pressed keys ?
	bKbdInt = (Chipset.in && (wOldIn & 0x1FF) == 0) || Chipset.IR15X || bReset;

	// 01.03.99 cg, bugfix, update keyboard interrupt pending flag
	Chipset.intd = Chipset.intd || (bKbdInt && !Chipset.intk);

	// keyboard interrupt enabled
	bKbdInt = bKbdInt && (Chipset.intk || Chipset.IR15X != 0) && Chipset.inte;

	if (Chipset.in != 0)				// any key pressed
	{
		// fileLogs.Write(_L8("ScanKeyboardEvent Chipset.in <> 0.\n"));
		if (bKbdInt)					// interrupt enabled
		{
			//if(DEBUG) fileLogs.Write(_L8("ScanKeyboardEvent bInterrupt.\n"));
			Chipset.SoftInt = ETrue;		// interrupt request
			bInterrupt = ETrue;			// exit emulation loop
		}
		// else fileLogs.Write(_L8("ScanKeyboardEvent interrupt disabled.\n"));

		if (Chipset.Shutdn)				// cpu sleeping
		{
			Chipset.wShutdnWake = ETrue;	// wake up from SHUTDN mode
			Chipset.Shutdn = EFalse;
			SpeedRef();
			//fileLogs.Write(_L8("ScanKeyboardEvent reveil Chipset : Active.\n"));
			iActive->Active();
		}
	}
	else
	{
		//fileLogs.Write(_L8("ScanKeyboardEvent Chipset.in = 0 (no key).\n"));
		Chipset.intd = FALSE;			// 01.03.99 cg, bugfix, no keyboard interrupt pending
	}
	return;
}

void Engine::KeyboardEvent(TBool bPress, TUint out, TUint in)
{
#if 0
	if(DEBUG)
	{
		if(bPress) fileLogs.Write(_L8("KeyboardEvent bPress = True.\n"));
		else fileLogs.Write(_L8("KeyboardEvent bPress = False.\n"));
	}
#endif

	if (nState != 0)
	{						// not in running state
		// fileLogs.Write(_L8("KeyboardEvent nState<>0.\n"));
		return;								// ignore key
	}
	if (in == 0x8000)						// ON key ?
	{
		// fileLogs.Write(_L8("KeyboardEvent On key.\n"));
		Chipset.IR15X = bPress?0x8000:0x0000; // refresh special ON key flag
	}
	else
	{
		// fileLogs.Write(_L8("KeyboardEvent key.\n"));
		if (bPress)							// key pressed 
		{
			//if(DEBUG) fileLogs.Write(_L8("KeyboardEvent key down.\n"));
			Chipset.Keyboard_Row[out] |= in; // set key marker in keyboard row
		}
		else
		{
			//if(DEBUG) fileLogs.Write(_L8("KeyboardEvent key up.\n"));
			Chipset.Keyboard_Row[out] &= (~in); // clear key marker in keyboard row
		}
	}
	ScanKeyboard(FALSE);					// 02.09.98 cg, changed, update Chipset.in register
	bKeySlow = FALSE;						// 18.11.98 cg, new, break key slow down
	//User::After(500000);								// 28.09.98 cg, hold key state for a definite time
	return;
}
