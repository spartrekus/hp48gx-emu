/*
 *   timer.c
 *
 *   This file is part of Emu48
 *
 *   Copyright (C) 1995 Sebastien Carlier
 *
 */

#include "engine.h"


inline TUint MAX2(TUint a, TUint b) {return (a>b)?a:b;} 

inline TUint MIN(TUint a, TUint b) {return (a<b)?a:b;}


void Engine::SetHP48Time()				// 06.10.97 cg, new, set date and time
{
	//SYSTEMTIME ts;
	TTime tst;
	TDateTime tsdt;
	TInt64   ticks, time;
	TUint32      dw;
	TUint16       crc, i;
	TUint8       p[4];


	//GetLocalTime(&ts);						// local time, _ftime() cause memory/resource leaks
	tst.HomeTime();
	tsdt=tst.DateTime();

	// calculate days until 01.01.1970
	dw = (TUint32) tsdt.Month() + 1; // +1 pour Epoc32
	if (dw > 2)
		dw -= 3L;
	else
	{
		dw += 9L;
		//--tsdt.wYear;
		tsdt.SetYear(tsdt.Year()-1);
	}
	dw = (TUint32)tsdt.Day() + 1 + (153L * dw + 2L) / 5L;  // + 1 pour Epoc32
	dw += (146097L * (((TUint32) tsdt.Year()) / 100L)) / 4L;
	dw +=   (1461L * (((TUint32) tsdt.Year()) % 100L)) / 4L;
	dw -= 719469L;

	// convert into seconds and add time
	dw = dw * 24L + (TUint32) tsdt.Hour();
	dw = dw * 60L + (TUint32) tsdt.Minute();
	dw = dw * 60L + (TUint32) tsdt.Second();

	// create timerticks = (s + ms) * 8192
	//ticks = ((LONGLONG) dw << 13) | (((LONGLONG) ts.wMilliseconds << 10) / 125);
	//ticks = TInt64((TInt)(dw << 13)).operator+( (TInt64((TInt)(tsdt.MicroSecond()/1000)).operator<<(10)).operator/(TInt64(125)) );
	ticks = TInt64((TInt)dw).operator<<(13).operator+( (TInt64((TInt)(tsdt.MicroSecond()/1000)).operator<<(10)).operator/(TInt64(125)) );

	ticks.operator+=( TInt64((TInt)UNIX_0_TIME).operator*(TInt64((TInt)0x100000)) );					// add offset ticks from year 0
	ticks.operator+=(TInt64((TInt)Chipset.t2));				// add actual timer2 value

	time = ticks;							// save for calc. timeout
	time.operator+=(OFF_TIME);						// add 10 min for auto off

	dw = RPLTIME;							// 30.09.98, bugfix, HP addresses for clock in port0
	crc = 0x0;								// reset crc value
	for (i = 0; i < 13; ++i, ++dw)			// write date and time
	{
		*p = (TUint8)(ticks.Low() & 0xf);
		crc = (crc >> 4) ^ (((crc ^ ((TUint16) *p)) & 0xf) * 0x1081);
		Chipset.Port0[dw] = *p;				// 30.09.98, bugfix, always store in port0
		ticks >>= 4;
	}

	Nunpack(p,crc,4);						// write crc
	memcpy(Chipset.Port0+dw,p,4);			// 30.09.98, bugfix, always store in port0

	dw += 4;								// HP addresses for timeout

	for (i = 0; i < 13; ++i, ++dw)			// write time for auto off
	{
		// 30.09.98, bugfix, always store in port0
		Chipset.Port0[dw] = (TUint8)(time.Low() & 0xf);
		time >>= 4;
	}

	Chipset.Port0[dw] = 0xf;				// 30.09.98, bugfix, always store in port0
	return;
}

TUint32 Engine::CalcT2()					// 21.04.98 cg, new, calculate timer2 value
{
	TTime tst;
	TInt64 lT2Act;
	TUint32 dwT2;				// get value from chipset
	TUint32 diff;
	//if(DEBUG) fileLogs.Write(_L8("CalcT2.\n"));
	if (bStarted)							// timer2 running
	{
		tst.HomeTime();
		lT2Act = tst.Int64();
		// calculate ticks since reference point
		diff = (((lT2Act.operator-(lT2Ref)).operator*(TInt64(T2_FREQ))).operator/(lFreq)).Low();
		dwT2 = Chipset.t2 - diff;
	}
	else
	{
		dwT2 = Chipset.t2;
	}
#if 0
	fileLogs.Write(_L8("t2 = "));
	strnum.NumUC(dwT2,EHex);
	fileLogs.Write(strnum);
	fileLogs.Write(_L8("\n"));
#endif
	return dwT2;
}

void Engine::CheckT1(TUint8 nT1)				// 25.11.98 cg, bugfix, changed implementation
{
	//if(DEBUG) fileLogs.Write(_L8("CheckT1.\n"));
	if ((nT1&8) == 0)						// timer1 MSB not set
	{
		Chipset.IORam[TIMER1_CTRL] &= ~SRQ;	// clear SRQ bit
		return;
	}

	// timer MSB is one and either INT or WAKE is set
	if (   (Chipset.IORam[TIMER1_CTRL]&WKE) 
	    || (Chipset.IORam[TIMER1_CTRL]&INT))
		Chipset.IORam[TIMER1_CTRL] |= SRQ;	// set SRQ

	// cpu not sleeping and T1 -> Interrupt
	if (   (!Chipset.Shutdn || (Chipset.IORam[TIMER1_CTRL]&WKE))
		&& (Chipset.IORam[TIMER1_CTRL]&INT))
	{
		Chipset.SoftInt = TRUE;
		bInterrupt = TRUE;
	}

	// cpu sleeping and T1 -> Wake Up
	if (Chipset.Shutdn && (Chipset.IORam[TIMER1_CTRL]&WKE))
	{
		Chipset.IORam[TIMER1_CTRL] &= ~WKE;	// clear WKE bit
		Chipset.wShutdnWake = ETrue;			// wake up from SHUTDN mode
		Chipset.Shutdn = EFalse;
		SpeedRef();
		iActive->Active();
	}
	return;
}

void Engine::CheckT2(TUint32 dwT2)				// 25.11.98 cg, bugfix, changed implementation
{
	//if(DEBUG) fileLogs.Write(_L8("CheckT2.\n"));
	if ((dwT2&0x80000000) == 0)				// timer2 MSB not set
	{
		Chipset.IORam[TIMER2_CTRL] &= ~SRQ;	// clear SRQ bit
		return;
	}

	// timer MSB is one and either INT or WAKE is set
	if (   (Chipset.IORam[TIMER2_CTRL]&WKE) 
	    || (Chipset.IORam[TIMER2_CTRL]&INT))
		Chipset.IORam[TIMER2_CTRL] |= SRQ;	// set SRQ

	// cpu not sleeping and T2 -> Interrupt
	if (   (!Chipset.Shutdn || (Chipset.IORam[TIMER2_CTRL]&WKE))
		&& (Chipset.IORam[TIMER2_CTRL]&INT))
	{
		Chipset.SoftInt = TRUE;
		bInterrupt = TRUE;
	}
	// cpu sleeping and T2 -> Wake Up
	if (Chipset.Shutdn && (Chipset.IORam[TIMER2_CTRL]&WKE))
	{
		Chipset.IORam[TIMER2_CTRL] &= ~WKE;	// clear WKE bit
		Chipset.wShutdnWake = ETrue;			// wake up from SHUTDN mode
		Chipset.Shutdn = EFalse;
		SpeedRef();
		iActive->Active();
	}
	return;
}

void Engine::RescheduleT2(TBool bRefPoint)	// 21.04.98 cg, add function parameter
{
	TUint uDelay;
	TTime tst;
	//if(DEBUG) fileLogs.Write(_L8("      RescheduleT2.\n"));
	if (T2run) delete uT2TimerId;
	if (bRefPoint)							// save reference time
	{
		tst.HomeTime();
		lT2Ref = tst.Int64();
		dwT2Init = (tst.Int64().operator/(TInt64(1000))).Low(); // ancien timer

		//dwT2Ticks  = dwT2Init; // ancien timer
		dwT2Ticks = Chipset.t2;
		uDelay = Chipset.t2;				// timer value for delay
	}
	else									// called without new refpoint, restart t2 with actual value
	{
		uDelay = CalcT2();					// actual timer value for delay
	}

	//uDelay = Chipset.t2;				// timer value for delay
	uDelay &= 0x7FFFFFFF;					// 24.11.98 cg, bugfix, execute timer2 event when MSB change
#if 0
	fileLogs.Write(_L8("      uDelay = "));
	strnum.NumUC(uDelay);
	fileLogs.Write(strnum);
	fileLogs.Write(_L8("\n"));
#endif

	uDelay >>= 3;							// timer delay in ms

	uDelay = MAX2(1,uDelay);
	//uDelay = MIN(0x20c400,uDelay);
	if(uDelay > 0x20c400)
	{
		bOutRange = ETrue;
		uDelay = 0x20c400;
	}
	else bOutRange = EFalse;

	uT2TimerId=CPeriodic::NewL(8);
	uT2TimerId->Start(TTimeIntervalMicroSeconds32(uDelay*1000),TTimeIntervalMicroSeconds32(5000000),TCallBack(TickT2,this));
	T2run = TRUE;
	// fileLogs.Write(_L8("      RescheduleT2 Ok.\n"));
	return;
}

void Engine::AbortT2()
{
	// fileLogs.Write(_L8("AbortT2.\n"));
	if (T2run)
	{
		// fileLogs.Write(_L8("AbortT2 T2run.\n"));
		delete uT2TimerId;
		T2run = FALSE;
	}
	// fileLogs.Write(_L8("AbortT2 Ok.\n"));
	return;
}


TInt Engine::TickT1(TAny* aObject)
{
	((Engine*)aObject)->TimeProcT1();
	return 1;
}

TInt Engine::TickT2(TAny* aObject)
{
	((Engine*)aObject)->TimeProcT2();
	return 1;
}

void Engine::TimeProcT1()
{
	//fileLogs.Write(_L8("TimeProcT1.\n"));
	if (!bStarted) return;
	if (T1run)
	{
		Chipset.t1 = (Chipset.t1-1)&0xF;
		CheckT1(Chipset.t1);
	}
	// fileLogs.Write(_L8("TimeProcT1 Ok.\n"));
}

void Engine::TimeProcT2()
{
	if(DEBUG) fileLogs.Write(_L8("TimeProcT2.\n"));
	if (!bStarted) return;
	if (T2run)
	{
		if (!bOutRange)
		{
			Chipset.t2 = CalcT2();		// calculate new timer2 value
			CheckT2(Chipset.t2);
		}
		RescheduleT2(!bOutRange);
	}
	// fileLogs.Write(_L8("TimeProcT2 Ok.\n"));
}

void Engine::StartTimers(void)
{
	// fileLogs.Write(_L8("      StartTimers.\n"));
	if (bStarted) return;
	if (Chipset.IORam[TIMER2_CTRL]&RUN)
	{
		bStarted = TRUE;
		CheckT1(Chipset.t1);				// check for timer1 interrupts
		CheckT2(Chipset.t2);				// check for timer2 interrupts
		uT1TimerId=CPeriodic::NewL(10);
		uT1TimerId->Start(TTimeIntervalMicroSeconds32(T1_FREQ*1000),TTimeIntervalMicroSeconds32(T1_FREQ*1000),TCallBack(TickT1,this));
		T1run = TRUE;
		RescheduleT2(ETrue);
	}
	return;
}


void Engine::StopTimers(void)
{

	if(DEBUG) fileLogs.Write(_L8("      StopTimers.\n"));
	if (!bStarted) return;
	if (T1run)
	{

		delete uT1TimerId;
		T1run = FALSE;
	}
	if (T2run)
	{
		Chipset.t2 = CalcT2();
		AbortT2();
	}
	bStarted = FALSE;
	if(DEBUG) fileLogs.Write(_L8("      StopTimers Ok.\n"));
	return;
}


TUint32 Engine::ReadT2()
{
	TUint32 dwT2;
	TUint32 dwNow;
	TTime tst;
	if (!bStarted)
	{
		dwT2 = Chipset.t2;
	}
	else
	{
#if 1
		tst.HomeTime();
		dwNow = (tst.Int64().operator/(TInt64(1000))).Low();
		if (dwNow == dwT2Ticks)
		{
			if (dwT2Step < 128)
			{
				dwT2Step++;
			}
			dwT2 = Chipset.t2-(8*(dwNow-dwT2Init)+dwT2Step);
		}
		else
		{
			dwT2Step = 0;
			dwT2Ticks = dwNow;
			dwT2 = Chipset.t2-8*(dwNow-dwT2Init);
		}
#endif
#if 0
		if(dwT2Ticks > 0) dwT2Ticks--;
		dwT2 = dwT2Ticks;
#endif
	}
	CheckT2(dwT2);
	return dwT2;
}

void Engine::SetT2(TUint32 dwValue)
{
	if(T2run) AbortT2();
	Chipset.t2 = dwValue;
	CheckT2(Chipset.t2);
	if (bStarted) RescheduleT2(ETrue);
	return;
}

TUint8 Engine::ReadT1()
{
	TUint8 nT1;
	nT1 = Chipset.t1;					// read timer1 value
	CheckT1(nT1);						// 25.11.98 cg, new, update timer1 control bits
	return nT1;
}

void Engine::SetT1(TUint8 byValue)
{
	if (Chipset.t1 == byValue)				// same value doesn't restart timer period
		return;
	if (T1run)
	{
		delete uT1TimerId;
		uT1TimerId = NULL;
		T1run = EFalse;
	}
	Chipset.t1 = byValue&0xF;			// set new timer1 value
	CheckT1(Chipset.t1);				// 25.11.98 cg, readded, test timer1 control bits
	uT1TimerId=CPeriodic::NewL(10);
	uT1TimerId->Start(TTimeIntervalMicroSeconds32(T1_FREQ*1000),TTimeIntervalMicroSeconds32(T1_FREQ*1000),TCallBack(TickT1,this));
	T1run = TRUE;
	return;
}
