#ifndef __ENGINE_H
#define __ENGINE_H
#define __ER5__

#include "kml.h"
#include "types.h"
#include <libc/string.h>
#include <e32std.h>
#include <e32svr.h>

// _LIT(KFicRomSx,"System\\Apps\\Emu48E\\sx.rom");
// _LIT(KFicRomGx,"System\\Apps\\Emu48E\\gx.rom");
// _LIT(KFicRom49G,"System\\Apps\\Emu48E\\49g.rom");
// _LIT(KRomPath,"System\\Apps\\Emu48E\\");
_LIT(KFicRomExt,".rom");
_LIT(KFicRomSx,"sx.rom");
_LIT(KFicRomGx,"gx.rom");
_LIT(KFicRom49G,"49g.rom");
_LIT(KFicRamP0,"System\\Apps\\Emu48E\\ramP0.bak");
_LIT(KFicRamP1,"System\\Apps\\Emu48E\\ramP1.bak");
_LIT(KFicRamP2,"System\\Apps\\Emu48E\\ramP2.bak");
_LIT(KFicChipset,"System\\Apps\\Emu48E\\chipset.bak");
_LIT(KFicLogs,"System\\Apps\\Emu48E\\logs.txt");
_LIT(KAnnuncBitmap,"System\\Apps\\Emu48E\\annunc.mbm");
_LIT(Khp48lib,"System\\Apps\\Emu48E\\hp48.lib");
_LIT(KDriveC,"c:\\");
_LIT(KDriveD,"d:\\");
_LIT(KDriveE,"e:\\");

#define DEBUG ETrue
#define S_ERR_NO        0					// 11.05,98 cg, new, stack errorcodes
#define S_ERR_BINARY    1
#define S_ERR_ASCII     2

#define NO_SERIAL       "disabled"			// 22.05.98 cg, new, serial port not open

#define PORT_CLOSE      0					// 20.05.98 cg, new, COM port status
#define PORT_WIRE       1
#define PORT_IR         2

#define HP_MNEMONICS	FALSE				// 10.11.98 cg, new, disassembler mnenomics mode
#define CLASS_MNEMONICS	TRUE

#define MEM_MAP		0						// 10.11.98 cg, new, memory module definition
#define MEM_ROM		1
#define MEM_RAM		2
#define MEM_PORT1	3
#define MEM_PORT2	4

// 0x0f Card Status [P2W P1W P2C P1C]
#define P2W			0x08					// High when Port2 writeable
#define P1W			0x04					// High when Port1 writeable
#define P2C			0x02					// High when Card in Port2 inserted
#define P1C			0x01					// High when Card in Port1 inserted
#define PORT1_PRESENT	((cCurrentRomType==1)?P1C:P2C)
#define PORT1_WRITE		((cCurrentRomType==1)?P1W:P2W)
#define PORT2_PRESENT	((cCurrentRomType==1)?P2C:P1C)
#define PORT2_WRITE		((cCurrentRomType==1)?P2W:P1W)

// I/O addresses without mapping offset
#define BITOFFSET   0x00					// Display bit offset and DON
#define CRC         0x04					// Crc (16 bit, LSB first)
#define ANNCTRL		0x0b					// Annunciator Control (2 nibble)
#define BAUD		0x0d					// Baudrate (Bit 2-0)
#define CARDCTL		0x0e					// card control
#define CARDSTAT	0x0f					// card status
#define IOC			0x10					// IO CONTROL
#define RCS			0x11					// RCS
#define TCS			0x12					// TCS
#define CRER		0x13					// CRER
#define RBR_LSB		0x14					// RBR low nibble
#define RBR_MSB		0x15					// RBR high nibble
#define TBR_LSB		0x16					// TBR low nibble
#define TBR_MSB		0x17					// TBR high nibble
#define	SRQ1		0x18					// SRQ1
#define	SRQ2		0x19					// SRQ2
#define IR_CTRL		0x1a					// IR CONTROL
#define LCR			0x1c					// Led Control Register
#define LINECOUNT	0x28					// Display Line Counter

// 0x0e Card Control [ECDT RCDT SMP SWINT]
#define ECDT		0x08					// Enable Card Detect
#define RCDT		0x04					// Run Card Detect
#define SMP			0x02					// Set module pulled
#define SWINT		0x01					// Software Interrupt

// 0x19 Service Request Register 2 [KDN NINT2 NINT LSRQ]
#define KDN			0x08					// Bit set when ON Key or Key Interrupt
#define NINT2		0x04					// State of NINT2
#define NINT		0x02					// State of NINT
#define LSRQ		0x01					// LED driver pulls NINT2

// 0x1c Led Control Register [LED ELBE LBZ LBF]
#define LED			0x08					// Turn on LED
#define ELBE		0x04					// Enable Interrupt on Led Buffer empty
#define LBZ			0x02					// Led Port Busy
#define LBF			0x01					// Led Buffer Full

// 0x28 Display Line Counter LSB [LC3 LC2 LC1 LC0] 
#define LC3			0x08					// LC3 - Line Counter Bit3
#define LC2			0x04					// LC2 - Line Counter Bit2
#define LC1			0x02					// LC1 - Line Counter Bit1
#define LC0			0x01					// LC0 - Line Counter Bit0

// 0x29 Display Line Counter MSB [DA19 M32 LC5 LC4]
#define DA19		0x08					// Drive A[19]
#define M32			0x04					// Multiplex 32 way
#define LC5			0x02					// LC5 - Line Counter Bit5
#define LC4			0x01					// LC4 - Line Counter Bit4


// ----------------------------------------------------------------
// engine
// ----------------------------------------------------------------
// HST bits
#define XM 1
#define SB 2
#define SR 4

#define MP 8

#define w Chipset
#define PCHANGED  ((void)(F_s[0]=w.P,F_l[1]=w.P+1))
#define GOYES3    {if(w.carry)goto o_goyes3;else{w.pc+=2;continue;}}
#define GOYES5    {if(w.carry)goto o_goyes5;else{w.pc+=2;continue;}}
#define INTERRUPT ((void)(w.SoftInt=TRUE,bInterrupt=TRUE))

// --------------- Display
#define LCD1_ROW    144
#define LCD2_ROW    288
#define LCD3_ROW    576						// 24.08.98 cg, new, X4 display

// --------------- Timer --------------------------------------------

#define SAMPLE    16384						// 23.04.98 cg, new, speed adjust sample frequency
// 23.04.98 cg, new, cpu cycles for interval
#define T2CYCLES  ((cCurrentRomType==1)?dwSXCycles:dwGXCycles)

#define AUTO_OFF    10						// 25.02.98 cg, new, Time in minutes for 'auto off'

// 25.02.98 cg, new, Ticks for 01.01.1970 00:00:00
#define UNIX_0_TIME	0x1cf2e8f8

// 25.02.98 cg, new, Ticks for 'auto off'
#define OFF_TIME	((TInt64) (AUTO_OFF * 60) << 13)

// 30.09.98 cg, new, memory address for clock and auto off
// S(X) = 0x70052-0x70070, G(X) = 0x80058-0x80076
#define RPLTIME ((cCurrentRomType==1)? 0x52 : 0x58)

#define T1_FREQ		62		// 10.11.98 cg, new, Timer1 1/frequency in ms
#define T2_FREQ		8192					// 06.04.98 cg, new, Timer2 frequency

// 27.02.98 cg, new, Timer definitions

// Timer addresses without mapping offset
#define TIMER1_CTRL	0x2e					// Timer1 Control
#define TIMER2_CTRL	0x2f					// Timer2 Control
#define TIMER1		0x37					// Timer1 (4 bit)
#define TIMER2		0x3f					// Timer2 (32 bit, LSB first)

// 0x2e Timer1 Control [SRQ WKE INT XTRA]
#define SRQ			0x08					// Service request
#define WKE			0x04					// Wake up
#define INT			0x02					// Interrupt
#define XTRA		0x01					// Extra function

// 0x2f Timer2 Control [SRQ WKE INT RUN]
#define SRQ			0x08					// Service request
#define WKE			0x04					// Wake up
#define INT			0x02					// Interrupt
#define RUN			0x01					// Timer run

// --------- Mops -------------------------------------------------
// 30.06.98 cg, new, on mapping boundary adjusted base addresses
#define P0MAPBASE ((TUint8)(Chipset.P0Base & ~Chipset.P0Size))
#define P1MAPBASE ((TUint8)(Chipset.P1Base & ~Chipset.P1Size))
#define P2MAPBASE ((TUint8)(Chipset.P2Base & ~Chipset.P2Size))
#define BSMAPBASE ((TUint8)(Chipset.BSBase & ~Chipset.BSSize))

// defines for reading an open data bus
#define READEVEN  0x0D
#define READODD   0x0E

// values for mapping area
enum MMUMAP { M_IO, M_ROM, M_RAM, M_P1, M_P2, M_BS };

//  ----------- External ------------------------------------------
// 02.02.98 cg, new, memory address for flags -53 to -56
#define SFLAG53_56 ((cCurrentRomType!=3)? ((cCurrentRomType==1)? 0x706D2 : 0x80850) : 0x80F0F)


// ------------ RPL ------------------------------------------------
#define TEMPOB   ((cCurrentRomType==1)?0x7056A:0x806E9)
#define TEMPTOP  ((cCurrentRomType==1)?0x7056F:0x806EE)
#define RSKTOP   ((cCurrentRomType==1)?0x70574:0x806F3)
#define DSKTOP   ((cCurrentRomType==1)?0x70579:0x806F8)
#define AVMEM    ((cCurrentRomType!=3)?((cCurrentRomType==1)?0x7066E:0x807ED):0x80E9B)
#define INTRPPTR ((cCurrentRomType!=3)?((cCurrentRomType==1)?0x705B0:0x8072F):0x8076B)

// HST bits
#define XM 1
#define SB 2
#define SR 4
#define MP 8

// Fields start and length

#define NFunpack(a, b, f) Nunpack((a)+F_s[f], b, F_l[f])
#define NFread(a, b, f)   Nread((a)+F_s[f], b, F_l[f])
#define NFwrite(a, b, f)  Nwrite((a)+F_s[f], b, F_l[f])
#define NFcopy(a, b, f)   memcpy((a)+F_s[f], (b)+F_s[f], F_l[f])
#define NFxchg(a, b, f)   Nxchg((a)+F_s[f], (b)+F_s[f], F_l[f])
#define NFadd(a, b, f)    Nadd((a)+F_s[f], (b)+F_s[f], F_l[f])
#define NFsub(a, b, f)    Nsub((a)+F_s[f], (b)+F_s[f], F_l[f])
#define NFrsub(a, b, f)   Nrsub((a)+F_s[f], (b)+F_s[f], F_l[f])
#define NFand(a, b, f)    Nand((a)+F_s[f], (b)+F_s[f], F_l[f])
#define NFor(a, b, f)     Nor((a)+F_s[f], (b)+F_s[f], F_l[f])
#define NFzero(a,f)       memset((a)+F_s[f], 0, F_l[f])
#define NFpack(a, f)      Npack((a)+F_s[f], F_l[f])
#define NFinc(a, f)       Ninc(a, F_l[f], F_s[f])				// 24.03.98 cg, changed
#define NFdec(a, f)       Ndec(a, F_l[f], F_s[f])				// 24.03.98 cg, changed
#define NFnot(a, f)       Nnot((a)+F_s[f], F_l[f])
#define NFneg(a, f)       Nneg((a)+F_s[f], F_l[f])
#define NFsl(a, f)        Nsl((a)+F_s[f], F_l[f])
#define NFsr(a, f)        Nsr((a)+F_s[f], F_l[f])
#define NFsrb(a, f)       Nsrb((a)+F_s[f], F_l[f])
#define TFe(a, b, f)      Te((a)+F_s[f], (b)+F_s[f], F_l[f])
#define TFa(a, b, f)      Ta((a)+F_s[f], (b)+F_s[f], F_l[f])
#define TFb(a, b, f)      Tb((a)+F_s[f], (b)+F_s[f], F_l[f])
#define TFz(a, f)         Tz((a)+F_s[f], F_l[f])
#define TFne(a, b, f)     Tne((a)+F_s[f], (b)+F_s[f], F_l[f])
#define TFae(a, b, f)     Tae((a)+F_s[f], (b)+F_s[f], F_l[f])
#define TFbe(a, b, f)     Tbe((a)+F_s[f], (b)+F_s[f], F_l[f])
#define TFnz(a, f)        Tnz((a)+F_s[f], F_l[f])



const TUint16 crc_table[16] =
		{
		0x0000, 0x1081, 0x2102, 0x3183, 0x4204, 0x5285, 0x6306, 0x7387,
		0x8408, 0x9489, 0xA50A, 0xB58B, 0xC60C, 0xD68D, 0xE70E, 0xF78F
		};

class Engine;
class Emu48View;

// ----------------------------------------------------------
// ----------- ActiveEngine ---------------------------------
class ActiveEngine : public CActive
{
public:
	ActiveEngine(Engine* aEngine);
	ActiveEngine::~ActiveEngine();
	void Start();
	void Active();
private:
	void DoCancel();
	void RunL();
private:
	Engine* iEngine;
	TBool Actif;
};

// ----------- Engine -------------------------------
class Engine
{
public:
	Engine::Engine();
	~Engine();
	void FocusChanged();
	TBool Init(TBool memAlloc);
	void InitLogs();
	void WorkerThread();
	void SpeedRef();
	void ResetCalc();

	CHIPSET Chipset;
	Annunciator pAnnunciator[6];
	TUint nState;
	TUint nNextState;
	TBool bInterrupt;
	TInt cCurrentRomType;
	TInt zoom;
	ActiveEngine* iActive;
	Emu48View* iView;

	// kml
	TBool bPort2Plugged;

	// display.cpp
	void InitLcd(TBool LcdAlloc);
	void SupprimeLcd();
	void UpdateContrast(TUint8 byContrast);
	TBool InitAnnunciator(TBool chargeBmp);
	void UpdateDisplayPointers(void);


	void UpdateMainDisplay(TBool Update);
	void UpdateMenuDisplay(TBool Update);
	void UpdateAnnunciators(TBool Update);
	TUint nLcdX;
	TUint nLcdY;
	TUint nLcdDoubled;
	TInt RedrawMode;
	CFbsBitmap* hLcdBitmap;
	TBitmapUtil* hLcdBitmapUtil;
	CFbsBitmap* hAnnuncBitmap;

#if 0
	CFbsBitmap* hLcdBitmap2; // testNetbook
	TBitmapUtil* hLcdBitmapUtil2; // testNetbook
#endif
	TUint8* pbyLcd;
	TUint8* FBLcd;
	TUint8* FBAdr;
	TBool FBValid;
	TInt DispMode; // 1:4bpp, 2:8bpp
	TBool FBAffiche;
	TBool Focus;
	TBool FocusView;
	TBool FocusUi;
	//TBool FBDec;
	TInt nFBX;
	TInt nFBY;
	TInt n2FBX;
	TInt n4FBX;

	// Keyboard
	void KeyboardEvent(TBool bPress, TUint out, TUint in);

	// Files
	TBuf<3> DefaultDrive;
	TBuf<3> DefaultDriveBak;
	TBuf<150> RomFileName;
	TBool SaveP0();
	TBool SaveP1();
	TBool SaveP2();
	TBool SaveChipset();
	TBool SaveRom();
	TBool LoadP0();
	TBool LoadP1();
	TBool LoadP2();
	TBool LoadChipset();
	TBool Recharger();


	TBool SuppSauvegarde();

	// Timers
	void StartTimers();
	void StopTimers();

	// Mops
	TUint32   Read5(TUint32 d);
	TUint8 div4096;

	//RPL
	TUint LoadObject(TDesC& aFileName);
	TUint SaveObject(TDesC& aFileName);
	TUint16 WriteStack(TUint8* lpBuf,TUint32 dwSize);
	TUint16 WriteStackInt(TUint8* lpBuf,TUint32 dwSize);
	void WriteStack(TReal value);
	TBool IsRealString(TUint8* adr,TInt taille,TReal* value);
	void ReadStack(TUint8* adr,TUint32 dwAddress,TUint32 dwSize);
	void ReadStackInt(TUint8* adr,TUint32 dwAddress,TUint32 dwSize);
	void ReadStack(TReal* value,TUint32 dwAddress);
	void SkipTaggedData(TUint32* ptdwAddress);
	TUint32 RPL_Pick(TUint l);

private:
	void AdjKeySpeed(void);
	void SetSpeed(TBool bAdjust);
	void UpdateKdnBit(void);
	RFs fsLogs;
	RFile fileLogs;
	TBuf<80> filename;
	TAny* adrCellP0;
	TAny* adrCellP1;
	TAny* adrCellP2;
	TInt cpt1;
	TBuf8<16> strnum;
	TBool bAlwaysDisplayLog;
	TUint uTimer1Period;
	TBool bKeySlow;
	TBool bRealSpeed;
	TText8 szSerialWire[16];
	TText8 szSerialIr[16];
	TUint32 dwSXCycles;
	TUint32 dwGXCycles;
	TBool bCommInit;
	TUint32 dwOldCyc;
	TUint32 dwSpeedRef;
	TUint32 dwTickRef;

	// Kml
	void InitChipset();
	TBool InitPorts(TBool PortsAlloc);
	TBool bPressed;				// 01.10.97 cg, no key pressed

	// display
	void WriteToMainDisplay(TUint8* a, TUint32 d, TUint s);
	void WriteToMenuDisplay(TUint8* a, TUint32 d, TUint s);
	void DrawAnnunciator(TUint nId, TBool bOn);
	TUint8 Buf[36];
	TBool bScreenIsClean;
	TUint16 Pattern[16];
	TUint32 Pattern2[16];

	// Files
	TUint16 CrcPort2();
	TBool MapRom();
	void UnmapRom(void);
	TUint8* pbyRom;
	TBool bBackup;
	TInt dwRomSize;
	RChunk hRomMap;
	TUint8* pbyPort2;
	TBool bPort2Writeable;
	TBool bPort2IsShared;
	TUint32 dwPort2Size;
	TUint32 dwPort2Mask;

	// Timer
	void SetHP48Time();
	void CheckT1(TUint8 nT1);
	void CheckT2(TUint32 dwT2);
	TUint32 CalcT2();
	TUint32 ReadT2();
	void SetT2(TUint32 dwValue);
	TUint8 ReadT1();
	void SetT1(TUint8 byValue);
	void RescheduleT2(TBool bRefPoint);
	//void RescheduleT2();
	void AbortT2();
	static TInt TickT1(TAny*);
	static TInt TickT2(TAny*);
	void TimeProcT1();
	void TimeProcT2();
	CPeriodic* uT1TimerId;
	CPeriodic* uT2TimerId;

	
	TUint uT1Period;
	TUint32 dwT2Init;
	TUint32 dwT2Step;
	TUint32 dwT2Ticks;

	TBool bOutRange;
	//TBool bAccurateTimer;
	TInt64 lT2Ref;

	TBool T1run;
	TBool T2run;
	TBool  bStarted;
	TInt64 lFreq;
	
	// mops
	TBool bFlashRomArray;					// flag ROM mode
	TUint8* pbyRomView[2]; // HP49G ROM views
	enum MMUMAP MapData(TUint32 d);
	void RomSwitch(TUint32 adr);
	TUint8 F4096Hz();
	TUint32 f4096;
	void MapP0(TUint8 a, TUint8 b);
	void MapBS(TUint8 a, TUint8 b);
	void    Map(TUint8 a, TUint8 b);
	void MapP1(TUint8 a, TUint8 b);
	void MapP2(TUint8 a, TUint8 b);
	void MapROM(TUint8 a, TUint8 b);
	void    Config(void);
	void    Uncnfg(void);
	void    Reset(void);
	void    C_Eq_Id(void);
	void    Npeek(TUint8 *a, TUint32 d, TUint s);
	void    Nread(TUint8 *a, TUint32 d, TUint s);
	void    Nwrite(TUint8 *a, TUint32 d, TUint s);
	TUint8    Read1(TUint32 d);
	TUint8    Read2(TUint32 d);
	void    Write5(TUint32 d, TUint32 n);
	void    IOBit(TUint32 d, TUint8 b, TBool s);// 24.02.99 cg, set/clear bit in I/O section
	void    ReadIO(TUint8 *a, TUint32 b, TUint32 s);
	void    WriteIO(TUint8 *a, TUint32 b, TUint32 s);

	inline void UpCRC(TUint8 nib)
	{
		Chipset.crc = (TUint16)((Chipset.crc>>4)^crc_table[(Chipset.crc^nib)&0xf]);
	}

	TUint8 byVblRef;					// 14.01.99 cg, new, VBL stop reference
	TBool    ioc_acc;						// 17.05.98 cg, flag ioc changed
	TBool    ir_ctrl_acc;					// 17.05.98 cg, flag ir_ctl changed
	TUint8*  RMap[256];
	TUint8*  WMap[256];
	TUint F_s[16];
	TUint F_l[16];

	// keyboard
	TUint16 Keyboard_GetIR(void);			// 13.02.99 cg, make function static
	void ScanKeyboard(TBool bReset);		// 02.09.98 cg, add flag for key state reset

	// External
	void External(CHIPSET* w);

	// RPL
	TUint32 RPL_SkipOb(TUint32 d);
	TUint32 RPL_ObjectSize(TUint8 *o);
	TUint32 RPL_CreateTemp(TUint32 l);
	void RPL_Replace(TUint32 n);
	void RPL_Push(TUint32 n);
	// fontions inline

#include "ops.h"

inline TUint8* FASTPTR(TUint32 d)
{
	// 17.12.98 cg, bugfix, code is running in IO area as well
	if ((Chipset.IOCfig)&&((d&0xFFFC0)==Chipset.IOBase))
		return Chipset.IORam+d-Chipset.IOBase;

	return RMap[d>>12]+(d&0xFFF);
}



inline void CheckSerial(void)		// 17.05.98 cg, new function
						// 25.02.99 cg, changed, inline coded now

{
	if (ioc_acc)							// IOC changed
	{
		ioc_acc = EFalse;

		// COM port closed and serial on
/*

		if (bCommInit == EFalse && (Chipset.IORam[IO_CTRL] & SON) != 0)
		{
			CommOpen(szSerialWire,szSerialIr); // open COM ports
			bCommInit = CommConnect() != PORT_CLOSE;
		}

		// COM port opend and serial off
		if (bCommInit == TRUE && (Chipset.IORam[IO_CTRL] & SON) == 0)
		{
			CommClose();					// close COM port
			bCommInit = EFalse;
		}

		// Interrupt on recv buffer full and receive buffer full
		if ((Chipset.IORam[IO_CTRL] & ERBF) && (Chipset.IORam[RCS] & RBF))
		{
			Chipset.Shutdn = EFalse;
			INTERRUPT;
		}
*/
	}
}

inline void AdjustSpeed(void)		// 23.04.98 cg, new, adjust emulation speed
{
	if (bRealSpeed || bKeySlow)				// 18.11.98 cg, changed, slow down
	{
		// cycles elapsed for next check
		if (Chipset.cycles-dwOldCyc >= T2CYCLES)
		{
			TTime tst;
			TInt64 dwTime;
			do
			{
				tst.HomeTime();
				dwTime = tst.Int64()/1000;
			}
			while(dwTime.Low()-dwSpeedRef <= dwTickRef);
			dwOldCyc += T2CYCLES;			// adjust cycles reference
			dwSpeedRef += dwTickRef;		// adjust reference time
		}
	}
	return;
}



}; // declaration class Engine

#endif
