#include <iostream.h> 
#include <fstream.h>
int main(int argc, char **argv)
{
    char octet,carasc1,carasc2;
	
    ifstream inFile;
    ofstream outFile;
    if (argc < 3)
    {
        cout << "Usage: conv49 ROM_source ROM_Emu48E\n";
        cout << "Example: conv49 rom.49g 49g.rom\n";
        return 0;
    }
    inFile.open(argv[1], ios::in | ios::binary);
    if (!inFile)
    {
        cout << "Unable to open the file " << argv[1] << endl;
        return 1;
    }
    outFile.open(argv[2], ios::out | ios::binary);
    if (!outFile)
    {
        cout << "Unable to open the file " << argv[2] << endl;
        return 1;
    }

	inFile.read(&carasc1,1);
	inFile.read(&carasc2,1);

	while (!inFile.eof())
	{
		octet = carasc1 | (carasc2<<4);
		outFile.write(&octet,1);

		inFile.read(&carasc1,1);
		inFile.read(&carasc2,1);
	}
	inFile.close();
	outFile.close();
	return 0;
}
