/*
 *   types.h
 *
 *   This file is part of Emu48
 *
 *   Copyright (C) 1995 Sebastien Carlier
 *
 */
#ifndef __TYPES_H
#define __TYPES_H

#include <w32std.h>

typedef struct
{
	TInt	type;

	TUint32	Port0Size;						// real size of module im KB
	TUint32	Port1Size;						// real size of module im KB
	TUint32	Port2Size;						// 27.06.98 cg, not used any more
	TUint8*  Port0;
	TUint8*  Port1;
	TUint8*  Port2;

	TUint32   pc;
	TUint32	d0;
	TUint32	d1;
	TUint32	rstkp;
	TUint32	rstk[8];
	TUint8    A[16];
	TUint8    B[16];
	TUint8    C[16];
	TUint8    D[16];
	TUint8    R0[16];
	TUint8    R1[16];
	TUint8    R2[16];
	TUint8    R3[16];
	TUint8    R4[16];
	TUint8    ST[4];
	TUint8    HST;
	TUint8    P;
	TUint16    out;
	TUint16	in;
	TBool	SoftInt;
	TBool	Shutdn;
	TBool    mode_dec;
	TBool	inte;							// interrupt status flag (FALSE = int in service)
	TBool	intk;							// 1 ms keyboard scan flag (TRUE = enable)
	TBool	intd;							// keyboard interrupt pending (TRUE = int pending)
	TBool	carry;

	TUint16    crc;
	TUint16	wPort2Crc;						// 21.02.99 cg, new, fingerprint of port2
	TUint32	dwKdnCycles;					// 25.02.99 cg, cpu cycles at start of 1ms key handler
	TBool    Port1_Writeable;
	TBool    Port2_Writeable;				// 30.05.98 cg, not used
	TUint    Bank_FF;						// save state of HP48GX port2 or state of HP49G ROM FF
	// TUint    Port2_Bank;						// 15.12.98 cg, new, save state of GX port2 FF
	TUint    Port2_NBanks;					// 30.05.98 cg, not used
	TUint8    cards_status;
	TUint8    IORam[64];						// I/O hardware register
	TUint    IOBase;							// address of I/O modules page 
	TBool    IOCfig;							// I/O module configuration flag
	TUint8    P0Base, BSBase, P1Base, P2Base;	// address of modules first 2KB page 
	TUint8    P0Size, BSSize, P1Size, P2Size;	// mapped size of module in 2KB
	TUint8    P0End,  BSEnd,  P1End,  P2End;	// address of modules last 2KB page
	TBool    P0Cfig, BSCfig, P1Cfig, P2Cfig;	// module address configuration flag
	TBool    P0Cfg2, BSCfg2, P1Cfg2, P2Cfg2;	// module size configuration flag

	TUint8    t1;
	TUint32   t2;
	TBool    wShutdnWake;					// flag for wake up from SHUTDN mode
//	TUint32	t2_ticks;						// 03.03.98 cg, removed, not used

	TUint32	cycles;							// 03.03.98 cg, new, oscillator cycles

	TUint8    Keyboard_Row[9];
	TUint16    IR15X;
	TInt loffset;
	TInt   width;
	TUint    boffset;
	TUint    lcounter;
	TUint    sync;							// 24.08.98 cg, not used
	TUint8    contrast;
	TBool    dispon;
	TUint32   start1;
	TUint32   start12;
	TUint32   end1;
	TUint32   start2, end2;
} CHIPSET;


#endif