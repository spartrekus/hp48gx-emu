#include <stdlib.h>
#include <stdio.h>
#include <e32std.h>
#include <f32file.h>
#include <fbs.h>
#include <gdi.h>

#include "engine.h"
#include "emu48.h"

ActiveEngine::ActiveEngine(Engine* aEngine)
	: CActive(0) //EPriorityHigh
{
	iEngine = aEngine ;
	iEngine->iActive = this;
	CActiveScheduler::Add(this);
};


ActiveEngine::~ActiveEngine() 
{
	Cancel() ;
}

void ActiveEngine::DoCancel() 
{
	Actif = EFalse;
	return;
}

void ActiveEngine::Start()
{
	Actif = ETrue;
	SetActive() ;
	
	// send signal that this request has completed
	TRequestStatus* status = &iStatus ;
	User::RequestComplete(status, KErrNone) ;
}

void ActiveEngine::Active()
{
	iEngine->Chipset.Shutdn = EFalse;
	if(!Actif)
	{
		Actif = ETrue;
		SetActive() ;
		TRequestStatus* status = &iStatus ;
		User::RequestComplete(status, KErrNone) ;
	}
}

void ActiveEngine::RunL()
{
	SetActive();
	Actif = ETrue;
	iEngine->WorkerThread();
	// send signal that this request has completed
	TRequestStatus* status = &iStatus ;
	User::RequestComplete(status, KErrNone) ;
}

Engine::Engine()
{
	fsLogs.Connect();
}

Engine::~Engine()
{
	if(DEBUG) fileLogs.Write(_L8("Fin Engine.\n"));
	StopTimers();
	UnmapRom();
	hLcdBitmap->Reset();
	delete(hLcdBitmap);
	hAnnuncBitmap->Reset();
	delete(hAnnuncBitmap);

#if 0
	strnum.Num((TUint)Chipset.Port0,EHex);
	fileLogs.Write(strnum);
	fileLogs.Write(_L8(".\n"));
	strnum.Num((TUint)Chipset.Port1,EHex);
	fileLogs.Write(strnum);
	fileLogs.Write(_L8(".\n"));
#endif

	User::FreeZ(adrCellP0);
	User::FreeZ(adrCellP1);
	if(bPort2Plugged || Chipset.type==3) User::FreeZ(adrCellP2);
	if(DEBUG) 
	{
		fileLogs.Write(_L8("Fin Engine Ok.\n"));
		fileLogs.Close();
		fsLogs.Close();
	}
}

void Engine::InitLogs()
{
	if(DEBUG)
	{
		filename = DefaultDrive;
		filename += KFicLogs;
		fileLogs.Replace(fsLogs,filename,EFileWrite);
		fileLogs.Write(_L8("Debut Engine.\n"));
#ifndef _UNICODE
		fileLogs.Write(DefaultDrive);
#endif
	}
}

void Engine::FocusChanged()
{
	TBool Focus0;

	Focus0 = Focus;
	Focus = FocusView && FocusUi;
	if(Focus && !Focus0) StartTimers();
	if(!Focus && Focus0) StopTimers();
}

TBool Engine::Init(TBool memAlloc)
{
	TTime tst;
	TUint i;
	TBool LoadOk;
	if(DEBUG) fileLogs.Write(_L8("Debut Engine::Init.\n"));

	nState = 1;
	nNextState = 0;
	bInterrupt = EFalse;

	bKeySlow = EFalse;
	dwSXCycles = 82;
	dwGXCycles = 123;
	bCommInit = EFalse;


	// Kml
	bPressed = EFalse;				// 01.10.97 cg, no key pressed

	// Display
	FocusView = ETrue;
	FocusUi = ETrue;
	Focus = ETrue;
	bScreenIsClean = EFalse;

	for(i=0;i<16;i++) {Pattern[i] = 0;}
	UpdateContrast(10);

	// Timer
	bStarted   = EFalse;
	bRealSpeed = EFalse;
	T1run = EFalse;
	T2run = EFalse;
	dwTickRef = lFreq.operator/(TInt64(SAMPLE)).Low();

	//UserHal::TickPeriod(periode);
	//lFreq = 1000000 / periode.Int();
	lFreq = TInt64(1000000);

	// Timer plus
	bOutRange = EFalse;
	//bAccurateTimer = ETrue;
	tst.HomeTime();
	lT2Ref = tst.Int64();

	// Timer bak
	//uT1Period  = 62;
	dwT2Init  = 0;
	dwT2Step  = 0;
	dwT2Ticks = 0;

	// Mops
	pbyRomView[0] = NULL;
	pbyRomView[1] = NULL;
	bFlashRomArray = ETrue;					// flag ROM mode
	f4096 = 0;
	ioc_acc = FALSE;						// 17.05.98 cg, new, flag ioc changed
	ir_ctrl_acc = FALSE;					// 17.05.98 cg, new, flag ir_ctl changed
	byVblRef = 0;					// 14.01.99 cg, new, VBL stop reference
	for(i=0;i<256;i++) {RMap[i] = NULL;}
	for(i=0;i<256;i++) {WMap[i] = NULL;}

	// TUint F_s[16] = {0/*P*/,0,2,0,15,3,0,0,0,0,0,0,0,0,0,0};
	// TUint F_l[16] = {1,1/*P+1*/,1,3,1,12,2,16,0,0,0,0,0,0,0,5};
	for(i=0;i<16;i++) {F_s[i] = 0;}
	F_s[2] = 2;
	F_s[4] = 15;
	F_s[5] = 3;
	for(i=0;i<16;i++) {F_l[i] = 0;}
	F_l[0] = 1;
	F_l[1] = 1;
	F_l[2] = 1;
	F_l[3] = 3;
	F_l[4] = 1;
	F_l[5] = 12;
	F_l[6] = 2;
	F_l[7] = 16;
	F_l[15] = 5;

	InitLcd(memAlloc);
	if(memAlloc)
	{
		if(!InitAnnunciator(ETrue)) return EFalse;
		adrCellP0 = NULL;
		adrCellP1 = NULL;
		if (!MapRom())   // (+init cCurrentRomType)
		{
			if(DEBUG) fileLogs.Write(_L8("Erreur MapRom !\n"));
			return EFalse;
		}
	}
	LoadOk = ETrue;
	if(!LoadChipset()) InitChipset();
	if (!InitPorts(memAlloc))
	{
		if(DEBUG) fileLogs.Write(_L8("Erreur InitPorts !\n"));
		//User::InfoPrint(_L("Memoire insuffisante"));
		User::FreeZ(adrCellP0);
		User::FreeZ(adrCellP1);
		UnmapRom();
		return EFalse;
	}
	if(!LoadP0()) LoadOk = EFalse;
	if(!LoadP1()) LoadOk = EFalse;
	if(!LoadP2()) LoadOk = EFalse;
	if(!LoadOk)
	{
		if(DEBUG) fileLogs.Write(_L8("Erreur LoadP0, LoadP1.\n"));
		Mem::Fill(Chipset.Port0, Chipset.Port0Size*2048, 0x0);
		Mem::Fill(Chipset.Port1, Chipset.Port1Size*2048, 0x0);
		if(bPort2Plugged) Mem::Fill(pbyPort2, dwPort2Size*2048, 0x0);
		if(Chipset.Port2Size) Mem::Fill(Chipset.Port2, Chipset.Port2Size*2048, 0x0);
		RomSwitch(0);				// reload ROM view of HP49G and map memory
	}
	else
	{
		if(cCurrentRomType==1 || cCurrentRomType==2)
		{
			if (Chipset.wPort2Crc != CrcPort2())// port2 changed
			{
				Chipset.HST |= 8;				// set Module Pulled
				Chipset.SoftInt = ETrue;			// set interrupt
				bInterrupt = ETrue;
			}
		}
		RomSwitch(Chipset.Bank_FF);				// reload ROM view of HP49G and map memory
	}
	//Map(0x00,0xFF);
	return ETrue;
}

void Engine::SpeedRef()
{
	// dwOldCyc = Chipset.cycles;
	// dwSpeedRef = User::TickCount();
	TTime tst;
	TInt64 lDummyInt;
	dwOldCyc = Chipset.cycles;
	tst.HomeTime();
	lDummyInt=tst.Int64()/1000;
	dwSpeedRef = lDummyInt.Low();
}

void Engine::WorkerThread()
{
	//if(DEBUG) fileLogs.Write(_L8("Debut WorkerThread.\n"));


	if (nState!=0)
	{
		if(DEBUG) fileLogs.Write(_L8("  WorkerThread nState!=0.\n"));
		nState = 0;

		// clear port2 status bits
		Chipset.cards_status &= ~(PORT2_PRESENT | PORT2_WRITE);
		if (pbyPort2 || Chipset.Port2)	// card plugged in port2
		{
			Chipset.cards_status |= PORT2_PRESENT;
			if (bPort2Writeable) Chipset.cards_status |= PORT2_WRITE;
		}
		RomSwitch(Chipset.Bank_FF);		// select HP49G ROM bank and update memory mapping
		UpdateDisplayPointers();
		if(DEBUG) fileLogs.Write(_L8("UpdateDisplayPointers Ok.\n"));
		UpdateMainDisplay(ETrue);
		if(DEBUG) fileLogs.Write(_L8("UpdateMainDisplay Ok.\n"));
		UpdateMenuDisplay(ETrue);
		if(DEBUG) fileLogs.Write(_L8("UpdateMenuDisplay Ok.\n"));
		UpdateAnnunciators(ETrue);
		if(DEBUG) fileLogs.Write(_L8("UpdateAnnunciators Ok.\n"));
		// if(RedrawMode == 2) iView->UpdateWindow(hLcdBitmap,0,0,nLcdX,nLcdY,0,0); // Bitmap Fast
		SpeedRef();
		SetHP48Time();					// update HP48 time & date
		StartTimers();
		//if(DEBUG)fileLogs.Write(_L8("    WorkerThread StartTimers Ok.\n"));
		PCHANGED;
	}
	cpt1 = 500; //500
	while(!bInterrupt && cpt1-- > 0)
	{
		//fileLogs.Write(_L8("  WorkerThread loop.\n"));
		do								
		{
			f4096--;
			TUint8* I = FASTPTR(w.pc);
#if 0
			fileLogs.Write(_L8("    WorkerThread Chipset.pc = "));
			strnum.NumUC(w.pc,EHex);
			fileLogs.Write(strnum);
			fileLogs.Write(_L8(" "));
		//if(I[0]==8 && I[1]==1 && I[2]==0xB)
		//{
			fileLogs.Write(_L8("I = "));
			for(TInt i=0;i<=6;i++)
			{
				strnum.NumUC(I[i],EHex);
				fileLogs.Write(strnum);
			}

			fileLogs.Write(_L8("\n"));
		//}
#endif
			#include "Fetch.h"
			#include "opcodes.h"
		}
		while(0);						// 23.04.98 cg, workaround for continue
		//CheckSerial();					// 17.05.98 cg, serial support
		//fileLogs.Write(_L8("  WorkerThread loop Ok.\n"));
		//AdjustSpeed();					// 23.04.98 cg, adjust emulation speed
	}
	if (bInterrupt)
	{

		//fileLogs.Write(_L8("  WorkerThread bInterrupt.\n"));
		if (Chipset.Shutdn)
		{
			//fileLogs.Write(_L8("    WorkerThread bInterrupt Shutdn.\n"));
			bInterrupt = EFalse;
			if(RedrawMode == 2) // Bitmap fast
			{
				UpdateMainDisplay(ETrue);
				UpdateMenuDisplay(ETrue);
				// iView->UpdateWindow(hLcdBitmap,0,0,nLcdX,nLcdY,0,0); // fait dans Update...
			}
			if(iView->OldButtonMode != iView->ButtonMode)
			{
				iView->DrawAllButtons();
				iView->OldButtonMode = iView->ButtonMode;
			}
			iActive->Cancel();
			//User::InfoPrint(_L("Shutdn Ok.\n"));
			//fileLogs.Write(_L8("    WorkerThread bInterrupt Shutdn Ok.\n"));
		}
		if (Chipset.SoftInt)
		{
			//fileLogs.Write(_L8("    WorkerThread bInterrupt SoftInt.\n"));
			bInterrupt = EFalse;
			Chipset.SoftInt = EFalse;
			if (Chipset.inte)
			{
				//fileLogs.Write(_L8("    WorkerThread bInterrupt SoftInt inte.\n"));
				Chipset.inte = EFalse;
				rstkpush(Chipset.pc);
				Chipset.pc = 0xf;
				

			}
			// fileLogs.Write(_L8("    WorkerThread bInterrupt SoftInt Ok.\n"));
		}
		if (nNextState != 0)
		{
			//fileLogs.Write(_L8("    WorkerThread bInterrupt nNextState != 0.\n"));
			StopTimers();
			Chipset.cards_status &= (Chipset.type==1)?0x5:0xA;
		}
		PCHANGED;
	}
	iView->ReleaseKey();
	//fileLogs.Write(_L8("Fin WorkerThread.\n"));
}


void Engine::AdjKeySpeed(void)				// 05.07.98 cg, new, slow down key repeat
{
	TUint16 i;
	TBool bKey;

	// fileLogs.Write(_L8("AdjKeySpeed.\n"));
	if (bRealSpeed) return;					// no need to slow down

	bKey = EFalse;							// search for a pressed key
	for (i = 0;i < sizeof(Chipset.Keyboard_Row) / sizeof(Chipset.Keyboard_Row[0]) && !bKey;++i)
		bKey = (Chipset.Keyboard_Row[i] != 0);

	// fileLogs.Write(_L8("search Ok.\n"));


	if (!bKeySlow && bKey)					// key pressed, init variables
	{
		TTime tst;

		TInt64 dwTime;
		tst.HomeTime();



		dwTime = tst.Int64()/1000;
		dwSpeedRef = dwTime.Low();			// save reference time
	}
	bKeySlow = bKey;						// save new state
	//fileLogs.Write(_L8("AdjKeySpeed Ok.\n"));


	return;
}

void Engine::SetSpeed(TBool bAdjust)					// 23.04.98 cg, new, set emulation speed
{
	if (bAdjust)							// 15.05.98 cg, changed, switch to real speed
	{

		TTime tst;
		TInt64 dwTime;
		tst.HomeTime();
		dwTime = tst.Int64()/1000;
		dwSpeedRef = dwTime.Low();			// save reference time
		dwOldCyc = Chipset.cycles;			// save reference cycles
	}

	bRealSpeed = bAdjust;					// 15.05.98 cg, bugfix, save emulation speed
}

void Engine::UpdateKdnBit(void)						// 25.02.99 cg, new, update KDN bit
{
	if (Chipset.intk && Chipset.cycles - Chipset.dwKdnCycles > (TUint32) T2CYCLES * 16)
		IOBit(0x19,8,Chipset.in != 0);
}

void Engine::ResetCalc()
{
	StopTimers();

	Chipset.cards_status &= (Chipset.type==1)?0x5:0xA;
	Chipset.pc = 0;
	Chipset.inte = ETrue;
	Chipset.Shutdn = EFalse;
	Chipset.SoftInt = ETrue;
	Reset();
	bInterrupt = ETrue;
	nState = 1;
	nNextState = 0;

}
