#ifndef __EMU48_H
#define __EMU48_H

#ifdef __ER5__
	#include <eikappui.h>
	#include <eikapp.h>
	#include <eikdoc.h>
	#include <eikcmds.hrh>
	#include <eikdialg.hrh>
	#include <eikmenu.hrh>
	#include <eikmfne.h>
#endif
#ifdef __ER6__
	#include <uikon.hrh>
	#include <eikappui.h>
	#include <eikapp.h>
	#include <eikdoc.h>
	#include <eikmfne.h>
#endif
#ifdef __ER7__
	#include <uikon.hrh>
	#include <qikAppUi.h>
	#include <qikApplication.h>
	#include <qikDocument.h>
	//#include <eikappui.h>
	//#include <eikapp.h>
	//#include <eikdoc.h>
	#include <qiknumbereditor.h>
#endif

#include <coecntrl.h>
#include <coeccntx.h>
#include <coemain.h>
#include <coeaui.h>
#include <eikenv.h> 
#include <eikdialg.h>
#include <eikcfdlg.h>
#include <eikmenup.h>
#include <eikcmbut.h>
#include <eikbutb.h>
#include <eikhopbt.h>
#include <eikchkbx.h>
#include <eikinfo.h>
#include <eikon.rsg>
#include <emu48e.rsg>
#include "emu48e.hrh"
#include <w32std.h>
#include <baclipb.h>
#include <s32strm.h>

const TUid KUidEmu48E = { 0x101f9f96 };

_LIT(KFicLogsView,"System\\Apps\\Emu48E\\logsView.txt");
_LIT(KFicLogsUI,"System\\Apps\\Emu48E\\logsUI.txt");
_LIT(KFicPrefs,"System\\Apps\\Emu48E\\Emu48E.ini");
_LIT(KMainSxBitmap,"System\\Apps\\Emu48E\\mainSx.mbm");
_LIT(KMainGxBitmap,"System\\Apps\\Emu48E\\mainGx.mbm");
_LIT(KMain2SGxBitmap,"System\\Apps\\Emu48E\\main2SGx.mbm");
_LIT(KMain5SxBitmap,"System\\Apps\\Emu48E\\main5Sx.mbm");
_LIT(KMain5GxBitmap,"System\\Apps\\Emu48E\\main5Gx.mbm");
_LIT(KKeya2SGxBitmap,"System\\Apps\\Emu48E\\keya2SGx.mbm");
_LIT(KKeyl2GxBitmap,"System\\Apps\\Emu48E\\keyl2Gx.mbm");
_LIT(KKeyl2SxBitmap,"System\\Apps\\Emu48E\\keyl2Sx.mbm");
_LIT(KKeyr2GxBitmap,"System\\Apps\\Emu48E\\keyr2Gx.mbm");
_LIT(KKeyr2SxBitmap,"System\\Apps\\Emu48E\\keyr2Sx.mbm");
_LIT(KMain49GBitmap,"System\\Apps\\Emu48E\\main49G.mbm");
_LIT(KMain249GBitmap,"System\\Apps\\Emu48E\\main249G.mbm");
_LIT(KKeya249GBitmap,"System\\Apps\\Emu48E\\keya249G.mbm");
_LIT(KKeyl249GBitmap,"System\\Apps\\Emu48E\\keyl249G.mbm");
_LIT(KKeyr249GBitmap,"System\\Apps\\Emu48E\\keyr249G.mbm");
_LIT(KMain549GBitmap,"System\\Apps\\Emu48E\\main549G.mbm");

class Emu48Doc;
class Engine;
class ActiveEngine;

typedef struct Button
{



	TBool bDown;
	TBool b3d;
	TInt Ox, Oy;
	TInt nx, ny;
	TUint Out, In;
} Button;

typedef struct Prefs
{
	TInt RedrawMode;
	TInt zoom;
	TBool KeyUpEvents;
	TInt64 TimeKeyMin;
	TUint8 div4096;
	TBool Backup;
	TBuf<150> RomFileName;
} Prefs;

class Emu48View : public CCoeControl, public MCoeControlBrushContext
    {
public:
	~Emu48View();
	//void ConstructL(const TRect& aRect);
	void ConstructL(TInt azoom);
	void UpdateWindow(CFbsBitmap* aLcdBitmap,TInt x0Dest, TInt y0Dest, TInt nx, TInt ny, TInt x0Src, TInt y0Src);
	TInt MainX;
	TInt MainY;
	TInt LcdX0;
	TInt LcdY0;
	void UpdateAnnunc(CFbsBitmap* aAnnuncBitmap, TInt x0Dest, TInt y0Dest, TInt nx, TInt ny, TInt x0Src, TInt y0Src);
	Engine* Emu48Engine;
	TBuf<3> DefaultDrive;
	TBuf<3> DefaultDriveBak;
	TInt ChipsetType;
	TInt ButtonMode; // 0 = normal, 1 = shift_left, 2 = shift_right, 3 = alpha
	TInt OldButtonMode; // 0 = normal, 1 = shift_left, 2 = shift_right, 3 = alpha
	TBool KeyUpEvents;
	TBool KeyUpEvent1;
	TInt64 TimeKeyMin;
#ifndef __ER7__
	TKeyResponse OfferKeyEventL(const TKeyEvent& aKeyEvent,TEventCode aType);
#endif
	void DrawAllButtons();
	void ReleaseKey();
	void PressKey(TUint i);
	void PressKeyB(TUint i);
private: // from CCoeControl
	void FocusChanged(TDrawNow aDrawNow);
	void HandlePointerEventL(const TPointerEvent& aPointerEvent);
	void Draw(const TRect& /*aRect*/) const;
	void DrawButton(TUint bid);
	void InitButton();
private:
	CFbsBitmap* hMainBitmap;
	CFbsBitmap* hKeyaBitmap;
	CFbsBitmap* hKeylBitmap;
	CFbsBitmap* hKeyrBitmap;
	TInt zoom;
	TInt PointerX0;
	TInt PointerY0;
	TBool MainDrag;
	TBool KeyPressed;
	TUint KeyPressedId;
	TInt KeyPressedNb;
	Button pButton[51];
	RFs fsLogs;
	RFile fileLogs;
	TBuf<80> filename;
	TBuf8<16> strnum;
	CFont*	iFont;
	TDesC*  iText;
	TUint ToucheIn;
	TUint ToucheOut;
	// RWindow iWindow;
	RDrawableWindow* iWindow;
	TInt nLcdX;
	TInt nLcdY;
	TSize MainSize;
	TTime tst;
	TInt64 KeyRefTime;
	TUint KeyMul;
	TUint KeyDiv;
	TUint KeyPlus;
	TUint KeyMoins;
    };

#ifndef __ER7__
class Emu48Ui : public CEikAppUi
#else
class Emu48Ui : public CQikAppUi
#endif
    {
public:
    void ConstructL();
	~Emu48Ui();
	Emu48View* iAppView;
	Engine* Emu48Engine;
	ActiveEngine* iActiveEngine;
	void CmdDialog();
	void CmdVue(TInt azoom);
	void ResetConfirmDialog();
	void NouveauConfirmDialog();
	TBool RomSelectL();
	void CmdObjectOpenL();
	void CmdObjectSaveL();
	void doPasteL();
	void doCopyL();
	void Sauvegarde();
	void CmdRecharger();
	TBool LoadPrefs();
	TBool SavePrefs();
	Prefs Pref;
private: // from CEikAppUi
	RFs fsLogs;
	RFile fileLogs;
	TBuf<150> filename;
	TBuf<3> DefaultDrive;
	TBuf<3> DefaultDriveBak;
	TInt ChipsetType;
	TBuf8<16> strnum;
	//TInt zoom;
	void HandleCommandL(TInt aCommand);
#ifndef __ER7__
	void DynInitMenuPaneL(TInt aMenuId,CEikMenuPane* aMenuPane);
#endif
#ifdef __ER5__
	void HandleKeyEventL(const TKeyEvent& aKeyEvent,TEventCode aType);
#endif
	void HandleForegroundEventL(TBool aForeground);
private:
    };


#ifndef __ER7__
class Emu48Doc : public CEikDocument
#else
class Emu48Doc : public CQikDocument
#endif
	{
public:
	// construct/destruct
	Emu48Doc(CEikApplication& aApp);
private: // from CEikDocument
	CEikAppUi* CreateAppUiL();
	};


#ifndef __ER7__
class Emu48App : public CEikApplication
#else
class Emu48App : public CQikApplication
#endif
	{
private: // from CApaApplication
	CApaDocument* CreateDocumentL();
	TUid AppDllUid() const;
	};

class CEmu48DispDialog : public CEikDialog
	{
  public:
	CEmu48DispDialog(Emu48Ui* aUi); //construction

  private:
	void  PreLayoutDynInitL(); //impl. of virtual in CEikDialog
	TBool OkToExitL(TInt aKeycode); //overd. of virtual in CEikDialog

	//Data members:
  private:
	Emu48Ui* iUi;
	};
#endif
