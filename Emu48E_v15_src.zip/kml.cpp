/*
 *   kml.c
 *
 *   This file is part of Emu48
 *
 *   Copyright (C) 1995 Sebastien Carlier
 *
 */

#include "engine.h"


//################
//#
//#    Initialization Phase
//#
//################

void Engine::InitChipset()
{
	TUint i;
	Chipset.pc = 0;
	Chipset.type = cCurrentRomType;
	Chipset.inte = EFalse;		// interrupt status flag (FALSE = int in service)
	Chipset.intk = EFalse;		// 1 ms keyboard scan flag (TRUE = enable)
	Chipset.intd = EFalse;		// keyboard interrupt pending (TRUE = int pending)
	Chipset.Shutdn = EFalse;
	Chipset.SoftInt = EFalse;
	Chipset.contrast = 15;

	for(i=0;i<9;i++) {Chipset.Keyboard_Row[i] = 0;}
	for(i=0;i<64;i++) {Chipset.IORam[i] = 0;}
	Chipset.IOBase = 0x100000;
	Chipset.IOCfig = EFalse;
	Chipset.d0 = 0;
	Chipset.d1 = 0;
	for(i=0;i<8;i++) {Chipset.rstk[i] = NULL;}
	for(i=0;i<16;i++) {Chipset.A[i] = 0;}
	for(i=0;i<16;i++) {Chipset.B[i] = 0;}
	for(i=0;i<16;i++) {Chipset.C[i] = 0;}
	for(i=0;i<16;i++) {Chipset.D[i] = 0;}
	for(i=0;i<16;i++) {Chipset.R0[i] = 0;}
	for(i=0;i<16;i++) {Chipset.R1[i] = 0;}
	for(i=0;i<16;i++) {Chipset.R2[i] = 0;}
	for(i=0;i<16;i++) {Chipset.R3[i] = 0;}
	for(i=0;i<16;i++) {Chipset.R4[i] = 0;}
	for(i=0;i<4;i++) {Chipset.ST[i] = 0;}
	Chipset.HST = 0;
	Chipset.P = NULL;
	Chipset.mode_dec = EFalse;
	Chipset.carry = EFalse;
	Chipset.crc = 0;
	Chipset.wPort2Crc = 0;
	Chipset.wShutdnWake = EFalse;
	Chipset.dwKdnCycles = 0;
	Chipset.Bank_FF = NULL;
	Chipset.Port2_NBanks = NULL;
	Chipset.P0Base = NULL;
	Chipset.BSBase = NULL;
	Chipset.P1Base = NULL;
	Chipset.P2Base = NULL;
	Chipset.P0Size = NULL;
	Chipset.BSSize = NULL;
	Chipset.P1Size = NULL;
	Chipset.P2Size = NULL;
	Chipset.P0End = NULL;
	Chipset.BSEnd = NULL;
	Chipset.P1End = NULL;
	Chipset.P2End = NULL;
	Chipset.cycles = 0;
#if 1
	Chipset.loffset = NULL;
	Chipset.width = NULL;
	Chipset.boffset = NULL;
	Chipset.lcounter = NULL;
	Chipset.sync = 0;							// 24.08.98 cg, not used
	Chipset.start1 = NULL;
	Chipset.start12 = NULL;
	Chipset.end1 = NULL;
	Chipset.start2 = NULL;
	Chipset.end2 = NULL;
	Chipset.dispon = EFalse;
	Chipset.t1 = 0;
	Chipset.t2 = 0;

	Chipset.rstkp = NULL;
	Chipset.in = NULL;
	Chipset.out = NULL;
	Chipset.P0Cfig = EFalse;
	Chipset.BSCfig = EFalse;
	Chipset.P1Cfig = EFalse;
	Chipset.P2Cfig = EFalse;
	Chipset.P0Cfg2 = EFalse;
	Chipset.BSCfg2 = EFalse;
	Chipset.P1Cfg2 = EFalse;
	Chipset.P2Cfg2 = EFalse;
	Chipset.IR15X = 0;
	if(DEBUG) fileLogs.Write(_L8("InitChipset Ok.\n"));
#endif

}

TBool Engine::InitPorts(TBool PortsAlloc)
{
	if(DEBUG) fileLogs.Write(_L8("InitPorts.\n"));
	Chipset.type = cCurrentRomType;

	if (Chipset.type == 1) // 48SX
	{
		if(DEBUG) fileLogs.Write(_L8("48SX.\n"));
		Chipset.Port0Size = 32;
		Chipset.Port1Size = 128;
		Chipset.Port2Size = 0;
		Chipset.cards_status = 0x5;
		bPort2Plugged = EFalse;
		bPort2Writeable = EFalse;
	}
	if (Chipset.type == 2) // 48GX
	{
		if(DEBUG) fileLogs.Write(_L8("48GX.\n"));
		Chipset.Port0Size = 128;
		Chipset.Port1Size = 128;
		Chipset.Port2Size = 0;
		Chipset.cards_status = 0xA;
		bPort2Plugged = ETrue;
		bPort2Writeable = ETrue;
	}
	if (Chipset.type == 3) // 49G
	{
		if(DEBUG) fileLogs.Write(_L8("49G.\n"));
		Chipset.Port0Size = 256;
		Chipset.Port1Size = 128;
		Chipset.Port2Size = 128;
		Chipset.cards_status = 0xF;
		bPort2Plugged = EFalse;
		bPort2Writeable = ETrue;				// port2 is writeable
	}
	Chipset.Port1_Writeable = ETrue;

	if (Chipset.Port0Size)
	{
		if(PortsAlloc) adrCellP0 = User::Alloc(Chipset.Port0Size*2048);
		if (adrCellP0 == NULL) return EFalse;
		Chipset.Port0 = (TUint8*)adrCellP0;
		if(DEBUG) fileLogs.Write(_L8("Alloc P0 Ok.\n"));
	} else Chipset.Port0 = NULL;

	if (Chipset.Port1Size)
	{
		if(PortsAlloc) adrCellP1 = User::Alloc(Chipset.Port1Size*2048);
		if (adrCellP1 == NULL) return EFalse;
		Chipset.Port1 = (TUint8*)adrCellP1;
		if(DEBUG) fileLogs.Write(_L8("Alloc P1 Ok.\n"));
	} else Chipset.Port1 = NULL;

	if (Chipset.Port2Size)
	{
		if(PortsAlloc) adrCellP2 = User::Alloc(Chipset.Port2Size*2048);
		if (adrCellP2 == NULL) return EFalse;
		Chipset.Port2 = (TUint8*)adrCellP2;
		if(DEBUG) fileLogs.Write(_L8("Alloc P2 49G Ok.\n"));
	} else Chipset.Port2 = NULL;

	if(bPort2Plugged)
	{
		dwPort2Size = 128;
		bPort2Writeable = ETrue;
		dwPort2Mask = ((dwPort2Size*2048) - 1) >> 18;	// mask for valid address lines of the BS-FF
		if(PortsAlloc) adrCellP2 = User::Alloc(dwPort2Size*2048);
		if (adrCellP2 == NULL) return EFalse;
		pbyPort2 = (TUint8*)adrCellP2;
		if(DEBUG) fileLogs.Write(_L8("Alloc P2 48 Ok.\n"));
	}
	else
	{
		dwPort2Size = 0;
		dwPort2Mask = 0;
		pbyPort2 = NULL;
	}
	return ETrue;

}


void Engine::InitLcd(TBool LcdAlloc)
{
	TInt bmp;
	TScreenInfoV01 screenInfo;
	TPckg<TScreenInfoV01> sI(screenInfo);
	UserSvr::ScreenInfo(sI);

	if(DEBUG) fileLogs.Write(_L8("InitLcd.\n"));
	nFBX = screenInfo.iScreenSize.iWidth;
	nFBY = screenInfo.iScreenSize.iHeight;
	if(DEBUG)
	{
		fileLogs.Write(_L8("nFBX="));
		strnum.Num(nFBX);
		fileLogs.Write(strnum);
		fileLogs.Write(_L8(".\n"));
		fileLogs.Write(_L8("nFBY="));
		strnum.Num(nFBY);
		fileLogs.Write(strnum);
		fileLogs.Write(_L8(".\n"));
	}
	n2FBX = nFBX / 2;
	n4FBX = nFBX / 4;
#ifdef __ER5__
	FBValid = screenInfo.iScreenAddressValid;
#else
	FBValid = EFalse;
#endif
	if(FBValid)
	{
		if(DEBUG) fileLogs.Write(_L8("FBValid = true.\n"));
		FBAdr = (TUint8*)screenInfo.iScreenAddress;
		if(DispMode == 2)
		{
			FBAdr += 512;
			if(DEBUG) fileLogs.Write(_L8("FBAdr + 512 : 8bpp.\n"));
		}
		else
		{
			if(DEBUG) fileLogs.Write(_L8("FBAdr : 4bpp.\n"));
		}
		if(DEBUG)
		{
			fileLogs.Write(_L8("FBAdr="));
			strnum.Num((TUint)FBAdr,EHex);
			fileLogs.Write(strnum);
			fileLogs.Write(_L8(".\n"));
		}
	}
	else
	{
		if(DEBUG) fileLogs.Write(_L8("FBValid = false.\n"));
		FBAdr = NULL;
	}

	nLcdX = 131*nLcdDoubled;
	nLcdY = 64*nLcdDoubled;
	if(LcdAlloc)
	{
		if(DEBUG) fileLogs.Write(_L8("LcdAlloc.\n"));
		hLcdBitmap = NULL;
		hLcdBitmap = new (ELeave) CFbsBitmap();
		TSize LcdSize = TSize(144 * nLcdDoubled,64 * nLcdDoubled);
		bmp = KErrCouldNotConnect; // une valeur par defaut
		if(DispMode == 2) bmp = hLcdBitmap->Create(LcdSize,EColor256); // 8bpp
		else bmp = hLcdBitmap->Create(LcdSize,EGray16); // 4bpp EGray16
		switch(bmp)
		{
		case KErrCouldNotConnect :
			{
			if(DEBUG) fileLogs.Write(_L8("Creation bitmap : KErrCouldNotConnect.\n"));
			User::Leave(0);
			break;
			}
		case KErrArgument :
			{
			if(DEBUG) fileLogs.Write(_L8("Creation bitmap : KErrArgument.\n"));
			User::Leave(0);
			break;
			}
		case KErrNone :
			{
			if(DEBUG) fileLogs.Write(_L8("Creation bitmap Ok.\n"));
			break;
			}
		default :
			if(DEBUG)
			{
				fileLogs.Write(_L8("Creation bitmap : Erreur "));
				strnum.Num(bmp);
				fileLogs.Write(strnum);
				fileLogs.Write(_L8(".\n"));
			}
			User::Leave(0);
			break;
		}
		hLcdBitmapUtil = new (ELeave) TBitmapUtil(hLcdBitmap);
	}
	pbyLcd=(TUint8*)(hLcdBitmap->DataAddress());


#if 0
	// testNetbook
	hLcdBitmap2 = NULL;
	hLcdBitmap2 = new CFbsBitmap();
	LcdSize = TSize(nFBX,nFBY);
	bmp = hLcdBitmap2->Create(LcdSize,EGray256); // 8bpp
	if(bmp == KErrNone)
	{
		if(DEBUG) fileLogs.Write(_L8("Creation hLcdBitmap2 Ok.\n"));
	}
	else User::Leave(0);
	hLcdBitmapUtil2 = new (ELeave) TBitmapUtil(hLcdBitmap2);
	FBAdr=(TUint8*)(hLcdBitmap2->DataAddress());
	if(DEBUG)
	{
		fileLogs.Write(_L8("FBAdr="));
		strnum.Num((TUint)FBAdr,EHex);
		fileLogs.Write(strnum);
		fileLogs.Write(_L8(".\n"));
	}
	FBValid = ETrue;
	// fin testNetbook
#endif

	if(DEBUG) fileLogs.Write(_L8("InitLcd Ok.\n"));
	return;
}

void Engine::SupprimeLcd()
{
	if(DEBUG) fileLogs.Write(_L8("SupprimeLcd.\n"));

	delete hLcdBitmapUtil;
	hLcdBitmapUtil = NULL;
	hLcdBitmap->Reset();
	delete(hLcdBitmap);
	hLcdBitmap = NULL;

#if 0
	// testNetbook
	delete hLcdBitmapUtil2;
	hLcdBitmapUtil2 = NULL;
	hLcdBitmap2->Reset();
	delete(hLcdBitmap2);
	hLcdBitmap2 = NULL;
	// fin testNetbook
#endif

	if(DEBUG) fileLogs.Write(_L8("SupprimeLcd Ok.\n"));
}

TBool Engine::InitAnnunciator(TBool chargeBmp)
{
	TInt i;

	if(chargeBmp)
	{
		hAnnuncBitmap = new CFbsBitmap();

		filename = DefaultDrive;
		filename += KAnnuncBitmap;
		TInt bmp = hAnnuncBitmap->Load(filename,0,ETrue);
		switch(bmp)
		{
		case KErrCouldNotConnect :
			{
			if(DEBUG) fileLogs.Write(_L8("Load AnnuncBitmap : KErrCouldNotConnect.\n"));
			return EFalse;
			break;
			}
		case KErrArgument :
			{
			if(DEBUG) fileLogs.Write(_L8("Load AnnuncBitmap : KErrArgument.\n"));
			return EFalse;
			break;
			}
		case KErrNone :
			{
			if(DEBUG) fileLogs.Write(_L8("Load AnnuncBitmap Ok.\n"));
			break;
			}
		default :
			if(DEBUG) fileLogs.Write(_L8("Load AnnuncBitmap : Fichier non trouve.\n"));
			return EFalse;
			break;
		}
	}
	if(zoom == 1)
	{
		for(i=0;i<6;i++)
		{
			pAnnunciator[i].srcY = 0;
			pAnnunciator[i].destY = 7;
			pAnnunciator[i].disp = EFalse;
		}
		pAnnunciator[0].srcX = 1;
		pAnnunciator[0].destX = 33;
		pAnnunciator[1].srcX = 13;
		pAnnunciator[1].destX = 45;
		pAnnunciator[2].srcX = 34;
		pAnnunciator[2].destX = 66;
		pAnnunciator[3].srcX = 54;
		pAnnunciator[3].destX = 86;
		pAnnunciator[4].srcX = 78;
		pAnnunciator[4].destX = 110;
		pAnnunciator[5].srcX = 109;

		pAnnunciator[5].destX = 140;
	}
	if(zoom == 2)
	{
#ifndef __ER7__
		for(i=0;i<6;i++)
		{
			pAnnunciator[i].srcY = 0;
			pAnnunciator[i].destY = 1;
			pAnnunciator[i].disp = EFalse;
		}
		pAnnunciator[0].srcX = 1;
		pAnnunciator[0].destX = 41;
		pAnnunciator[1].srcX = 13;
		pAnnunciator[1].destX = 65;
		pAnnunciator[2].srcX = 34;
		pAnnunciator[2].destX = 107;
		pAnnunciator[3].srcX = 54;
		pAnnunciator[3].destX = 147;
		pAnnunciator[4].srcX = 78;
		pAnnunciator[4].destX = 195;
		pAnnunciator[5].srcX = 109;
		pAnnunciator[5].destX = 255;
#else
		for(i=0;i<6;i++)
		{
			pAnnunciator[i].srcY = 0;
			pAnnunciator[i].destY = 8;
			pAnnunciator[i].disp = EFalse;
		}
		pAnnunciator[0].srcX = 1;
		pAnnunciator[0].destX = 43;
		pAnnunciator[1].srcX = 13;
		pAnnunciator[1].destX = 55;
		pAnnunciator[2].srcX = 34;
		pAnnunciator[2].destX = 76;
		pAnnunciator[3].srcX = 54;
		pAnnunciator[3].destX = 96;
		pAnnunciator[4].srcX = 78;
		pAnnunciator[4].destX = 120;
		pAnnunciator[5].srcX = 109;
		pAnnunciator[5].destX = 150;
#endif
	}
	if(zoom == 3)
	{
		for(i=0;i<6;i++)
		{
			pAnnunciator[i].srcY = 0;
			pAnnunciator[i].destY = 1;
			pAnnunciator[i].disp = EFalse;
		}
		pAnnunciator[0].srcX = 1;
		pAnnunciator[0].destX = 33*2;
		pAnnunciator[1].srcX = 13;
		pAnnunciator[1].destX = 45*2;
		pAnnunciator[2].srcX = 34;
		pAnnunciator[2].destX = 66*2;
		pAnnunciator[3].srcX = 54;
		pAnnunciator[3].destX = 86*2;
		pAnnunciator[4].srcX = 78;
		pAnnunciator[4].destX = 110*2;
		pAnnunciator[5].srcX = 109;
		pAnnunciator[5].destX = 140*2;
	}
	return ETrue;
}

