#include "engine.h"
#include "emu48.h"
#include <libc/string.h>
#include <e32keys.h>


inline TUint MIN(TUint a, TUint b)
{
	return (a<b)?a:b;
}

EXPORT_C CApaApplication* NewApplication()
{
	return new Emu48App;
}

// This function is required by all EPOC32 DLLs. In this example,
// it does nothing.
GLDEF_C TInt E32Dll(TDllReason)
{
	return KErrNone;
}

TUid Emu48App::AppDllUid() const
{
	return KUidEmu48E;
}

CApaDocument* Emu48App::CreateDocumentL()
{
	return new (ELeave) Emu48Doc(*this);
}


#ifndef __ER7__
Emu48Doc::Emu48Doc(CEikApplication& aApp)
		: CEikDocument(aApp)
#else
Emu48Doc::Emu48Doc(CEikApplication& aApp)
		: CQikDocument(aApp)
#endif
{
}


CEikAppUi* Emu48Doc::CreateAppUiL()
{
    return new(ELeave) Emu48Ui;
}

void Emu48Ui::ConstructL()
{
	RFile file;
	TBool RomPresente;

#ifndef __ER7__
	BaseConstructL();
#else
	CQikAppUi::ConstructL();
	//BaseConstructL();
#endif

	fsLogs.Connect();
	if (file.Open(fsLogs,(filename=KDriveE)+=KAnnuncBitmap,EFileShareReadersOnly) == KErrNone)
	{
		file.Close();
		DefaultDrive = KDriveE;
	}
	else if (file.Open(fsLogs,(filename=KDriveD)+=KAnnuncBitmap,EFileShareReadersOnly) == KErrNone)
	{
		file.Close();
		DefaultDrive = KDriveD;
	}
	else DefaultDrive = KDriveC;

	if (file.Open(fsLogs,(filename=KDriveE)+=KFicRamP0,EFileShareReadersOnly) == KErrNone)
	{
		file.Close();
		DefaultDriveBak = KDriveE;
	}
	else if (file.Open(fsLogs,(filename=KDriveD)+=KFicRamP0,EFileShareReadersOnly) == KErrNone)
	{
		file.Close();
		DefaultDriveBak = KDriveD;
	}
	else if (file.Open(fsLogs,(filename=KDriveC)+=KFicRamP0,EFileShareReadersOnly) == KErrNone)
	{
		file.Close();
		DefaultDriveBak = KDriveC;
	}
	else DefaultDriveBak = DefaultDrive;

/*
	RomPresente = ETrue;
	if(file.Open(fsLogs,((filename=DefaultDrive)+=KRomPath)+=KFicRom49G,EFileShareReadersOnly) == KErrNone)
	{
		file.Close();
		ChipsetType = 3; // 49G
		Pref.RomFileName = filename;
	}
	else if(file.Open(fsLogs,((filename=DefaultDrive)+=KRomPath)+=KFicRomGx,EFileShareReadersOnly) == KErrNone)
	{
		file.Close();
		ChipsetType = 2; // 48Gx
		Pref.RomFileName = filename;
	}
	else if(file.Open(fsLogs,((filename=DefaultDrive)+=KRomPath)+=KFicRomSx,EFileShareReadersOnly) == KErrNone)
	{
		file.Close();
		ChipsetType = 1; // 48Gx
		Pref.RomFileName = filename;
	}
	else
	{
		iEikonEnv->InfoMsg(R_ROM_ERREUR);
		RomPresente = EFalse;
		User::After(3000000);
	}
*/
	if(!DEBUG) fsLogs.Close();
	filename = DefaultDrive;
	filename += KFicLogsUI;
	if(DEBUG) fileLogs.Replace(fsLogs,filename,EFileWrite);
	if(DEBUG) fileLogs.Write(_L8("ConstructL.\n"));

#ifdef __ER5__
	if(DEBUG) fileLogs.Write(_L8("Emu48ER5 v1.5\n"));
#endif
#ifdef __ER6__
	if(DEBUG) fileLogs.Write(_L8("Emu48ER6 v1.5\n"));
#endif
#ifdef __ER7__
	if(DEBUG) fileLogs.Write(_L8("Emu48ER7 v1.5 deb.\n"));
#endif


	if(!LoadPrefs())
	{
		if(ChipsetType == 3) Pref.zoom = 2;
		else Pref.zoom = 1;
		Pref.RedrawMode = 3;
#ifdef __ER6__
		Pref.zoom = 3;
		Pref.RedrawMode = 1;
#endif
#ifdef __ER7__
		Pref.zoom = 2;
		Pref.RedrawMode = 1;
#endif
		Pref.div4096 = 5;
		Pref.KeyUpEvents = ETrue;
		Pref.TimeKeyMin = TInt64(80000);
		Pref.Backup = EFalse;
	}

	if(file.Open(fsLogs,Pref.RomFileName,EFileShareReadersOnly) == KErrNone)
	{
		RomPresente = ETrue;
		file.Close();
	}
	else
	{
		iEikonEnv->InfoMsg(R_ROM_ERREUR);
		User::After(2000000);
		RomPresente = RomSelectL();
	}

	if(Pref.RomFileName.Length() > 6)
	{
		if(Pref.RomFileName.Right(7) == KFicRom49G) ChipsetType = 3;
		else if(Pref.RomFileName.Right(6) == KFicRomGx) ChipsetType = 2;
		else if(Pref.RomFileName.Right(6) == KFicRomSx) ChipsetType = 1;
		else RomPresente = EFalse;
	}

	if(!RomPresente)
	{
		if(DEBUG) fileLogs.Write(_L8("Erreur : Fichier Rom non present.\n"));
		iEikonEnv->InfoMsg(R_ROM_ERREUR);
		User::After(2000000);
		Exit();
	}

	//TRect fenetre(TPoint(0,0),TSize(333,156));

	Emu48Engine = new Engine;
	Emu48Engine->DefaultDrive = DefaultDrive;
	Emu48Engine->DefaultDriveBak = DefaultDriveBak;
	Emu48Engine->RomFileName = Pref.RomFileName;
	Emu48Engine->cCurrentRomType = ChipsetType;
	if(Pref.zoom == 1)
	{
		Emu48Engine->nLcdDoubled = 1;
		Emu48Engine->zoom = 1;
	}
	if(Pref.zoom == 2)
	{
		Emu48Engine->nLcdDoubled = 2;
		Emu48Engine->zoom = 2;
#ifdef __ER7__
		Emu48Engine->nLcdDoubled = 1;
#endif
	}
	if(Pref.zoom == 3)
	{
		Emu48Engine->nLcdDoubled = 2;
		Emu48Engine->zoom = 3;
	}
	if(DEBUG)
	{
		fileLogs.Write(_L8("Display Mode = "));
		strnum.Num((TInt)(iEikonEnv->ScreenDevice()->DisplayMode()));
		fileLogs.Write(strnum);
		fileLogs.Write(_L8(".\n"));
	}
	switch(iEikonEnv->ScreenDevice()->DisplayMode())
	{
		case EGray4 :
			Emu48Engine->DispMode = 1;
			if(DEBUG) fileLogs.Write(_L8("EGray4 2bpp.\n"));
			break;
		case EGray16 :
			Emu48Engine->DispMode = 1;
			if(DEBUG) fileLogs.Write(_L8("EGray16 4bpp.\n"));
			break;
		case EGray256 :
			Emu48Engine->DispMode = 2;
			if(DEBUG) fileLogs.Write(_L8("EGray256 8bpp.\n"));
			break;
		case EColor16 :
			Emu48Engine->DispMode = 1;
			if(DEBUG) fileLogs.Write(_L8("EColor16 4bpp.\n"));
			break;
		case EColor256 :
			Emu48Engine->DispMode = 2;
			if(DEBUG) fileLogs.Write(_L8("EColor256 8bpp.\n"));
			break;
		case EColor4K :
			Emu48Engine->DispMode = 2;
			if(DEBUG) fileLogs.Write(_L8("EColor4K 12bpp.\n"));
			break;
		case EColor64K :
			Emu48Engine->DispMode = 2;
			if(DEBUG) fileLogs.Write(_L8("EColor64K 16bpp.\n"));
			break;
#ifdef __ER5__
		default : Emu48Engine->DispMode = 1;
#else
		default : Emu48Engine->DispMode = 2;
#endif

	}
	Emu48Engine->RedrawMode = Pref.RedrawMode;
	Emu48Engine->div4096 = Pref.div4096;
	if(DEBUG) Emu48Engine->InitLogs();

	iEikonEnv->BusyMsgL(R_INIT_TEXTE);

	if(!Emu48Engine->Init(ETrue))
	{
		iEikonEnv->BusyMsgCancel();
		iEikonEnv->InfoMsg(R_MEMOIRE_ERREUR);
		User::After(3000000);
		Exit();
	}

	iEikonEnv->BusyMsgCancel();

	iAppView=new(ELeave) Emu48View;
	iAppView->DefaultDrive = DefaultDrive;
	iAppView->DefaultDriveBak = DefaultDriveBak;
	iAppView->ChipsetType = ChipsetType;
	iAppView->Emu48Engine = this->Emu48Engine;
	iAppView->ConstructL(Pref.zoom);
	AddToStackL(iAppView);
	iAppView->KeyUpEvents = Pref.KeyUpEvents;
	iAppView->TimeKeyMin = Pref.TimeKeyMin;

	iAppView->SetFocus(ETrue);

	Emu48Engine->iView = iAppView;
	iActiveEngine = new ActiveEngine(Emu48Engine);
	iActiveEngine->Start();

	if(DEBUG) fileLogs.Write(_L8("ConstructL Ok.\n"));
}


Emu48Ui::~Emu48Ui()
{
	if(DEBUG) fileLogs.Write(_L8("Fin Emu48UI.\n"));
	if(!SavePrefs())
	{
	}
	delete iActiveEngine;
	delete iAppView;
	delete Emu48Engine;
	if(DEBUG) 
	{
		fileLogs.Write(_L8("Fin Emu48UI Ok.\n"));
		fileLogs.Close();
		fsLogs.Close();
	}
}

void Emu48Ui::HandleCommandL(TInt aCommand)
{
	//if(DEBUG) fileLogs.Write(_L8("HandleCommandL.\n"));
	switch (aCommand)
	{
	case EEmu48Nouveau:
		NouveauConfirmDialog();
		break;
	case EEmu48Recharger:
		CmdRecharger();
		break;
	case EEmu48Sauver: 
		if(DEBUG) fileLogs.Write(_L8("Sauver.\n"));
#if 0
		iActiveEngine->Cancel();
		Emu48Engine->StopTimers();
		if(DEBUG) fileLogs.Write(_L8("StopTimers ok.\n"));
#endif
		Sauvegarde();
		break;

	case EEmu48Options:
		CmdDialog();
		break;
#ifndef __ER7__
	case EEikCmdZoomIn:
		if(Pref.zoom < 3)
		{
			Pref.zoom++;
			CmdVue(Pref.zoom);
		}
		break;
	case EEikCmdZoomOut:
		if((Pref.zoom > 1 && ChipsetType !=3)||(Pref.zoom > 2 && ChipsetType ==3))
		{
			Pref.zoom--;
			CmdVue(Pref.zoom);
		}
		break;
	case EEmu48Vue1:
		if(Pref.zoom != 1 && ChipsetType != 3) CmdVue(1);

		break;
	case EEmu48Vue2:
		if(Pref.zoom != 2) CmdVue(2);
		break;
	case EEmu48Vue3:
		if(Pref.zoom != 3) CmdVue(3);
		break;
#endif
	case EEmu48LoadObject:
		if(Emu48Engine->Chipset.Shutdn) CmdObjectOpenL();
		break;
	case EEmu48SaveObject:
		if(Emu48Engine->Chipset.Shutdn) CmdObjectSaveL();
		break;
	case EEikCmdEditCopy: //EEmu48Copier:
		if(!DEBUG) fsLogs.Connect();
		if(Emu48Engine->Chipset.Shutdn)
		{
			TRAPD(ret,doCopyL());
		}
		if(!DEBUG) fsLogs.Close();
		break;
	case EEikCmdEditPaste: //EEmu48Coller:
		if(!DEBUG) fsLogs.Connect();
		if(Emu48Engine->Chipset.Shutdn)
		{
			TRAPD(ret,doPasteL());
		}
		if(!DEBUG) fsLogs.Close();
		break;
	case EEmu48Reset:
		ResetConfirmDialog();
		break;
	case EEikCmdExit: 
		if(DEBUG) fileLogs.Write(_L8("Exit.\n"));
		iActiveEngine->Cancel();
		Emu48Engine->StopTimers();
		if(DEBUG) fileLogs.Write(_L8("StopTimers ok.\n"));
		if(Pref.Backup)
		{
			Sauvegarde();
		}
		Exit();
		break;
	}
	//if(DEBUG) fileLogs.Write(_L8("HandleCommandL Ok.\n"));
}

void Emu48Ui::CmdDialog()
{
	if(DEBUG) fileLogs.Write(_L8("CmdDialog.\n"));
	CEikDialog* dialog = new (ELeave) CEmu48DispDialog(this);
	if(DEBUG) fileLogs.Write(_L8("CmdDialog..\n"));
	if (dialog->ExecuteLD(R_EMU48_DISPLAY_DIALOG))
	{
		Emu48Engine->RedrawMode = Pref.RedrawMode;
		iAppView->KeyUpEvents = Pref.KeyUpEvents;
		iAppView->TimeKeyMin = Pref.TimeKeyMin;
		Emu48Engine->div4096 = Pref.div4096;
		if(DEBUG)
		{
			fileLogs.Write(_L8("Redraw mode = "));
			strnum.Num(Pref.RedrawMode);
			fileLogs.Write(strnum);
			fileLogs.Write(_L8(".\n"));
		}
	}
}

TBool Emu48Ui::RomSelectL()
{
	TUint ret;
	TBuf<4> fileExt;

	if(DEBUG) fileLogs.Write(_L8("RomSelectL.\n"));
	filename.SetMax();
	filename.FillZ();
	filename = DefaultDrive;
	filename.SetMax();
	fileExt = KFicRomExt;

	CEikFileOpenDialog* dialog=new(ELeave) CEikFileOpenDialog(&filename);
	if(DEBUG) fileLogs.Write(_L8("RomSelectL..\n"));
	dialog->SetShowSystem(ETrue);
	dialog->SetRequiredExtension(&fileExt);
	if (dialog->ExecuteLD(R_EIK_DIALOG_FILE_OPEN))
	{
		Pref.RomFileName = filename;
		if(DEBUG) fileLogs.Write(_L8("RomSelectL Ok.\n"));
		return ETrue;
	}
	if(DEBUG) fileLogs.Write(_L8("RomSelectL Nok.\n"));
	return EFalse;
}

void Emu48Ui::CmdObjectOpenL()
{
	TUint ret;
	filename.SetMax();
	filename.FillZ();
	filename = DefaultDrive;
	filename.SetMax();
	CEikFileOpenDialog* dialog=new(ELeave) CEikFileOpenDialog(&filename);
	dialog->SetShowSystem(ETrue);
	// If the dialog returns a filename, call OpenFileL() to open the file.
	if (dialog->ExecuteLD(R_EIK_DIALOG_FILE_OPEN))
	{
		if(DEBUG) fileLogs.Write(_L8("Load Object.\n"));
		ret = Emu48Engine->LoadObject(filename);
		switch (ret)
		{
			case 0 : // pas d'erreur
				if(ChipsetType!=3) iAppView->PressKey(32);
				else iAppView->PressKey(46);
				iAppView->KeyUpEvent1 = ETrue;
				break;
			case 1 :
				iEikonEnv->InfoMsg(R_MEMOIRE_ERREUR);
				break;
			case 2 :
				iEikonEnv->InfoMsg(R_MEMOIRE_HP48);
				break;
			default:
				iEikonEnv->InfoMsg(R_ERREUR);
				break;
		}
	}
}

void Emu48Ui::CmdObjectSaveL()
{
	TUint ret;
	//filename.SetMax();
	//filename.FillZ();
	filename = DefaultDrive;
	//filename.SetMax();
	CEikDialog* dialog=new(ELeave) CEikFileSaveAsDialog(&filename,NULL,NULL);
	if (dialog->ExecuteLD(R_EIK_DIALOG_FILE_SAVEAS))
	{
		if(DEBUG) fileLogs.Write(_L8("Save Object.\n"));
		ret = Emu48Engine->SaveObject(filename);
		switch (ret)
		{
			case 0 : // pas d'erreur
				iEikonEnv->InfoMsg(R_OBJET_SAUVE);
				break;
			case 1 :
				iEikonEnv->InfoMsg(R_SAUVE_RIEN);
				break;
			default:
				iEikonEnv->InfoMsg(R_ERREUR);
				break;
		}
	}
}

void Emu48Ui::doPasteL()
{
	TInt taille;
	TUint32 i;
	TReal value;

	if(DEBUG) fileLogs.Write(_L8("doPasteL.\n"));
	CClipboard* cb = NULL;
	TRAPD(ret,cb=CClipboard::NewForReadingL(fsLogs));
	CleanupStack::PushL(cb);
	if (ret!=KErrNone)
	{
		iEikonEnv->InfoMsg(R_COLLER_RIEN);
		User::Leave(ret);
	}
		
#ifndef _UNICODE
	TStreamId stid = (cb->StreamDictionary()).At(KClipboardUidTypePlainText8);
#else
	TStreamId stid = (cb->StreamDictionary()).At(KClipboardUidTypePlainText);
#endif
	if (stid == KNullStreamId)
	{
		iEikonEnv->InfoMsg(R_COLLER_RIEN);
		User::Leave(0);
	}

	if(DEBUG) fileLogs.Write(_L8("doPasteL quelque chose a coller.\n"));
	
	RStoreReadStream stream;
	stream.OpenLC(cb->Store(),stid);       // CleanupStack::PushL


	taille = stream.ReadInt32L();

	TAny* adrClip = User::Alloc(taille*2);
	if (adrClip == NULL)
	{
		iEikonEnv->InfoMsg(R_MEMOIRE_ERREUR);
		User::Leave(0);
	}
	TUint8* adr = (TUint8*)adrClip + taille;
	TRAP(ret,stream.ReadL(adr,taille));
	if (ret!=KErrNone)
	{
		User::FreeZ(adrClip);
		User::Leave(ret);
	}

//	adr = (TUint8*)adrClip;
//	Emu48Engine->WriteStack(adr,taille);

	// test HP49 integer
	TBool bInteger = EFalse;
	if(ChipsetType==3)
	{
		bInteger = ETrue;
		if(adr[0] < '0' || adr[0] > '9') bInteger = EFalse;
		if(adr[0] == '-' && taille > 1) bInteger = ETrue;
		for (i=1; i<taille; i++)
		{
			if(adr[i] < '0' || adr[i] > '9') bInteger = EFalse;
		}
	}

	if(bInteger)
	{
		if(DEBUG) fileLogs.Write(_L8("doPasteL HP49 Integer.\n"));
		adr = (TUint8*)adrClip;
		Emu48Engine->WriteStackInt(adr,taille);
	}
	else if(Emu48Engine->IsRealString(adr,taille,&value))
	{
		if(DEBUG) fileLogs.Write(_L8("doPasteL real.\n"));
		Emu48Engine->WriteStack(value);
	}
	else
	{
		if(DEBUG) fileLogs.Write(_L8("doPasteL string.\n"));
		adr = (TUint8*)adrClip;
		Emu48Engine->WriteStack(adr,taille);
	}

	User::FreeZ(adrClip);
	
	CleanupStack::PopAndDestroy(2); // stream et cb
	if(ChipsetType!=3) iAppView->PressKey(32);
	else iAppView->PressKey(46);
	iAppView->KeyUpEvent1 = ETrue;
	if(DEBUG) fileLogs.Write(_L8("doPasteL Ok.\n"));
}

void Emu48Ui::doCopyL()
{
	TUint32  dwAddress,dwSize,dwProlog;

	dwAddress = Emu48Engine->RPL_Pick(1);
	if (dwAddress == 0)		// pick address of level1 object
	{
		iEikonEnv->InfoMsg(R_COPIER_RIEN);
		User::Leave(0);
	}

	dwProlog = Emu48Engine->Read5(dwAddress);
	if(dwProlog == 0x2AFC) // tagged object (skipped if any)
	{
		dwAddress += 5; // address of tag length
		Emu48Engine->SkipTaggedData(&dwAddress);
		dwProlog = Emu48Engine->Read5(dwAddress);
	}

	switch(dwProlog)
	{
		case 0x02A2C: // string object
		{
			dwAddress += 5;							// address of string length
			dwSize = (Emu48Engine->Read5(dwAddress) - 5) / 2;	// length of string

			TAny* adrClip = User::Alloc(dwSize+1);  //dwSize +1
			if (adrClip == NULL)
			{
				iEikonEnv->InfoMsg(R_MEMOIRE_ERREUR);
				User::Leave(0);
			}

			TUint8* adr = (TUint8*)adrClip;
			Emu48Engine->ReadStack(adr,dwAddress,dwSize);
			if(DEBUG) fileLogs.Write(_L8("doCopyL ReadStack Ok.\n"));

			// Construct the clipboard object and prepare the 
			// clipboard for writing
			CClipboard* cb = CClipboard::NewForWritingLC(fsLogs);
			RStoreWriteStream  stream;
			TStreamId stid = stream.CreateLC(cb->Store());

			TRAPD(ret,stream.WriteInt32L(dwSize));
			TRAP(ret,stream.WriteL(adr,dwSize+1));
			if (ret!=KErrNone)
			{
				iEikonEnv->InfoMsg(R_ERREUR);
				User::FreeZ(adrClip);
				User::Leave(ret);
			}
			if(DEBUG) fileLogs.Write(_L8("doCopyL stream.write Ok.\n"));

			stream.CommitL();

#ifndef _UNICODE
			(cb->StreamDictionary()).AssignL(KClipboardUidTypePlainText8,stid);
#else
			(cb->StreamDictionary()).AssignL(KClipboardUidTypePlainText,stid);
#endif

			CleanupStack::PopAndDestroy(); //the stream
			
			// commit the clipboard - this writes the stream dictionary to the
			// store as the root stream and commits all changes to the store 
			cb->CommitL();

			CleanupStack::PopAndDestroy(); // Clipboard
			iEikonEnv->InfoMsg(R_COPIER_OK);
			if(DEBUG) fileLogs.Write(_L8("doCopyL string Ok.\n"));
			break;
		}
		case 0x02933:	// real object
		{
			dwAddress += 5;

			TReal value = 0;
			Emu48Engine->ReadStack(&value, dwAddress);

			// Construct the clipboard object and prepare the 
			// clipboard for writing
			CClipboard* cb = CClipboard::NewForWritingLC(fsLogs);

			// copy data as a real (for calc app)...
			cb->CopyToL(value);

			// ...and as a string (for all other apps)...
			RStoreWriteStream stream;
			TStreamId stid = stream.CreateLC(cb->Store());

			// ...using current decimal separator.
			TLocale locale;
			TRealFormat realFormat;
			realFormat.iPoint = locale.DecimalSeparator();
			realFormat.iType  = KRealFormatGeneral | KAllowThreeDigitExp;
			realFormat.iWidth = 22;
			// 22 gives you 15 digit mantissa, 3 digit exponent, ".", "e",
			// and two "-" (one each for mantissa and exponent). [EIKFPNE.CPP]

			TBuf8<23> buffer;
			buffer.Num(value, realFormat);

			TInt32 size = buffer.Length();
			buffer.SetLength(size+1);
			buffer[size]=0;
			TUint8* ptr = (TUint8*)buffer.Ptr();
			TRAPD(ret, stream.WriteInt32L(size));
			TRAP(ret, stream.WriteL(ptr, size+1)); // copier un TDes
			if (ret!=KErrNone)
			{
				iEikonEnv->InfoMsg(R_ERREUR);
				User::Leave(ret);
			}

			stream.CommitL();

#ifndef _UNICODE
			(cb->StreamDictionary()).AssignL(KClipboardUidTypePlainText8,stid);
#else
			(cb->StreamDictionary()).AssignL(KClipboardUidTypePlainText,stid);
#endif
			CleanupStack::PopAndDestroy(); //the stream

			// commit the clipboard - this writes the stream dictionary to the
			// store as the root stream and commits all changes to the store 
			cb->CommitL();

			CleanupStack::PopAndDestroy(); // Clipboard
			iEikonEnv->InfoMsg(R_COPIER_OK);
			if(DEBUG) fileLogs.Write(_L8("doCopyL real Ok.\n"));
			break;
		}
		case 0x02614: // HP49 integer object
		{
			dwAddress += 5;
			dwSize = (Emu48Engine->Read5(dwAddress) - 5);

			TAny* adrClip = User::Alloc(dwSize+dwSize+1);
			if (adrClip == NULL)
			{
				iEikonEnv->InfoMsg(R_MEMOIRE_ERREUR);
				User::Leave(0);
			}

			TUint8* adr = (TUint8*)adrClip;
			Emu48Engine->ReadStackInt(adr,dwAddress,dwSize);
			if(DEBUG) fileLogs.Write(_L8("doCopyL ReadStack Ok.\n"));

			// Construct the clipboard object and prepare the 
			// clipboard for writing
			CClipboard* cb = CClipboard::NewForWritingLC(fsLogs);
			RStoreWriteStream  stream;
			TStreamId stid = stream.CreateLC(cb->Store());
			if(*adr == '+')
			{
				adr++;
				dwSize--;
			}
			TRAPD(ret,stream.WriteInt32L(dwSize));
			TRAP(ret,stream.WriteL(adr,dwSize+1));
			if (ret!=KErrNone)
			{
				iEikonEnv->InfoMsg(R_ERREUR);
				User::FreeZ(adrClip);
				User::Leave(ret);
			}
			if(DEBUG) fileLogs.Write(_L8("doCopyL stream.write Ok.\n"));

			stream.CommitL();

#ifndef _UNICODE
			(cb->StreamDictionary()).AssignL(KClipboardUidTypePlainText8,stid);
#else
			(cb->StreamDictionary()).AssignL(KClipboardUidTypePlainText,stid);
#endif

			CleanupStack::PopAndDestroy(); //the stream
			
			// commit the clipboard - this writes the stream dictionary to the
			// store as the root stream and commits all changes to the store 
			cb->CommitL();

			CleanupStack::PopAndDestroy(); // Clipboard
			iEikonEnv->InfoMsg(R_COPIER_OK);
			if(DEBUG) fileLogs.Write(_L8("doCopyL string Ok.\n"));
			break;
		}
		default:
			iEikonEnv->InfoMsg(R_COPIER_RIEN);
			User::Leave(0);
			break;
	}

}

void Emu48Ui::CmdVue(TInt azoom)
{
	TBool KeyModeState;
	TInt64 OldTimeKeyMin;

	if(DEBUG) fileLogs.Write(_L8("CmdVue.\n"));
	Emu48Engine->StopTimers();
	iActiveEngine->Cancel();
	Emu48Engine->SupprimeLcd();
	KeyModeState = iAppView->KeyUpEvents;
	OldTimeKeyMin = iAppView->TimeKeyMin;

	RemoveFromStack(iAppView);
	delete iAppView;
	iAppView = NULL;
	Pref.zoom = azoom;


	if(DEBUG) fileLogs.Write(_L8("CmdVue iAppView.\n"));
	iAppView=new(ELeave) Emu48View;

	iAppView->DefaultDrive = DefaultDrive;
	iAppView->DefaultDriveBak = DefaultDriveBak;
	iAppView->ChipsetType = ChipsetType;
	iAppView->Emu48Engine = this->Emu48Engine;
	iAppView->ConstructL(Pref.zoom);

	if(Pref.zoom == 1)
	{
		if(DEBUG) fileLogs.Write(_L8("zoom 1.\n"));
		Emu48Engine->nLcdDoubled = 1;
		Emu48Engine->zoom = 1;

	}
	if(Pref.zoom == 2)
	{
		if(DEBUG) fileLogs.Write(_L8("zoom 2.\n"));
		Emu48Engine->nLcdDoubled = 2;
		Emu48Engine->zoom = 2;
	}
	if(Pref.zoom == 3)
	{
		if(DEBUG) fileLogs.Write(_L8("zoom 3.\n"));
		Emu48Engine->nLcdDoubled = 2;
		Emu48Engine->zoom = 3;
	}
	iAppView->KeyUpEvents = KeyModeState;
	iAppView->TimeKeyMin = OldTimeKeyMin;
	Emu48Engine->iView = iAppView;
	Emu48Engine->InitAnnunciator(EFalse);
	Emu48Engine->InitLcd(ETrue);
	Emu48Engine->UpdateContrast(0);

	AddToStackL(iAppView);
	iAppView->SetFocus(ETrue);
	Emu48Engine->nState = 1;
	Emu48Engine->nNextState = 0;
	iActiveEngine->Active();
	if(DEBUG) fileLogs.Write(_L8("CmdVue ok.\n"));
}

void Emu48Ui::ResetConfirmDialog()
{
#ifdef __ER5__
	TBuf<20> iTitre;
	TBuf<80> iTexte;
	CEikonEnv::Static()->ReadResource(iTitre, R_DLG_CONFIRM_TITRE);
	CEikonEnv::Static()->ReadResource(iTexte, R_DLG_CONFIRM_TEXTE);
	//TDesC* iTitre=iCoeEnv->AllocReadResourceL(R_DLG_CONFIRM_TITRE);
	//TDesC* iTexte=iCoeEnv->AllocReadResourceL(R_DLG_CONFIRM_TEXTE);
	CEikInfoDialog* dialog2 = new (ELeave) CEikInfoDialog(iTitre,iTexte);
	if(dialog2->ExecuteLD(R_EIK_DIALOG_QUERY))
	{
		iActiveEngine->Cancel();
		Emu48Engine->ResetCalc();

		iActiveEngine->Active();
	}
#else
	HBufC* iTitre = iEikonEnv->AllocReadResourceLC(R_DLG_CONFIRM_TITRE);
	HBufC* iTexte = iEikonEnv->AllocReadResourceLC(R_DLG_CONFIRM_TEXTE);

	if(iEikonEnv->QueryWinL(*iTitre,*iTexte))
	{
		iActiveEngine->Cancel();
		Emu48Engine->ResetCalc();
		iActiveEngine->Active();
	}
	else
	{
		// Do something here when the NO button is pressed.
	}

	// Pop and destroy the title and query text message heap descriptors.
	CleanupStack::PopAndDestroy(2);
#endif
}

void Emu48Ui::NouveauConfirmDialog()
{
#ifdef __ER5__
	TBuf<20> iTitre;


	TBuf<80> iTexte;
	CEikonEnv::Static()->ReadResource(iTitre, R_DLG_CONFIRM_TITRE);
	CEikonEnv::Static()->ReadResource(iTexte, R_DLG_CONFIRMN_TEXTE);
	CEikInfoDialog* dialog2 = new (ELeave) CEikInfoDialog(iTitre,iTexte);
	if(dialog2->ExecuteLD(R_EIK_DIALOG_QUERY))
	{
#endif
		if(DEBUG) fileLogs.Write(_L8("Nouveau.\n"));
		iActiveEngine->Cancel();
		Emu48Engine->StopTimers();
		TUint redraw = Emu48Engine->RedrawMode;
		if(Emu48Engine->SuppSauvegarde())
		{
			if(DEBUG) fileLogs.Write(_L8("Init(Efalse).\n"));
			if(!Emu48Engine->Init(EFalse))
			{
				Exit();
			}

			Emu48Engine->RedrawMode = redraw;
			iActiveEngine->Active();
		}
		else
		{
			Emu48Engine->StartTimers();
		}			
		if(DEBUG) fileLogs.Write(_L8("Nouveau Ok.\n"));
#ifdef __ER5__
	}
#endif
}

void Emu48Ui::CmdRecharger()
{
	if(DEBUG) fileLogs.Write(_L8("Recharger mem HP.\n"));
	iActiveEngine->Cancel();
	Emu48Engine->StopTimers();
	TUint redraw = Emu48Engine->RedrawMode;
	if(!Emu48Engine->Init(EFalse))
	{
		Exit();
	}
	Emu48Engine->RedrawMode = redraw;
	iActiveEngine->Active();
	if(DEBUG) fileLogs.Write(_L8("Recharger Ok.\n"));
}


void Emu48Ui::Sauvegarde()
{
	if(DEBUG) fileLogs.Write(_L8("sauve la mem HP.\n"));
	iEikonEnv->BusyMsgL(R_SAUV_TEXTE);
	if(Emu48Engine->SaveP0() && Emu48Engine->SaveP1() && Emu48Engine->SaveP2())
	{
		if(DEBUG) fileLogs.Write(_L8("Sauvegarde P0, P1 et P2 Ok.\n"));
	}
	else
	{
		if(DEBUG) fileLogs.Write(_L8("Sauvegarde P0, P1 et P2 Erreur !.\n"));
		User::InfoPrint(_L("Memory Error"));
		Emu48Engine->SuppSauvegarde();
	}
	if(Emu48Engine->SaveChipset())
	{
		if(DEBUG) fileLogs.Write(_L8("Sauvegarde Chipset Ok.\n"));
	}
	else
	{
		if(DEBUG) fileLogs.Write(_L8("Sauvegarde Chipset Erreur !.\n"));
		User::InfoPrint(_L("Memory Error"));
		Emu48Engine->SuppSauvegarde();
	}
#if 0
	if(Emu48Engine->SaveRom())
	{
		if(DEBUG) fileLogs.Write(_L8("Sauvegarde Rom Ok.\n"));
	}
	else
	{
		if(DEBUG) fileLogs.Write(_L8("Sauvegarde Rom Erreur !.\n"));
		User::InfoPrint(_L("Memory Error"));
	}
#endif
	iEikonEnv->BusyMsgCancel();
	if(DEBUG) fileLogs.Write(_L8("sauve la mem HP ok.\n"));
}

#ifndef __ER7__
void Emu48Ui::DynInitMenuPaneL(TInt aMenuId,CEikMenuPane* aMenuPane)
{
	if (aMenuId==R_MENU_AFFICHAGE)
	{
		if (Pref.zoom==1) aMenuPane->SetItemButtonState(EEmu48Vue1,EEikMenuItemSymbolOn);
		if (Pref.zoom==2) aMenuPane->SetItemButtonState(EEmu48Vue2,EEikMenuItemSymbolOn);
		if (Pref.zoom==3) aMenuPane->SetItemButtonState(EEmu48Vue3,EEikMenuItemSymbolOn);
	}
}
#endif

#ifdef __ER5__
void Emu48Ui::HandleKeyEventL(const TKeyEvent& aKeyEvent,TEventCode aType)
{
	iAppView->OfferKeyEventL(aKeyEvent,aType);
}
#endif

void Emu48Ui::HandleForegroundEventL(TBool aForeground)
{
	if(Emu48Engine)
	{
		Emu48Engine->FocusUi = aForeground;
		Emu48Engine->FocusChanged();
	}
}

TBool Emu48Ui::LoadPrefs()
{
	RFs fs;

	TBuf8<256> Buff1;
	TUint8* adr;
	TUint8* adrBuff;
	TUint taille;
	TInt dwRamSize;

	if(fs.Connect() != KErrNone)
	{
		if(DEBUG) fileLogs.Write(_L8("LoadPrefs Connection impossible a FileServer !\n"));
		return EFalse;
	}

	RFile fileRam;
	filename = DefaultDrive;
	filename += KFicPrefs;
	if(fileRam.Open(fs,filename,EFileShareReadersOnly) != KErrNone)
	{
		fs.Close();
		if(DEBUG) fileLogs.Write(_L8("Fichier prefs introuvable !\n"));
		return EFalse;
	}
	if (fileRam.Size(dwRamSize) != KErrNone)
	{
		fileRam.Close();
		fs.Close();
		if(DEBUG) fileLogs.Write(_L8("Erreur fichier prefs Open !\n"));
		return EFalse;
	}
	if (dwRamSize != sizeof(Pref))
	{
		fileRam.Close();
		fs.Close();
		if(DEBUG) fileLogs.Write(_L8("Fichier prefs taille invalide !\n"));
		return EFalse;
	}

	Buff1.SetLength(256);
	adrBuff = (TUint8*)Buff1.Ptr();
	adr = (TUint8*)&Pref;
	fileRam.Read(Buff1);
	taille = Buff1.Length();
	while(taille > 0) {
		Mem::Copy(adr,adrBuff,taille);
		adr += taille;
		fileRam.Read(Buff1);
		taille = Buff1.Length();
	}
	fileRam.Close();
	fs.Close();
	if(DEBUG) fileLogs.Write(_L8("LoadPrefs Ok.\n"));
	return ETrue;
}

TBool Emu48Ui::SavePrefs()
{
	RFs fs;
	RFile fileRam;
	TBuf8<256> Buff1;
	TUint8* adr;
	TUint cpt;
	TUint taille;
	TBool erreur;



	if(fs.Connect() != KErrNone)
	{

		if(DEBUG) fileLogs.Write(_L8("SavePrefs : Connection impossible a FileServer !\n"));
		return EFalse;
	}
	filename = DefaultDrive;
	filename += KFicPrefs;
	fileRam.Replace(fs,filename,EFileWrite);
	adr = (TUint8*)&Pref;
	taille = sizeof(Pref);
	cpt = 0;
	erreur = EFalse;
	Buff1.SetLength(MIN(256,taille-cpt));
	while(cpt < taille && !erreur)
	{
		Buff1.Copy(adr,Buff1.Length());
		if(fileRam.Write(Buff1) != KErrNone) erreur = ETrue;
		cpt += Buff1.Length();
		adr += Buff1.Length();
		Buff1.SetLength(MIN(256,taille-cpt));
	}
	fileRam.Close();
	fs.Close();
	if(erreur)
	{
		if(DEBUG) fileLogs.Write(_L8("SavePrefs : Erreur ecriture disk !. \n"));
		return EFalse;
	}
	if(DEBUG) fileLogs.Write(_L8("SavePrefs : Ok. \n"));
	return ETrue;
}

//-----------------------------------------------------------------------------------------
//------------------ CEmu48DispDialog -----------------------------------------------------
//-----------------------------------------------------------------------------------------

CEmu48DispDialog::CEmu48DispDialog(Emu48Ui* aUi)
	:iUi(aUi)
{
}

void CEmu48DispDialog::PreLayoutDynInitL()
{
	CEikHorOptionButtonList* myHorOpDisp = (CEikHorOptionButtonList*)(this->Control(EEmu48DispOptions));
#ifndef __ER7__
	CEikHorOptionButtonList* myHorOpKey = (CEikHorOptionButtonList*)(this->Control(EEmu48KeyOptions));
#endif
	CEikCheckBox* myCheckBox = (CEikCheckBox*)(this->Control(EEmu48Bak));

#ifndef __ER7__
	CEikNumberEditor* myNumberKey = (CEikNumberEditor*)(this->Control(EEmu48KeyMini));
	CEikNumberEditor* myNumberDiv = (CEikNumberEditor*)(this->Control(EEmu48div4096));
#else
	CQikNumberEditor* myNumberKey = (CQikNumberEditor*)(this->Control(EEmu48KeyMini));
	CQikNumberEditor* myNumberDiv = (CQikNumberEditor*)(this->Control(EEmu48div4096));
#endif
	switch(iUi->Pref.RedrawMode)
	{
		case 1: myHorOpDisp->SetButtonById(EEmu48DispOpt1); break;
		case 2: myHorOpDisp->SetButtonById(EEmu48DispOpt2); break;
		case 3: myHorOpDisp->SetButtonById(EEmu48DispOpt3); break;
		default: myHorOpDisp->SetButtonById(EEmu48DispOpt2); break;
	}

#ifndef __ER7__
	if(iUi->Pref.KeyUpEvents) myHorOpKey->SetButtonById(EEmu48KeyOpt1);
	else myHorOpKey->SetButtonById(EEmu48KeyOpt2);
#endif

#ifndef __ER7__
	myNumberKey->SetNumber((iUi->Pref.TimeKeyMin.operator/(1000)).Low());
	myNumberDiv->SetNumber(iUi->Pref.div4096);
#else
	myNumberKey->SetValueL((iUi->Pref.TimeKeyMin.operator/(1000)).Low());
	myNumberDiv->SetValueL(iUi->Pref.div4096);
#endif
	myCheckBox->SetState((iUi->Pref.Backup)?CEikCheckBox::ESet:CEikCheckBox::EClear);
}

TBool CEmu48DispDialog::OkToExitL(TInt /*aKeycode*/)
{
	CEikHorOptionButtonList* myHorOpDisp = (CEikHorOptionButtonList*)(this->Control(EEmu48DispOptions));
#ifndef __ER7__
	CEikHorOptionButtonList* myHorOpKey = (CEikHorOptionButtonList*)(this->Control(EEmu48KeyOptions));
#endif
	CEikCheckBox* myCheckBox = (CEikCheckBox*)(this->Control(EEmu48Bak));
#ifndef __ER7__
	CEikNumberEditor* myNumberKey = (CEikNumberEditor*)(this->Control(EEmu48KeyMini));
	CEikNumberEditor* myNumberDiv = (CEikNumberEditor*)(this->Control(EEmu48div4096));
#else
	CQikNumberEditor* myNumberKey = (CQikNumberEditor*)(this->Control(EEmu48KeyMini));
	CQikNumberEditor* myNumberDiv = (CQikNumberEditor*)(this->Control(EEmu48div4096));
#endif
	switch(myHorOpDisp->LabeledButtonId())
	{
		case EEmu48DispOpt1 : iUi->Pref.RedrawMode = 1; break;
		case EEmu48DispOpt2 : iUi->Pref.RedrawMode = 2; break;
		case EEmu48DispOpt3 : iUi->Pref.RedrawMode = 3; break;
	}

#ifndef __ER7__
	if(myHorOpKey->LabeledButtonId() == EEmu48KeyOpt1) iUi->Pref.KeyUpEvents = ETrue;
	else iUi->Pref.KeyUpEvents = EFalse;
#endif

#ifndef __ER7__
	iUi->Pref.TimeKeyMin = TInt64(myNumberKey->Number() * 1000);
	iUi->Pref.div4096 = (TUint8)(myNumberDiv->Number());
#else
	iUi->Pref.TimeKeyMin = TInt64(myNumberKey->Value() * 1000);
	iUi->Pref.div4096 = (TUint8)(myNumberDiv->Value());
#endif
	if(myCheckBox->State() == CEikCheckBox::ESet) iUi->Pref.Backup = ETrue;
	else iUi->Pref.Backup = EFalse;

	return ETrue;
}

//*****************************************************************************************
//------------------ Emu48View ------------------------------------------------------------
//*****************************************************************************************

void Emu48View::ConstructL(TInt azoom)
{
	ButtonMode = 0;
	OldButtonMode = 0;
	TInt bmp;

	if(DEBUG) fsLogs.Connect();
	filename = DefaultDrive;
	filename += KFicLogsView;
	if(DEBUG) fileLogs.Replace(fsLogs,filename,EFileWrite);
	
	if(DEBUG) fileLogs.Write(_L8("ConstructL deb 3.\n"));
	// Make this a window-owning control
	CreateWindowL();

	// Set its size and position
	zoom = azoom;


	if(zoom == 1)
	{
		MainX = 0;
		MainY = 0;
		MainSize = TSize(333,156);
		LcdX0 = 24;
		LcdY0 = 17;
		nLcdX = 131;
		nLcdY = 64;
	}
	if(zoom == 2)

	{
#ifndef __ER7__
		MainX = 0;
		MainY = 0;
		MainSize = TSize(480,160);
		LcdX0 = 6;
		LcdY0 = 11;
		nLcdX = 131*2;
		nLcdY = 64*2;
#else
		MainX = 0;
		MainY = 45;
		MainSize = TSize(208,256);
		LcdX0 = 34;
		LcdY0 = 18;
		nLcdX = 131;
		nLcdY = 64;
#endif
	}

	if(zoom == 3)
	{
		MainX = 0;
		MainY = 0;
#ifdef __ER5__
		MainSize = TSize(619,240);
		LcdX0 = 32;
		LcdY0 = 11;
		nLcdX = 131*2;
		nLcdY = 64*2;
#endif
#ifdef __ER6__
		if(ChipsetType == 3) // 49G
		{
			MainSize = TSize(619,200);
			LcdX0 = 54;
			LcdY0 = 11;
			nLcdX = 131*2;
			nLcdY = 64*2;
		}
		else
		{
			MainSize = TSize(619,200);
			LcdX0 = 32;
			LcdY0 = 11;
			nLcdX = 131*2;
			nLcdY = 64*2;
		}
#endif
	}
#ifndef __ER5__
		SetRect(TRect(TPoint(0,0),MainSize));
#else
		SetRectL(TRect(TPoint(0,0),MainSize));
#endif
	MainDrag = EFalse;
	SetPosition(TPoint(MainX,MainY));
	if(Emu48Engine->FBValid)
	{
		if(DEBUG) fileLogs.Write(_L8("FBValid = true.\n"));
		if(MainX+LcdX0 >= 0 && MainY+LcdY0 >= 0 && MainX+LcdX0+nLcdX < Emu48Engine->nFBX-1 && MainY+LcdY0+nLcdY < Emu48Engine->nFBY-1)
		{
			Emu48Engine->FBAffiche = ETrue;
			if(Emu48Engine->DispMode == 2) // 8bpp
			{
				if(DEBUG) fileLogs.Write(_L8("FBAffiche=true 8bpp.\n"));
				Emu48Engine->FBLcd = Emu48Engine->FBAdr + (MainY+LcdY0)*Emu48Engine->nFBX + MainX + LcdX0;
			}
			else // 4bpp
			{
				if(DEBUG) fileLogs.Write(_L8("FBAffiche=true 4bpp.\n"));
				Emu48Engine->FBLcd = Emu48Engine->FBAdr + (MainY+LcdY0)*Emu48Engine->nFBX / 2;
				Emu48Engine->FBLcd += (MainX+LcdX0)/2;
			}
		}
		else
		{
			Emu48Engine->FBAffiche = EFalse;
			if(DEBUG) fileLogs.Write(_L8("FBAffiche = false.\n"));
		}
	}
	else

	{
		Emu48Engine->FBAffiche = EFalse;
		if(DEBUG) fileLogs.Write(_L8("FBValid = FBAffiche = false.\n"));
	}
	
	
	if(zoom == 1)
	{
		hMainBitmap = new (ELeave) CFbsBitmap();
		filename = DefaultDrive;
		if(ChipsetType == 1)
		{
			if(DEBUG) fileLogs.Write(_L8("zoom 1, ChipsetType 1.\n"));
			filename += KMainSxBitmap;
			bmp = hMainBitmap->Load(filename,0);
			if(bmp == KErrNone)
			{
				if(DEBUG) fileLogs.Write(_L8("Load MainSxBitmap Ok.\n"));
			}
			else if(DEBUG)
			{
				fileLogs.Write(_L8("Creation bitmap : Erreur "));
				strnum.Num(bmp);
				fileLogs.Write(strnum);
				fileLogs.Write(_L8(".\n"));
			}
		}
		if(ChipsetType == 2)
		{
			if(DEBUG) fileLogs.Write(_L8("zoom 1, ChipsetType 2.\n"));
			filename += KMainGxBitmap;
			bmp = hMainBitmap->Load(filename,0);
			if(bmp == KErrNone)
			{
				if(DEBUG) fileLogs.Write(_L8("Load MainGxBitmap Ok.\n"));

			}
			else if(DEBUG)
			{
				fileLogs.Write(_L8("Creation bitmap : Erreur "));
				strnum.Num(bmp);
				fileLogs.Write(strnum);
				fileLogs.Write(_L8(".\n"));
			}
		}
		if(ChipsetType == 3)
		{
			if(DEBUG) fileLogs.Write(_L8("zoom 1, ChipsetType 3.\n"));
			filename += KMainGxBitmap;
			bmp = hMainBitmap->Load(filename,0);
			if(bmp == KErrNone)
			{
				if(DEBUG) fileLogs.Write(_L8("Load Main49GBitmap Ok.\n"));

			}
			else if(DEBUG)
			{
				fileLogs.Write(_L8("Creation bitmap : Erreur "));
				strnum.Num(bmp);
				fileLogs.Write(strnum);
				fileLogs.Write(_L8(".\n"));
			}
		}
	}
	if(zoom == 2)
	{
		hMainBitmap = new (ELeave) CFbsBitmap();
		hKeyaBitmap = new (ELeave) CFbsBitmap();
		hKeylBitmap = new (ELeave) CFbsBitmap();
		hKeyrBitmap = new (ELeave) CFbsBitmap();
		if(ChipsetType == 1)
		{
			if(DEBUG) fileLogs.Write(_L8("zoom 2, ChipsetType 1.\n"));
			filename = DefaultDrive;
			filename += KMain2SGxBitmap;
			bmp = hMainBitmap->Load(filename,0);
			if(bmp == KErrNone)
			{
				if(DEBUG) fileLogs.Write(_L8("Load Main2SGxBitmap Ok.\n"));
			}
			else if(DEBUG)
			{
				fileLogs.Write(_L8("Creation bitmap : Erreur "));
				strnum.Num(bmp);
				fileLogs.Write(strnum);
				fileLogs.Write(_L8(".\n"));
			}
			filename = DefaultDrive;
			filename += KKeya2SGxBitmap;
			bmp = hKeyaBitmap->Load(filename,0);
			if(bmp == KErrNone)
			{
				if(DEBUG) fileLogs.Write(_L8("Load Keya2SGxBitmap Ok.\n"));
			}
			else if(DEBUG)
			{
				fileLogs.Write(_L8("Creation bitmap : Erreur "));
				strnum.Num(bmp);
				fileLogs.Write(strnum);
				fileLogs.Write(_L8(".\n"));
			}
			filename = DefaultDrive;
			filename += KKeyl2SxBitmap;
			bmp = hKeylBitmap->Load(filename,0);
			if(bmp == KErrNone)
			{
				if(DEBUG) fileLogs.Write(_L8("Load Keyl2SxBitmap Ok.\n"));
			}
			else if(DEBUG)
			{
				fileLogs.Write(_L8("Creation bitmap : Erreur "));
				strnum.Num(bmp);
				fileLogs.Write(strnum);
				fileLogs.Write(_L8(".\n"));
			}
			filename = DefaultDrive;
			filename += KKeyr2SxBitmap;
			bmp = hKeyrBitmap->Load(filename,0);
			if(bmp == KErrNone)

			{
				if(DEBUG) fileLogs.Write(_L8("Load Keyr2SxBitmap Ok.\n"));
			}
			else if(DEBUG)
			{
				fileLogs.Write(_L8("Creation bitmap : Erreur "));
				strnum.Num(bmp);
				fileLogs.Write(strnum);
				fileLogs.Write(_L8(".\n"));
			}
		}
		if(ChipsetType == 2)
		{
			if(DEBUG) fileLogs.Write(_L8("zoom 2, ChipsetType 2.\n"));
			filename = DefaultDrive;
			filename += KMain2SGxBitmap;
			bmp = hMainBitmap->Load(filename,0);
			if(bmp == KErrNone)
			{

				if(DEBUG) fileLogs.Write(_L8("Load Main2SGxBitmap Ok.\n"));
			}
			else if(DEBUG)
			{
				fileLogs.Write(_L8("Creation bitmap : Erreur "));
				strnum.Num(bmp);
				fileLogs.Write(strnum);
				fileLogs.Write(_L8(".\n"));
			}
			filename = DefaultDrive;
			filename += KKeya2SGxBitmap;
			bmp = hKeyaBitmap->Load(filename,0);
			if(bmp == KErrNone)
			{
				if(DEBUG) fileLogs.Write(_L8("Load Keya2SGxBitmap Ok.\n"));
			}
			else if(DEBUG)
			{
				fileLogs.Write(_L8("Creation bitmap : Erreur "));
				strnum.Num(bmp);
				fileLogs.Write(strnum);
				fileLogs.Write(_L8(".\n"));
			}
			filename = DefaultDrive;
			filename += KKeyl2GxBitmap;
			bmp = hKeylBitmap->Load(filename,0);
			if(bmp == KErrNone)
			{
				if(DEBUG) fileLogs.Write(_L8("Load Keyl2GxBitmap Ok.\n"));
			}
			else if(DEBUG)
			{
				fileLogs.Write(_L8("Creation bitmap : Erreur "));
				strnum.Num(bmp);
				fileLogs.Write(strnum);
				fileLogs.Write(_L8(".\n"));
			}
			filename = DefaultDrive;
			filename += KKeyr2GxBitmap;
			bmp = hKeyrBitmap->Load(filename,0);
			if(bmp == KErrNone)
			{
				if(DEBUG) fileLogs.Write(_L8("Load Keyr2GxBitmap Ok.\n"));
			}
			else if(DEBUG)
			{
				fileLogs.Write(_L8("Creation bitmap : Erreur "));
				strnum.Num(bmp);
				fileLogs.Write(strnum);
				fileLogs.Write(_L8(".\n"));
			}
		}
		if(ChipsetType == 3)
		{
			if(DEBUG) fileLogs.Write(_L8("zoom 2, ChipsetType 3.\n"));
			filename = DefaultDrive;
			filename += KMain249GBitmap;
			bmp = hMainBitmap->Load(filename,0);
			if(bmp == KErrNone)
			{
				if(DEBUG) fileLogs.Write(_L8("Load Main249GBitmap Ok.\n"));
			}
			else if(DEBUG)
			{
				fileLogs.Write(_L8("Creation bitmap : Erreur "));
				strnum.Num(bmp);
				fileLogs.Write(strnum);
				fileLogs.Write(_L8(".\n"));
			}
			filename = DefaultDrive;
			filename += KKeya249GBitmap;
			bmp = hKeyaBitmap->Load(filename,0);
			if(bmp == KErrNone)
			{
				if(DEBUG) fileLogs.Write(_L8("Load Keya249GBitmap Ok.\n"));
			}
			else if(DEBUG)
			{
				fileLogs.Write(_L8("Creation bitmap : Erreur "));
				strnum.Num(bmp);
				fileLogs.Write(strnum);
				fileLogs.Write(_L8(".\n"));
			}
			filename = DefaultDrive;
			filename += KKeyl249GBitmap;
			bmp = hKeylBitmap->Load(filename,0);
			if(bmp == KErrNone)
			{
				if(DEBUG) fileLogs.Write(_L8("Load Keyl249GBitmap Ok.\n"));
			}
			else if(DEBUG)
			{
				fileLogs.Write(_L8("Creation bitmap : Erreur "));
				strnum.Num(bmp);
				fileLogs.Write(strnum);
				fileLogs.Write(_L8(".\n"));
			}
			filename = DefaultDrive;
			filename += KKeyr249GBitmap;
			bmp = hKeyrBitmap->Load(filename,0);
			if(bmp == KErrNone)
			{
				if(DEBUG) fileLogs.Write(_L8("Load Keyr249GBitmap Ok.\n"));
			}
			else if(DEBUG)
			{
				fileLogs.Write(_L8("Creation bitmap : Erreur "));
				strnum.Num(bmp);
				fileLogs.Write(strnum);
				fileLogs.Write(_L8(".\n"));
			}
		}
	}
	if(zoom == 3)
	{
		hMainBitmap = new (ELeave) CFbsBitmap();
		filename = DefaultDrive;
		if(ChipsetType == 1)
		{
			if(DEBUG) fileLogs.Write(_L8("zoom 3, ChipsetType 1.\n"));
			filename += KMain5SxBitmap;
			bmp = hMainBitmap->Load(filename,0);
			if(bmp == KErrNone)
			{
				if(DEBUG) fileLogs.Write(_L8("Load Main5SxBitmap Ok.\n"));
			}
			else if(DEBUG)
			{
				fileLogs.Write(_L8("Creation bitmap : Erreur "));
				strnum.Num(bmp);
				fileLogs.Write(strnum);
				fileLogs.Write(_L8(".\n"));
			}
		}
		if(ChipsetType == 2)
		{
			if(DEBUG) fileLogs.Write(_L8("zoom 3, ChipsetType 2.\n"));
			filename += KMain5GxBitmap;
			bmp = hMainBitmap->Load(filename,0);
			if(bmp == KErrNone)
			{
				if(DEBUG) fileLogs.Write(_L8("Load Main5GxBitmap Ok.\n"));
			}
			else if(DEBUG)
			{
				fileLogs.Write(_L8("Creation bitmap : Erreur "));
				strnum.Num(bmp);
				fileLogs.Write(strnum);
				fileLogs.Write(_L8(".\n"));
			}
		}
		if(ChipsetType == 3)
		{
			if(DEBUG) fileLogs.Write(_L8("zoom 3, ChipsetType 3.\n"));
			filename += KMain549GBitmap;
			bmp = hMainBitmap->Load(filename,0);
			if(bmp == KErrNone)
			{
				if(DEBUG) fileLogs.Write(_L8("Load Main549GBitmap Ok.\n"));
			}
			else if(DEBUG)
			{
				fileLogs.Write(_L8("Creation bitmap : Erreur "));
				strnum.Num(bmp);
				fileLogs.Write(strnum);
				fileLogs.Write(_L8(".\n"));
			}
		}
	}

	// Activate the control.
	ActivateL();

#ifdef __ER5__
	SetGloballyCapturing(EFalse);
	SetPointerCapture(ETrue);
	Window().PointerFilter(EPointerFilterDrag, 0); // autorise le drag
#endif
	if(Emu48Engine->DispMode == 1)
	{
		if(DEBUG) fileLogs.Write(_L8("SetRequiredDisplayMode(EGray16).\n"));
		Window().SetRequiredDisplayMode(EGray16); // frame buffer en 4bpp au lieu de 2bpp
	}
	else
	{
		if(DEBUG) fileLogs.Write(_L8("SetRequiredDisplayMode(EColor256).\n"));
		Window().SetRequiredDisplayMode(EColor256); // frame buffer en 8bpp
	}
	// Window().PointerFilter(EPointerFilterDrag, EPointerFilterDrag);  // filtre le drag

	// iWindow=Window();

	// iWindow = DrawableWindow();

	InitButton();
	ToucheIn = 0;
	ToucheOut = 0;
	//KeyPressed = EFalse;
	KeyPressedNb = 0;

	switch(User::Language())
	{
		case ELangFrench :
		{
			KeyMul = 'J';
			KeyDiv = 'K';
			KeyPlus = 'L';
			KeyMoins = 'M';
			break;
		}
		case ELangGerman :
		{
			KeyMul = 'H';
			KeyDiv = 'J';
			KeyPlus = 'K';
			KeyMoins = 'L';
			break;
		}
		case ELangEnglish :
		{
			KeyMul = 'Y';
			KeyDiv = 'U';
			KeyPlus = 'I';
			KeyMoins = 'O';
			break;
		}
		default :
		{
			KeyMul = 'Y';
			KeyDiv = 'U';
			KeyPlus = 'I';
			KeyMoins = 'O';
			break;
		}
	}

	

	if(DEBUG) fileLogs.Write(_L8("ConstructL Ok.\n"));
}

Emu48View::~Emu48View()
{
	if(DEBUG) fileLogs.Write(_L8("Fin Emu48View.\n"));
	Emu48Engine->iView = NULL;
	hMainBitmap->Reset();
	delete(hMainBitmap);
	if(zoom == 2)
	{
		hKeyaBitmap->Reset();
		delete(hKeyaBitmap);
		hKeylBitmap->Reset();
		delete(hKeylBitmap);
		hKeyrBitmap->Reset();
		delete(hKeyrBitmap);
	}
	if(DEBUG)
	{
		fileLogs.Write(_L8("Fin Emu48View Ok.\n"));
		fileLogs.Close();

		fsLogs.Close();
	}
}

void Emu48View::FocusChanged(TDrawNow aDrawNow)
{
	Emu48Engine->FocusView = IsFocused();
	Emu48Engine->FocusChanged();
}

void Emu48View::Draw(const TRect& /*aRect*/) const
{
	//User::InfoPrint(_L("Draw.\n"));

	CWindowGc& gc = SystemGc();
	TUint nId;

	switch(ButtonMode)
	{
		case 0: gc.BitBlt(TPoint(0,0), hMainBitmap, TRect(TPoint(0,0),MainSize)); break;
		case 1: gc.BitBlt(TPoint(0,0), hKeylBitmap, TRect(TPoint(0,0),MainSize)); break;
		case 2: gc.BitBlt(TPoint(0,0), hKeyrBitmap, TRect(TPoint(0,0),MainSize)); break;
		case 3: gc.BitBlt(TPoint(0,0), hKeyaBitmap, TRect(TPoint(0,0),MainSize)); break;
	}

	if(Emu48Engine->Chipset.dispon)
	{
		if(Emu48Engine->RedrawMode == 3)
		{
			Emu48Engine->RedrawMode = 1;
			Emu48Engine->UpdateMainDisplay(EFalse);
			Emu48Engine->UpdateMenuDisplay(EFalse);
			gc.BitBlt(TPoint(LcdX0,LcdY0), Emu48Engine->hLcdBitmap, TRect(TPoint(0,0),TSize(nLcdX,nLcdY)));
			Emu48Engine->RedrawMode = 3;
		}
		if(Emu48Engine->RedrawMode == 1 || Emu48Engine->RedrawMode == 2)
		{
			gc.BitBlt(TPoint(LcdX0,LcdY0), Emu48Engine->hLcdBitmap, TRect(TPoint(0,0),TSize(nLcdX,nLcdY)));
		}
		for(nId=0;nId<6;nId++)
		{
			if(Emu48Engine->pAnnunciator[nId].disp)
			{
				gc.BitBlt(TPoint(Emu48Engine->pAnnunciator[nId].destX,Emu48Engine->pAnnunciator[nId].destY), Emu48Engine->hAnnuncBitmap, TRect(TPoint(Emu48Engine->pAnnunciator[nId].srcX,Emu48Engine->pAnnunciator[nId].srcY),TSize(11,10)));
			}
		}
	}

	// iWindow.EndRedraw();
	// gc.Deactivate();
	// User::InfoPrint(_L("Draw Ok.\n"));
}



void Emu48View::UpdateWindow(CFbsBitmap* aLcdBitmap, TInt x0Dest, TInt y0Dest, TInt nx, TInt ny, TInt x0Src, TInt y0Src)

{
	//if(DEBUG) fileLogs.Write(_L8("UpdateWindow.\n"));
	CWindowGc& gc = SystemGc();
	ActivateGc();
	if(Emu48Engine->RedrawMode == 1 || Emu48Engine->RedrawMode == 2)
	{
		gc.BitBlt(TPoint(LcdX0 + x0Dest,LcdY0 + y0Dest), aLcdBitmap, TRect(TPoint(x0Src,y0Src),TSize(nx,ny)));
	}
#if 0
	//testNetbook
	else
	{
		gc.BitBlt(TPoint(LcdX0 + x0Dest,LcdY0 + y0Dest), aLcdBitmap, TRect(TPoint(x0Src,y0Src),TSize(nx,ny)));
	}
	// fin testNetbook
#endif

	DeactivateGc();
	// DrawNow();
}


void Emu48View::UpdateAnnunc(CFbsBitmap* aAnnuncBitmap, TInt x0Dest, TInt y0Dest, TInt nx, TInt ny, TInt x0Src, TInt y0Src)
{
	CWindowGc& gc = SystemGc();

	ActivateGc();
	gc.BitBlt(TPoint(x0Dest,y0Dest), aAnnuncBitmap, TRect(TPoint(x0Src,y0Src),TSize(nx,ny)));
	DeactivateGc();
}

void Emu48View::DrawButton(TUint bid)
{
	if(pButton[bid].b3d)
	{

		TPoint borig = TPoint(pButton[bid].Ox,pButton[bid].Oy);
		CWindowGc& gc = SystemGc();
		ActivateGc();
		if(pButton[bid].bDown)
		{
			gc.SetPenColor(TRgb(0x0));
			gc.DrawLine(borig,TPoint(pButton[bid].Ox, pButton[bid].Oy + pButton[bid].ny));
			gc.DrawLine(borig,TPoint(pButton[bid].Ox + pButton[bid].nx -1 , pButton[bid].Oy));
			if(zoom != 1) gc.DrawLine(TPoint(pButton[bid].Ox+1,pButton[bid].Oy+1),TPoint(pButton[bid].Ox+1, pButton[bid].Oy + pButton[bid].ny -1));
			if(zoom != 1) gc.DrawLine(TPoint(pButton[bid].Ox+1,pButton[bid].Oy+1),TPoint(pButton[bid].Ox + pButton[bid].nx -1 , pButton[bid].Oy+1));

			gc.SetPenColor(TRgb(0x00555555));
			gc.DrawLine(TPoint(pButton[bid].Ox + 1 ,pButton[bid].Oy + pButton[bid].ny -1),TPoint(pButton[bid].Ox + pButton[bid].nx - 1 ,pButton[bid].Oy + pButton[bid].ny - 1));
			gc.DrawLine(TPoint(pButton[bid].Ox + pButton[bid].nx -1,pButton[bid].Oy),TPoint(pButton[bid].Ox + pButton[bid].nx - 1 ,pButton[bid].Oy + pButton[bid].ny ));
			gc.SetPenColor(TRgb(0x0));
			//gc.BitBlt(TPoint(pButton[bid].Ox + 2,pButton[bid].Oy + 2), hMainBitmap, TRect(TPoint(pButton[bid].Ox + 1,pButton[bid].Oy + 1),TSize(pButton[bid].nx - 3,pButton[bid].ny - 3 )));
		}
		else
		{
			switch(ButtonMode)
			{
				case 0: gc.BitBlt(borig, hMainBitmap, TRect(borig,TSize(pButton[bid].nx,pButton[bid].ny))); break;
				case 1: gc.BitBlt(borig, hKeylBitmap, TRect(borig,TSize(pButton[bid].nx,pButton[bid].ny))); break;
				case 2: gc.BitBlt(borig, hKeyrBitmap, TRect(borig,TSize(pButton[bid].nx,pButton[bid].ny))); break;
				case 3: gc.BitBlt(borig, hKeyaBitmap, TRect(borig,TSize(pButton[bid].nx,pButton[bid].ny))); break;
			}
		}
		DeactivateGc();
	}
}

void Emu48View::DrawAllButtons()
{
	TUint bid;
	CWindowGc& gc = SystemGc();
	ActivateGc();
	if(DEBUG) fileLogs.Write(_L8("DrawAllButtons.\n"));
	for(bid=0; bid<51; bid++)
	{
		if(pButton[bid].b3d && pButton[bid].Ox != 9999)
		{

			TPoint borig = TPoint(pButton[bid].Ox,pButton[bid].Oy);
			if(pButton[bid].bDown)
			{
				switch(ButtonMode)

				{
					case 0: gc.BitBlt(borig, hMainBitmap, TRect(borig,TSize(pButton[bid].nx,pButton[bid].ny))); break;
					case 1: gc.BitBlt(borig, hKeylBitmap, TRect(borig,TSize(pButton[bid].nx,pButton[bid].ny))); break;
					case 2: gc.BitBlt(borig, hKeyrBitmap, TRect(borig,TSize(pButton[bid].nx,pButton[bid].ny))); break;
					case 3: gc.BitBlt(borig, hKeyaBitmap, TRect(borig,TSize(pButton[bid].nx,pButton[bid].ny))); break;
				}

				gc.SetPenColor(TRgb(0x0));
				gc.DrawLine(borig,TPoint(pButton[bid].Ox, pButton[bid].Oy + pButton[bid].ny));
				gc.DrawLine(borig,TPoint(pButton[bid].Ox + pButton[bid].nx -1 , pButton[bid].Oy));
				gc.DrawLine(TPoint(pButton[bid].Ox+1,pButton[bid].Oy+1),TPoint(pButton[bid].Ox+1, pButton[bid].Oy + pButton[bid].ny -1));
				gc.DrawLine(TPoint(pButton[bid].Ox+1,pButton[bid].Oy+1),TPoint(pButton[bid].Ox + pButton[bid].nx -1 , pButton[bid].Oy+1));
				gc.SetPenColor(TRgb(0x00555555));
				gc.DrawLine(TPoint(pButton[bid].Ox + 1 ,pButton[bid].Oy + pButton[bid].ny -1),TPoint(pButton[bid].Ox + pButton[bid].nx - 1 ,pButton[bid].Oy + pButton[bid].ny - 1));
				gc.DrawLine(TPoint(pButton[bid].Ox + pButton[bid].nx -1,pButton[bid].Oy),TPoint(pButton[bid].Ox + pButton[bid].nx - 1 ,pButton[bid].Oy + pButton[bid].ny ));
				gc.SetPenColor(TRgb(0x0));
				//gc.BitBlt(TPoint(pButton[bid].Ox + 2,pButton[bid].Oy + 2), hMainBitmap, TRect(TPoint(pButton[bid].Ox + 1,pButton[bid].Oy + 1),TSize(pButton[bid].nx - 3,pButton[bid].ny - 3 )));
			}
			else
			{
				switch(ButtonMode)
				{
					case 0: gc.BitBlt(borig, hMainBitmap, TRect(borig,TSize(pButton[bid].nx,pButton[bid].ny))); break;
					case 1: gc.BitBlt(borig, hKeylBitmap, TRect(borig,TSize(pButton[bid].nx,pButton[bid].ny))); break;
					case 2: gc.BitBlt(borig, hKeyrBitmap, TRect(borig,TSize(pButton[bid].nx,pButton[bid].ny))); break;
					case 3: gc.BitBlt(borig, hKeyaBitmap, TRect(borig,TSize(pButton[bid].nx,pButton[bid].ny))); break;
				}
			}
		}
	}
	DeactivateGc();
}

#ifdef __ER5__
TKeyResponse Emu48View::OfferKeyEventL(const TKeyEvent& aKeyEvent,TEventCode aType)
{
	if (aType==EEventKey)
	{
		if(ChipsetType==1 || ChipsetType==2)
		{
			switch (aKeyEvent.iCode)
			{
				case '0': PressKeyB(45); break;
				case '1': PressKeyB(41); break;
				case '2': PressKeyB(42); break;
				case '3': PressKeyB(43); break;
				case '4': PressKeyB(37); break;
				case '5': PressKeyB(38); break;
				case '6': PressKeyB(39); break;
				case '7': PressKeyB(33); break;
				case '8': PressKeyB(34); break;
				case '9': PressKeyB(35); break;
				case EKeyEnter: PressKeyB(26); break;
				case EKeyBackspace: PressKeyB(28); break;
				case EKeyDelete: PressKeyB(27); break;
				case EKeyEscape: PressKeyB(32); break;
				case EKeySpace: PressKeyB(47); break;
				case EKeyUpArrow: PressKeyB(10); break;
				case EKeyLeftArrow: PressKeyB(15); break;
				case EKeyDownArrow: PressKeyB(16); break;
				case EKeyRightArrow: PressKeyB(17); break;
				case '*': PressKeyB(40); break;
				case '/': PressKeyB(36); break;
				case '+': PressKeyB(48); break;
				case '-': PressKeyB(44); break;
				case 'a': PressKeyB(0); break;
				case 'b': PressKeyB(1); break;
				case 'c': PressKeyB(2); break;
				case 'd': PressKeyB(3); break;
				case 'e': PressKeyB(4); break;
				case 'f': PressKeyB(5); break;
				case 'A': PressKeyB(0); break;
				case 'B': PressKeyB(1); break;
				case 'C': PressKeyB(2); break;
				case 'D': PressKeyB(3); break;
				case 'E': PressKeyB(4); break;
				case 'F': PressKeyB(5); break;
				// case 'j': PressKeyB(40); break;
				// case 'k': PressKeyB(36); break;
				// case 'l': PressKeyB(48); break;
				// case 'm': PressKeyB(44); break;
				// case 'y': PressKeyB(40); break;
				// case 'u': PressKeyB(36); break;
				// case 'i': PressKeyB(48); break;
				// case 'o': PressKeyB(44); break;
				case '.': PressKeyB(46); break;
				case ',': PressKeyB(46); break;
				default:
				{
					if(aKeyEvent.iCode == KeyMul || aKeyEvent.iCode == KeyMul+32) PressKeyB(40);
					else if(aKeyEvent.iCode == KeyDiv || aKeyEvent.iCode == KeyDiv+32) PressKeyB(36);
					else if(aKeyEvent.iCode == KeyPlus || aKeyEvent.iCode == KeyPlus+32) PressKeyB(48);
					else if(aKeyEvent.iCode == KeyMoins || aKeyEvent.iCode == KeyMoins+32) PressKeyB(44);
				}
				break;
			}
		}
		if(ChipsetType==3)
		{
			switch (aKeyEvent.iCode)
			{
				case '0': PressKeyB(47); break;
				case '1': PressKeyB(42); break;
				case '2': PressKeyB(43); break;
				case '3': PressKeyB(44); break;
				case '4': PressKeyB(37); break;
				case '5': PressKeyB(38); break;
				case '6': PressKeyB(39); break;
				case '7': PressKeyB(32); break;
				case '8': PressKeyB(33); break;
				case '9': PressKeyB(34); break;
				case EKeyEnter: PressKeyB(50); break;
				case EKeyBackspace: PressKeyB(20); break;
				case EKeyEscape: PressKeyB(46); break;
				case EKeySpace: PressKeyB(49); break;
				case EKeyUpArrow: PressKeyB(13); break;
				case EKeyLeftArrow: PressKeyB(12); break;
				case EKeyDownArrow: PressKeyB(14); break;
				case EKeyRightArrow: PressKeyB(15); break;
				case '*': PressKeyB(35); break;
				case '/': PressKeyB(30); break;
				case '+': PressKeyB(45); break;
				case '-': PressKeyB(40); break;
				case 'a': PressKeyB(0); break;
				case 'b': PressKeyB(1); break;
				case 'c': PressKeyB(2); break;
				case 'd': PressKeyB(3); break;
				case 'e': PressKeyB(4); break;
				case 'f': PressKeyB(5); break;
				case 'A': PressKeyB(0); break;
				case 'B': PressKeyB(1); break;
				case 'C': PressKeyB(2); break;
				case 'D': PressKeyB(3); break;
				case 'E': PressKeyB(4); break;
				case 'F': PressKeyB(5); break;
				// case 'j': PressKeyB(35); break;
				// case 'k': PressKeyB(30); break;
				// case 'l': PressKeyB(45); break;
				// case 'm': PressKeyB(40); break;
				// case 'y': PressKeyB(35); break;
				// case 'u': PressKeyB(30); break;
				// case 'i': PressKeyB(45); break;
				// case 'o': PressKeyB(40); break;
				case '.': PressKeyB(48); break;
				case ',': PressKeyB(48); break;
				default:
				{
					if(aKeyEvent.iCode == KeyMul || aKeyEvent.iCode == KeyMul+32) PressKeyB(35);
					else if(aKeyEvent.iCode == KeyDiv || aKeyEvent.iCode == KeyDiv+32) PressKeyB(30);
					else if(aKeyEvent.iCode == KeyPlus || aKeyEvent.iCode == KeyPlus+32) PressKeyB(45);
					else if(aKeyEvent.iCode == KeyMoins || aKeyEvent.iCode == KeyMoins+32) PressKeyB(40);
				}
				break;
			}
		}
	}

	if (aType==EEventKeyUp)
	{
		// fileLogs.Write(_L8("EEventKeyUp.\n"));
		if(KeyPressedNb > 0)
		{
			KeyUpEvent1 = ETrue;
			ReleaseKey();
		}
	}
	return(EKeyWasConsumed);
}
#endif

#ifdef __ER6__
TKeyResponse Emu48View::OfferKeyEventL(const TKeyEvent& aKeyEvent,TEventCode aType)
{
	if (aType==EEventKey)
	{
		if(ChipsetType==1 || ChipsetType==2) 
		{
			switch (aKeyEvent.iCode)
			{
				case '0': PressKeyB(45); break;
				case '1': PressKeyB(41); break;
				case '2': PressKeyB(42); break;
				case '3': PressKeyB(43); break;
				case '4': PressKeyB(37); break;
				case '5': PressKeyB(38); break;
				case '6': PressKeyB(39); break;
				case '7': PressKeyB(33); break;
				case '8': PressKeyB(34); break;
				case '9': PressKeyB(35); break;
				case EKeyEnter: PressKeyB(26); break;
				case EKeyBackspace:
					if(aKeyEvent.iModifiers&EModifierShift) PressKeyB(27); // Del

					else PressKeyB(28);
					break;
				case EKeyEscape: PressKeyB(32); break;
				case EKeySpace: PressKeyB(47); break;
				case EKeyUpArrow: PressKeyB(10); break;
				case EKeyLeftArrow:
					if(aKeyEvent.iModifiers&EModifierShift) PressKeyB(30); // shift G.
					else PressKeyB(15);
					break;
				case EKeyDownArrow: PressKeyB(16); break;
				case EKeyRightArrow:
					if(aKeyEvent.iModifiers&EModifierShift) PressKeyB(31); // shift D.
					else PressKeyB(17);
					break;
				case '*': PressKeyB(40); break;
				case '/': PressKeyB(36); break;
				case '+': PressKeyB(48); break;
				case '-': PressKeyB(44); break;
				case 'a':
					if(aKeyEvent.iModifiers&EModifierShift) PressKeyB(29); // Alpha
					else PressKeyB(0);
					break;
				case 'b': PressKeyB(1); break;
				case 'c': PressKeyB(2); break;
				case 'd': PressKeyB(3); break;
				case 'e': PressKeyB(4); break;
				case 'f': PressKeyB(5); break;
				case 'g': PressKeyB(6); break;
				case 'h': PressKeyB(7); break;
				case 'i': PressKeyB(8); break;
				case 'j': PressKeyB(9); break;
				case 'k': PressKeyB(10); break;
				case 'l': PressKeyB(11); break;
				case 'm': PressKeyB(12); break;
				case 'n': PressKeyB(13); break;
				case 'o': PressKeyB(14); break;
				case 'p': PressKeyB(15); break;
				case 'q': PressKeyB(16); break;
				case 'r': PressKeyB(17); break;
				case 's': PressKeyB(18); break;
				case 't': PressKeyB(19); break;
				case 'u': PressKeyB(20); break;
				case 'v': PressKeyB(21); break;
				case 'w': PressKeyB(22); break;
				case 'x': PressKeyB(23); break;
				case 'y': PressKeyB(24); break;
				case 'z': PressKeyB(25); break;
				case 'A':
					if(aKeyEvent.iModifiers&EModifierShift) PressKeyB(29); // Alpha
					else PressKeyB(0);
					break;
				case 'B': PressKeyB(1); break;
				case 'C': PressKeyB(2); break;
				case 'D': PressKeyB(3); break;
				case 'E': PressKeyB(4); break;
				case 'F': PressKeyB(5); break;
				case 'G': PressKeyB(6); break;
				case 'H': PressKeyB(7); break;
				case 'I': PressKeyB(8); break;
				case 'J': PressKeyB(9); break;
				case 'K': PressKeyB(10); break;
				case 'L': PressKeyB(11); break;
				case 'M': PressKeyB(12); break;
				case 'N': PressKeyB(13); break;
				case 'O': PressKeyB(14); break;
				case 'P': PressKeyB(15); break;
				case 'Q': PressKeyB(16); break;
				case 'R': PressKeyB(17); break;
				case 'S': PressKeyB(18); break;
				case 'T': PressKeyB(19); break;
				case 'U': PressKeyB(20); break;
				case 'V': PressKeyB(21); break;
				case 'W': PressKeyB(22); break;
				case 'X': PressKeyB(23); break;
				case 'Y': PressKeyB(24); break;
				case 'Z': PressKeyB(25); break;

				case '.': PressKeyB(46); break;
				case ',': PressKeyB(46); break;
				default: break;
			}
		}
		if(ChipsetType==3)
		{
			switch (aKeyEvent.iCode)
			{
				case '0': PressKeyB(47); break;
				case '1': PressKeyB(42); break;
				case '2': PressKeyB(43); break;
				case '3': PressKeyB(44); break;
				case '4': PressKeyB(37); break;
				case '5': PressKeyB(38); break;
				case '6': PressKeyB(39); break;
				case '7': PressKeyB(32); break;
				case '8': PressKeyB(33); break;

				case '9': PressKeyB(34); break;
				case EKeyEnter: PressKeyB(50); break;
				case EKeyBackspace: PressKeyB(20); break;
				case EKeyEscape: PressKeyB(46); break;
				case EKeySpace: PressKeyB(49); break;
				case EKeyUpArrow: PressKeyB(13); break;
				case EKeyLeftArrow: PressKeyB(12); break;
				case EKeyDownArrow: PressKeyB(14); break;
				case EKeyRightArrow: PressKeyB(15); break;
				case '*': PressKeyB(35); break;
				case '/': PressKeyB(30); break;
				case '+': PressKeyB(45); break;
				case '-': PressKeyB(40); break;
				case 'a': PressKeyB(0); break;
				case 'b': PressKeyB(1); break;
				case 'c': PressKeyB(2); break;
				case 'd': PressKeyB(3); break;
				case 'e': PressKeyB(4); break;
				case 'f': PressKeyB(5); break;
				case 'j': PressKeyB(35); break;
				case 'k': PressKeyB(30); break;
				case 'l': PressKeyB(45); break;
				case 'm': PressKeyB(40); break;
				case 'y': PressKeyB(35); break;
				case 'u': PressKeyB(30); break;
				case 'i': PressKeyB(45); break;
				case 'o': PressKeyB(40); break;
				case '.': PressKeyB(48); break;
				case ',': PressKeyB(48); break;
				default: break;
			}
		}
	}

	if (aType==EEventKeyUp)
	{
		// fileLogs.Write(_L8("EEventKeyUp.\n"));
		if(KeyPressedNb > 0)
		{
			KeyUpEvent1 = ETrue;
			ReleaseKey();
		}
	}
	return(EKeyWasConsumed);
}
#endif

void Emu48View::HandlePointerEventL(const TPointerEvent& aPointerEvent)
{	
	// fileLogs.Write(_L8("HandlePointerEventL.\n"));
	TUint i;
	TInt MainXtmp;
	TInt MainYtmp;
	TBool finWhile;

	TPoint point = aPointerEvent.iPosition;
	TPoint ppoint = aPointerEvent.iParentPosition;
	switch (aPointerEvent.iType)
	{
	case TPointerEvent::EButton1Down:
	{
		i = 51;
		finWhile = EFalse;

		while(i>0 && !finWhile)
		{
			i--;
			if(point.iX >= pButton[i].Ox && point.iX <= (pButton[i].Ox + pButton[i].nx) && point.iY >= pButton[i].Oy && point.iY <= (pButton[i].Oy + pButton[i].ny) )
			{
				//ToucheOut = pButton[i].Out;
				//ToucheIn = pButton[i].In;
				pButton[i].bDown = ETrue;
				KeyPressedNb++;;
				KeyUpEvent1 = EFalse;
				//KeyPressedId = i;
				tst.HomeTime();
				KeyRefTime = tst.Int64();
				DrawButton(i);
				Emu48Engine->KeyboardEvent(ETrue,pButton[i].Out,pButton[i].In);
				finWhile = ETrue;
			}
		}
#ifdef __ER5__
		if(!finWhile)
		{
			SetGloballyCapturing(ETrue);
			SetPointerCapture(ETrue);
			MainDrag = ETrue;
			PointerX0 = point.iX;
			PointerY0 = point.iY;
		}
#endif
		break;
	}
	case TPointerEvent::EButton1Up:
	{
		if(MainDrag)
		{
			MainDrag = EFalse;
			SetGloballyCapturing(EFalse);
			SetPointerCapture(ETrue);
		}
		KeyUpEvent1 = ETrue;
		ReleaseKey();
		break;
	}
	case TPointerEvent::EDrag:
	{
		if(MainDrag)
		{
			MainXtmp = ppoint.iX-PointerX0;
			MainYtmp = ppoint.iY-PointerY0;
			if((MainXtmp+LcdX0)&1)
			{
			}
			else
			{
				MainX = MainXtmp;
				MainY = MainYtmp;
				if(Emu48Engine->FBValid)
				{
					if(MainX+LcdX0 >= 0 && MainY+LcdY0 >= 0 && MainX+LcdX0+nLcdX < Emu48Engine->nFBX-1 && MainY+LcdY0+nLcdY < Emu48Engine->nFBY-1)
					{
						Emu48Engine->FBAffiche = ETrue;
						if(Emu48Engine->DispMode == 2) // 8bpp
						{
							Emu48Engine->FBLcd = Emu48Engine->FBAdr + (MainY+LcdY0)*Emu48Engine->nFBX + MainX + LcdX0;
						}
						else // 4bpp
						{
							Emu48Engine->FBLcd = Emu48Engine->FBAdr + (MainY+LcdY0)*Emu48Engine->nFBX / 2;
							Emu48Engine->FBLcd += (MainX+LcdX0)/2;
						}
						//if((MainX+LcdX0)&1) Emu48Engine->FBDec = ETrue;
						//else Emu48Engine->FBDec = EFalse;

					}
					else Emu48Engine->FBAffiche = EFalse;
				}
				else Emu48Engine->FBAffiche = EFalse;
				SetPosition(TPoint(MainX,MainY));
			}
		}
		break;

	}
	default:
		break;
	}
	// fileLogs.Write(_L8("HandlePointerEventL Ok.\n"));

}

void Emu48View::ReleaseKey()
{
	tst.HomeTime();
	TInt64 KeyTime = tst.Int64();
	if(KeyPressedNb > 0)
	{
		if( (!KeyUpEvents || (KeyUpEvents && KeyUpEvent1)) && (KeyTime.operator-(KeyRefTime)).operator>(TimeKeyMin))

		{
			//Emu48Engine->KeyboardEvent(EFalse,ToucheOut,ToucheIn);
			//pButton[KeyPressedId].bDown = EFalse;
			//DrawButton(KeyPressedId);
			for(TInt t=0; t<51; t++)
			{
				if(pButton[t].Ox !=9999)
				{
					if(pButton[t].bDown)
					{
						Emu48Engine->KeyboardEvent(EFalse,pButton[t].Out,pButton[t].In);
						pButton[t].bDown = EFalse;
						DrawButton(t);
					}
				}
			}
			KeyPressedNb = 0;
			KeyUpEvent1 = EFalse;
		}
	}
}

void Emu48View::PressKey(TUint i)
{
//	if(!KeyPressed)
//	{
		//ToucheOut = pButton[i].Out;
		//ToucheIn = pButton[i].In;
		pButton[i].bDown = ETrue;
		tst.HomeTime();
		if(KeyPressedNb == 0) KeyRefTime = tst.Int64();
		KeyPressedNb++;
		//KeyPressedId = i;
		Emu48Engine->KeyboardEvent(ETrue,pButton[i].Out,pButton[i].In);
//	}
}


void Emu48View::PressKeyB(TUint i)
{
#if 0
	if(DEBUG) fileLogs.Write(_L8("PressKeyB :"));
	strnum.Num(i);
	fileLogs.Write(strnum);
	fileLogs.Write(_L8(".\n"));
#endif
//	if(!KeyPressed)
//	{
		//ToucheOut = pButton[i].Out;
		//ToucheIn = pButton[i].In;
		pButton[i].bDown = ETrue;
		tst.HomeTime();
		if(KeyPressedNb == 0) KeyRefTime = tst.Int64();
		KeyPressedNb++;
		//KeyPressedId = i;
		DrawButton(i);
		Emu48Engine->KeyboardEvent(ETrue,pButton[i].Out,pButton[i].In);
//	}
}


void Emu48View::InitButton()
{
	TInt t;
	for(t=0; t<51; t++)
	{
		pButton[t].bDown = EFalse;
		pButton[t].b3d = ETrue;
		pButton[t].Ox = 9999;
		pButton[t].Oy = 9999;
		pButton[t].Out = 0;
		pButton[t].In = 0;
		pButton[t].nx = 0;
		pButton[t].ny = 0;


	}

	if(ChipsetType==1 || ChipsetType==2)
	{
		if(zoom == 1)
		{
			pButton[0].Ox = 18; pButton[0].Oy = 87; pButton[0].Out = 1; pButton[0].In = 16; pButton[0].nx = 19; pButton[0].ny = 15;
			pButton[1].Ox = 43; pButton[1].Oy = 87; pButton[1].Out = 8; pButton[1].In = 16; pButton[1].nx = 19; pButton[1].ny = 15;
			pButton[2].Ox = 68; pButton[2].Oy = 87; pButton[2].Out = 8; pButton[2].In = 8; pButton[2].nx = 19; pButton[2].ny = 15;
			pButton[3].Ox = 93; pButton[3].Oy = 87; pButton[3].Out = 8; pButton[3].In = 4; pButton[3].nx = 19; pButton[3].ny = 15;
			pButton[4].Ox = 118; pButton[4].Oy = 87; pButton[4].Out = 8; pButton[4].In = 2; pButton[4].nx = 19; pButton[4].ny = 15;
			pButton[5].Ox = 143; pButton[5].Oy = 87; pButton[5].Out = 8; pButton[5].In = 1; pButton[5].nx = 19; pButton[5].ny = 15;
	
			pButton[6].Ox = 18; pButton[6].Oy = 112; pButton[6].Out = 2; pButton[6].In = 16; pButton[6].nx = 19; pButton[6].ny = 15;
			pButton[7].Ox = 43; pButton[7].Oy = 112; pButton[7].Out = 7; pButton[7].In = 16; pButton[7].nx = 19; pButton[7].ny = 15;
			pButton[8].Ox = 68; pButton[8].Oy = 112; pButton[8].Out = 7; pButton[8].In = 8; pButton[8].nx = 19; pButton[8].ny = 15;
			pButton[9].Ox = 93; pButton[9].Oy = 112; pButton[9].Out = 7; pButton[9].In = 4; pButton[9].nx = 19; pButton[9].ny = 15;
			pButton[10].Ox = 118; pButton[10].Oy = 112; pButton[10].Out = 7; pButton[10].In = 2; pButton[10].nx = 19; pButton[10].ny = 15;
			pButton[11].Ox = 143; pButton[11].Oy = 112; pButton[11].Out = 7; pButton[11].In = 1; pButton[11].nx = 19; pButton[11].ny = 15;
	
			pButton[12].Ox = 18; pButton[12].Oy = 137; pButton[12].Out = 0; pButton[12].In = 16; pButton[12].nx = 19; pButton[12].ny = 15;
			pButton[13].Ox = 43; pButton[13].Oy = 137; pButton[13].Out = 6; pButton[13].In = 16; pButton[13].nx = 19; pButton[13].ny = 15;
			pButton[14].Ox = 68; pButton[14].Oy = 137; pButton[14].Out = 6; pButton[14].In = 8; pButton[14].nx = 19; pButton[14].ny = 15;
			pButton[15].Ox = 93; pButton[15].Oy = 137; pButton[15].Out = 6; pButton[15].In = 4; pButton[15].nx = 19; pButton[15].ny = 15;
			pButton[16].Ox = 118; pButton[16].Oy = 137; pButton[16].Out = 6; pButton[16].In = 2; pButton[16].nx = 19; pButton[16].ny = 15;
			pButton[17].Ox = 143; pButton[17].Oy = 137; pButton[17].Out = 6; pButton[17].In = 1; pButton[17].nx = 19; pButton[17].ny = 15;
	
			pButton[18].Ox = 179; pButton[18].Oy = 12; pButton[18].Out = 3; pButton[18].In = 16; pButton[18].nx = 19; pButton[18].ny = 15;
			pButton[19].Ox = 204; pButton[19].Oy = 12; pButton[19].Out = 5; pButton[19].In = 16; pButton[19].nx = 19; pButton[19].ny = 15;
			pButton[20].Ox = 229; pButton[20].Oy = 12; pButton[20].Out = 5; pButton[20].In = 8; pButton[20].nx = 19; pButton[20].ny = 15;
			pButton[21].Ox = 254; pButton[21].Oy = 12; pButton[21].Out = 5; pButton[21].In = 4; pButton[21].nx = 19; pButton[21].ny = 15;
			pButton[22].Ox = 279; pButton[22].Oy = 12; pButton[22].Out = 5; pButton[22].In = 2; pButton[22].nx = 19; pButton[22].ny = 15;
			pButton[23].Ox = 304; pButton[23].Oy = 12; pButton[23].Out = 5; pButton[23].In = 1; pButton[23].nx = 19; pButton[23].ny = 15;
	
			pButton[24].Ox = 229; pButton[24].Oy = 37; pButton[24].Out = 4; pButton[24].In = 8; pButton[24].nx = 19; pButton[24].ny = 15; // +/-
			pButton[25].Ox = 254; pButton[25].Oy = 37; pButton[25].Out = 4; pButton[25].In = 4; pButton[25].nx = 19; pButton[25].ny = 15; // EEX
			pButton[26].Ox = 179; pButton[26].Oy = 37; pButton[26].Out = 4; pButton[26].In = 16; pButton[26].nx = 44; pButton[26].ny = 15; // Enter
			pButton[27].Ox = 279; pButton[27].Oy = 37; pButton[27].Out = 4; pButton[27].In = 2; pButton[27].nx = 19; pButton[27].ny = 15; // Del
			pButton[28].Ox = 304; pButton[28].Oy = 37; pButton[28].Out = 4; pButton[28].In = 1; pButton[28].nx = 19; pButton[28].ny = 15; // Back

			pButton[29].Ox = 179; pButton[29].Oy = 62; pButton[29].Out = 3; pButton[29].In = 32; pButton[29].nx = 19; pButton[29].ny = 15;
			pButton[30].Ox = 179; pButton[30].Oy = 87; pButton[30].Out = 2; pButton[30].In = 32; pButton[30].nx = 19; pButton[30].ny = 15;
			pButton[31].Ox = 179; pButton[31].Oy = 112; pButton[31].Out = 1; pButton[31].In = 32; pButton[31].nx = 19; pButton[31].ny = 15;
			pButton[32].Ox = 179; pButton[32].Oy = 137; pButton[32].Out = 0; pButton[32].In = 32768; pButton[32].nx = 19; pButton[32].ny = 15;
	
			pButton[33].Ox = 209; pButton[33].Oy = 62; pButton[33].Out = 3; pButton[33].In = 8; pButton[33].nx = 24; pButton[33].ny = 15;
			pButton[34].Ox = 239; pButton[34].Oy = 62; pButton[34].Out = 3; pButton[34].In = 4; pButton[34].nx = 24; pButton[34].ny = 15;
			pButton[35].Ox = 269; pButton[35].Oy = 62; pButton[35].Out = 3; pButton[35].In = 2; pButton[35].nx = 24; pButton[35].ny = 15;
			pButton[36].Ox = 299; pButton[36].Oy = 62; pButton[36].Out = 3; pButton[36].In = 1; pButton[36].nx = 24; pButton[36].ny = 15;
	
			pButton[37].Ox = 209; pButton[37].Oy = 87; pButton[37].Out = 2; pButton[37].In = 8; pButton[37].nx = 24; pButton[37].ny = 15;
			pButton[38].Ox = 239; pButton[38].Oy = 87; pButton[38].Out = 2; pButton[38].In = 4; pButton[38].nx = 24; pButton[38].ny = 15;
			pButton[39].Ox = 269; pButton[39].Oy = 87; pButton[39].Out = 2; pButton[39].In = 2; pButton[39].nx = 24; pButton[39].ny = 15;
			pButton[40].Ox = 299; pButton[40].Oy = 87; pButton[40].Out = 2; pButton[40].In = 1; pButton[40].nx = 24; pButton[40].ny = 15;
	
			pButton[41].Ox = 209; pButton[41].Oy = 112; pButton[41].Out = 1; pButton[41].In = 8; pButton[41].nx = 24; pButton[41].ny = 15;
			pButton[42].Ox = 239; pButton[42].Oy = 112; pButton[42].Out = 1; pButton[42].In = 4; pButton[42].nx = 24; pButton[42].ny = 15;
			pButton[43].Ox = 269; pButton[43].Oy = 112; pButton[43].Out = 1; pButton[43].In = 2; pButton[43].nx = 24; pButton[43].ny = 15;
			pButton[44].Ox = 299; pButton[44].Oy = 112; pButton[44].Out = 1; pButton[44].In = 1; pButton[44].nx = 24; pButton[44].ny = 15;
	
			pButton[45].Ox = 209; pButton[45].Oy = 137; pButton[45].Out = 0; pButton[45].In = 8; pButton[45].nx = 24; pButton[45].ny = 15;
			pButton[46].Ox = 239; pButton[46].Oy = 137; pButton[46].Out = 0; pButton[46].In = 4; pButton[46].nx = 24; pButton[46].ny = 15;
			pButton[47].Ox = 269; pButton[47].Oy = 137; pButton[47].Out = 0; pButton[47].In = 2; pButton[47].nx = 24; pButton[47].ny = 15;

			pButton[48].Ox = 299; pButton[48].Oy = 137; pButton[48].Out = 0; pButton[48].In = 1; pButton[48].nx = 24; pButton[48].ny = 15;
		}
		if(zoom == 2)
		{
#ifndef __ER7__
			// ER5
			pButton[0].Ox = 6; pButton[0].Oy = 123; pButton[0].Out = 1; pButton[0].In = 16; pButton[0].nx = 42; pButton[0].ny = 16; pButton[0].b3d = EFalse;
			pButton[1].Ox = 50; pButton[1].Oy = 123; pButton[1].Out = 8; pButton[1].In = 16; pButton[1].nx = 42; pButton[1].ny = 16; pButton[1].b3d = EFalse;
			pButton[2].Ox = 94; pButton[2].Oy = 123; pButton[2].Out = 8; pButton[2].In = 8; pButton[2].nx = 42; pButton[2].ny = 16; pButton[2].b3d = EFalse;
			pButton[3].Ox = 138; pButton[3].Oy = 123; pButton[3].Out = 8; pButton[3].In = 4; pButton[3].nx = 42; pButton[3].ny = 16; pButton[3].b3d = EFalse;
			pButton[4].Ox = 182; pButton[4].Oy = 123; pButton[4].Out = 8; pButton[4].In = 2; pButton[4].nx = 42; pButton[4].ny = 16; pButton[4].b3d = EFalse;
			pButton[5].Ox = 226; pButton[5].Oy = 123; pButton[5].Out = 8; pButton[5].In = 1; pButton[5].nx = 42; pButton[5].ny = 16; pButton[5].b3d = EFalse;
	
			pButton[6].Ox = 1; pButton[6].Oy = 140; pButton[6].Out = 2; pButton[6].In = 16; pButton[6].nx = 22; pButton[6].ny = 19; //MTH
			pButton[7].Ox = 23; pButton[7].Oy = 140; pButton[7].Out = 7; pButton[7].In = 16; pButton[7].nx = 22; pButton[7].ny = 19; //PRG
			pButton[8].Ox = 45; pButton[8].Oy = 140; pButton[8].Out = 7; pButton[8].In = 8; pButton[8].nx = 22; pButton[8].ny = 19; //CST
			pButton[9].Ox = 67; pButton[9].Oy = 140; pButton[9].Out = 7; pButton[9].In = 4; pButton[9].nx = 22; pButton[9].ny = 19; //VAR
	
			pButton[12].Ox = 89; pButton[12].Oy = 140; pButton[12].Out = 0; pButton[12].In = 16; pButton[12].nx = 22; pButton[12].ny = 19; //'
			pButton[13].Ox = 111; pButton[13].Oy = 140; pButton[13].Out = 6; pButton[13].In = 16; pButton[13].nx = 22; pButton[13].ny = 19; //STO
			pButton[14].Ox = 133; pButton[14].Oy = 140; pButton[14].Out = 6; pButton[14].In = 8; pButton[14].nx = 22; pButton[14].ny = 19; //EVAL
	
			pButton[10].Ox = 155; pButton[10].Oy = 140; pButton[10].Out = 7; pButton[10].In = 2; pButton[10].nx = 24; pButton[10].ny = 19; //up
			pButton[16].Ox = 179; pButton[16].Oy = 140; pButton[16].Out = 6; pButton[16].In = 2; pButton[16].nx = 24; pButton[16].ny = 19; //down
			pButton[15].Ox = 203; pButton[15].Oy = 140; pButton[15].Out = 6; pButton[15].In = 4; pButton[15].nx = 24; pButton[15].ny = 19; //left
			pButton[17].Ox = 227; pButton[17].Oy = 140; pButton[17].Out = 6; pButton[17].In = 1; pButton[17].nx = 24; pButton[17].ny = 19; //right
			pButton[11].Ox = 251; pButton[11].Oy = 140; pButton[11].Out = 7; pButton[11].In = 1; pButton[11].nx = 24; pButton[11].ny = 19; //NEXT
	
			pButton[18].Ox = 275; pButton[18].Oy = 4; pButton[18].Out = 3; pButton[18].In = 16; pButton[18].nx = 34; pButton[18].ny = 25;
			pButton[19].Ox = 309; pButton[19].Oy = 4; pButton[19].Out = 5; pButton[19].In = 16; pButton[19].nx = 34; pButton[19].ny = 25;
			pButton[20].Ox = 343; pButton[20].Oy = 4; pButton[20].Out = 5; pButton[20].In = 8; pButton[20].nx = 34; pButton[20].ny = 25;
			pButton[21].Ox = 377; pButton[21].Oy = 4; pButton[21].Out = 5; pButton[21].In = 4; pButton[21].nx = 34; pButton[21].ny = 25;
			pButton[22].Ox = 411; pButton[22].Oy = 4; pButton[22].Out = 5; pButton[22].In = 2; pButton[22].nx = 34; pButton[22].ny = 25;
			pButton[23].Ox = 445; pButton[23].Oy = 4; pButton[23].Out = 5; pButton[23].In = 1; pButton[23].nx = 34; pButton[23].ny = 25;
	
			pButton[26].Ox = 275; pButton[26].Oy = 30; pButton[26].Out = 4; pButton[26].In = 16; pButton[26].nx = 68; pButton[26].ny = 25; //Enter
			pButton[24].Ox = 343; pButton[24].Oy = 30; pButton[24].Out = 4; pButton[24].In = 8; pButton[24].nx = 34; pButton[24].ny = 25; // y
			pButton[25].Ox = 377; pButton[25].Oy = 30; pButton[25].Out = 4; pButton[25].In = 4; pButton[25].nx = 34; pButton[25].ny = 25; // z
			pButton[27].Ox = 411; pButton[27].Oy = 30; pButton[27].Out = 4; pButton[27].In = 2; pButton[27].nx = 34; pButton[27].ny = 25; //del
			pButton[28].Ox = 445; pButton[28].Oy = 30; pButton[28].Out = 4; pButton[28].In = 1; pButton[28].nx = 34; pButton[28].ny = 25; //backspace
	
			pButton[29].Ox = 275; pButton[29].Oy = 56; pButton[29].Out = 3; pButton[29].In = 32; pButton[29].nx = 28; pButton[29].ny = 25; //alpha
			pButton[30].Ox = 275; pButton[30].Oy = 82; pButton[30].Out = 2; pButton[30].In = 32; pButton[30].nx = 28; pButton[30].ny = 25; //shift G.
			pButton[31].Ox = 275; pButton[31].Oy = 108; pButton[31].Out = 1; pButton[31].In = 32; pButton[31].nx = 28; pButton[31].ny = 25; //shift D.
			pButton[32].Ox = 275; pButton[32].Oy = 134; pButton[32].Out = 0; pButton[32].In = 32768; pButton[32].nx = 28; pButton[32].ny = 25; // on
	
			pButton[33].Ox = 303; pButton[33].Oy = 56; pButton[33].Out = 3; pButton[33].In = 8; pButton[33].nx = 44; pButton[33].ny = 25;
			pButton[34].Ox = 347; pButton[34].Oy = 56; pButton[34].Out = 3; pButton[34].In = 4; pButton[34].nx = 44; pButton[34].ny = 25;
			pButton[35].Ox = 391; pButton[35].Oy = 56; pButton[35].Out = 3; pButton[35].In = 2; pButton[35].nx = 44; pButton[35].ny = 25;
			pButton[36].Ox = 435; pButton[36].Oy = 56; pButton[36].Out = 3; pButton[36].In = 1; pButton[36].nx = 44; pButton[36].ny = 25;
	
			pButton[37].Ox = 303; pButton[37].Oy = 82; pButton[37].Out = 2; pButton[37].In = 8; pButton[37].nx = 44; pButton[37].ny = 25;
			pButton[38].Ox = 347; pButton[38].Oy = 82; pButton[38].Out = 2; pButton[38].In = 4; pButton[38].nx = 44; pButton[38].ny = 25;
			pButton[39].Ox = 391; pButton[39].Oy = 82; pButton[39].Out = 2; pButton[39].In = 2; pButton[39].nx = 44; pButton[39].ny = 25;
			pButton[40].Ox = 435; pButton[40].Oy = 82; pButton[40].Out = 2; pButton[40].In = 1; pButton[40].nx = 44; pButton[40].ny = 25;
	
			pButton[41].Ox = 303; pButton[41].Oy = 108; pButton[41].Out = 1; pButton[41].In = 8; pButton[41].nx = 44; pButton[41].ny = 25;
			pButton[42].Ox = 347; pButton[42].Oy = 108; pButton[42].Out = 1; pButton[42].In = 4; pButton[42].nx = 44; pButton[42].ny = 25;
			pButton[43].Ox = 391; pButton[43].Oy = 108; pButton[43].Out = 1; pButton[43].In = 2; pButton[43].nx = 44; pButton[43].ny = 25;
			pButton[44].Ox = 435; pButton[44].Oy = 108; pButton[44].Out = 1; pButton[44].In = 1; pButton[44].nx = 44; pButton[44].ny = 25;
	
			pButton[45].Ox = 303; pButton[45].Oy = 134; pButton[45].Out = 0; pButton[45].In = 8; pButton[45].nx = 44; pButton[45].ny = 25;
			pButton[46].Ox = 347; pButton[46].Oy = 134; pButton[46].Out = 0; pButton[46].In = 4; pButton[46].nx = 44; pButton[46].ny = 25;
			pButton[47].Ox = 391; pButton[47].Oy = 134; pButton[47].Out = 0; pButton[47].In = 2; pButton[47].nx = 44; pButton[47].ny = 25;
			pButton[48].Ox = 435; pButton[48].Oy = 134; pButton[48].Out = 0; pButton[48].In = 1; pButton[48].nx = 44; pButton[48].ny = 25;
#else
			// ER7
			pButton[0].Ox = 28; pButton[0].Oy = 88; pButton[0].Out = 1; pButton[0].In = 16; pButton[0].nx = 19; pButton[0].ny = 15;
			pButton[1].Ox = 53; pButton[1].Oy = 88; pButton[1].Out = 8; pButton[1].In = 16; pButton[1].nx = 19; pButton[1].ny = 15;
			pButton[2].Ox = 78; pButton[2].Oy = 88; pButton[2].Out = 8; pButton[2].In = 8; pButton[2].nx = 19; pButton[2].ny = 15;
			pButton[3].Ox = 103; pButton[3].Oy = 88; pButton[3].Out = 8; pButton[3].In = 4; pButton[3].nx = 19; pButton[3].ny = 15;
			pButton[4].Ox = 128; pButton[4].Oy = 88; pButton[4].Out = 8; pButton[4].In = 2; pButton[4].nx = 19; pButton[4].ny = 15;
			pButton[5].Ox = 153; pButton[5].Oy = 88; pButton[5].Out = 8; pButton[5].In = 1; pButton[5].nx = 19; pButton[5].ny = 15;
	
			pButton[6].Ox = 28; pButton[6].Oy = 106; pButton[6].Out = 2; pButton[6].In = 16; pButton[6].nx = 19; pButton[6].ny = 15;
			pButton[7].Ox = 53; pButton[7].Oy = 106; pButton[7].Out = 7; pButton[7].In = 16; pButton[7].nx = 19; pButton[7].ny = 15;
			pButton[8].Ox = 78; pButton[8].Oy = 106; pButton[8].Out = 7; pButton[8].In = 8; pButton[8].nx = 19; pButton[8].ny = 15;
			pButton[9].Ox = 103; pButton[9].Oy = 106; pButton[9].Out = 7; pButton[9].In = 4; pButton[9].nx = 19; pButton[9].ny = 15;
			pButton[10].Ox = 128; pButton[10].Oy = 106; pButton[10].Out = 7; pButton[10].In = 2; pButton[10].nx = 19; pButton[10].ny = 15;
			pButton[11].Ox = 153; pButton[11].Oy = 106; pButton[11].Out = 7; pButton[11].In = 1; pButton[11].nx = 19; pButton[11].ny = 15;
	
			pButton[12].Ox = 28; pButton[12].Oy = 124; pButton[12].Out = 0; pButton[12].In = 16; pButton[12].nx = 19; pButton[12].ny = 15;
			pButton[13].Ox = 53; pButton[13].Oy = 124; pButton[13].Out = 6; pButton[13].In = 16; pButton[13].nx = 19; pButton[13].ny = 15;
			pButton[14].Ox = 78; pButton[14].Oy = 124; pButton[14].Out = 6; pButton[14].In = 8; pButton[14].nx = 19; pButton[14].ny = 15;
			pButton[15].Ox = 103; pButton[15].Oy = 124; pButton[15].Out = 6; pButton[15].In = 4; pButton[15].nx = 19; pButton[15].ny = 15;
			pButton[16].Ox = 128; pButton[16].Oy = 124; pButton[16].Out = 6; pButton[16].In = 2; pButton[16].nx = 19; pButton[16].ny = 15;
			pButton[17].Ox = 153; pButton[17].Oy = 124; pButton[17].Out = 6; pButton[17].In = 1; pButton[17].nx = 19; pButton[17].ny = 15;
	
			pButton[18].Ox = 28; pButton[18].Oy = 142; pButton[18].Out = 3; pButton[18].In = 16; pButton[18].nx = 19; pButton[18].ny = 15;
			pButton[19].Ox = 53; pButton[19].Oy = 142; pButton[19].Out = 5; pButton[19].In = 16; pButton[19].nx = 19; pButton[19].ny = 15;
			pButton[20].Ox = 78; pButton[20].Oy = 142; pButton[20].Out = 5; pButton[20].In = 8; pButton[20].nx = 19; pButton[20].ny = 15;
			pButton[21].Ox = 103; pButton[21].Oy = 142; pButton[21].Out = 5; pButton[21].In = 4; pButton[21].nx = 19; pButton[21].ny = 15;
			pButton[22].Ox = 128; pButton[22].Oy = 142; pButton[22].Out = 5; pButton[22].In = 2; pButton[22].nx = 19; pButton[22].ny = 15;
			pButton[23].Ox = 153; pButton[23].Oy = 142; pButton[23].Out = 5; pButton[23].In = 1; pButton[23].nx = 19; pButton[23].ny = 15;
	
			pButton[24].Ox = 78; pButton[24].Oy = 160; pButton[24].Out = 4; pButton[24].In = 8; pButton[24].nx = 19; pButton[24].ny = 15; // +/-
			pButton[25].Ox = 103; pButton[25].Oy = 160; pButton[25].Out = 4; pButton[25].In = 4; pButton[25].nx = 19; pButton[25].ny = 15; // EEX
			pButton[26].Ox = 28; pButton[26].Oy = 160; pButton[26].Out = 4; pButton[26].In = 16; pButton[26].nx = 44; pButton[26].ny = 15; // Enter
			pButton[27].Ox = 128; pButton[27].Oy = 160; pButton[27].Out = 4; pButton[27].In = 2; pButton[27].nx = 19; pButton[27].ny = 15; // Del
			pButton[28].Ox = 153; pButton[28].Oy = 160; pButton[28].Out = 4; pButton[28].In = 1; pButton[28].nx = 19; pButton[28].ny = 15; // Back

			pButton[29].Ox = 28; pButton[29].Oy = 178; pButton[29].Out = 3; pButton[29].In = 32; pButton[29].nx = 19; pButton[29].ny = 15;
			pButton[30].Ox = 28; pButton[30].Oy = 196; pButton[30].Out = 2; pButton[30].In = 32; pButton[30].nx = 19; pButton[30].ny = 15;
			pButton[31].Ox = 28; pButton[31].Oy = 214; pButton[31].Out = 1; pButton[31].In = 32; pButton[31].nx = 19; pButton[31].ny = 15;
			pButton[32].Ox = 28; pButton[32].Oy = 232; pButton[32].Out = 0; pButton[32].In = 32768; pButton[32].nx = 19; pButton[32].ny = 15;
	
			pButton[33].Ox = 58; pButton[33].Oy = 178; pButton[33].Out = 3; pButton[33].In = 8; pButton[33].nx = 24; pButton[33].ny = 15;
			pButton[34].Ox = 88; pButton[34].Oy = 178; pButton[34].Out = 3; pButton[34].In = 4; pButton[34].nx = 24; pButton[34].ny = 15;
			pButton[35].Ox = 118; pButton[35].Oy = 178; pButton[35].Out = 3; pButton[35].In = 2; pButton[35].nx = 24; pButton[35].ny = 15;
			pButton[36].Ox = 148; pButton[36].Oy = 178; pButton[36].Out = 3; pButton[36].In = 1; pButton[36].nx = 24; pButton[36].ny = 15;
	
			pButton[37].Ox = 58; pButton[37].Oy = 196; pButton[37].Out = 2; pButton[37].In = 8; pButton[37].nx = 24; pButton[37].ny = 15;
			pButton[38].Ox = 88; pButton[38].Oy = 196; pButton[38].Out = 2; pButton[38].In = 4; pButton[38].nx = 24; pButton[38].ny = 15;
			pButton[39].Ox = 118; pButton[39].Oy = 196; pButton[39].Out = 2; pButton[39].In = 2; pButton[39].nx = 24; pButton[39].ny = 15;
			pButton[40].Ox = 148; pButton[40].Oy = 196; pButton[40].Out = 2; pButton[40].In = 1; pButton[40].nx = 24; pButton[40].ny = 15;
	
			pButton[41].Ox = 58; pButton[41].Oy = 214; pButton[41].Out = 1; pButton[41].In = 8; pButton[41].nx = 24; pButton[41].ny = 15;
			pButton[42].Ox = 88; pButton[42].Oy = 214; pButton[42].Out = 1; pButton[42].In = 4; pButton[42].nx = 24; pButton[42].ny = 15;
			pButton[43].Ox = 118; pButton[43].Oy = 214; pButton[43].Out = 1; pButton[43].In = 2; pButton[43].nx = 24; pButton[43].ny = 15;
			pButton[44].Ox = 148; pButton[44].Oy = 214; pButton[44].Out = 1; pButton[44].In = 1; pButton[44].nx = 24; pButton[44].ny = 15;
	
			pButton[45].Ox = 58; pButton[45].Oy = 232; pButton[45].Out = 0; pButton[45].In = 8; pButton[45].nx = 24; pButton[45].ny = 15;
			pButton[46].Ox = 88; pButton[46].Oy = 232; pButton[46].Out = 0; pButton[46].In = 4; pButton[46].nx = 24; pButton[46].ny = 15;
			pButton[47].Ox = 118; pButton[47].Oy = 232; pButton[47].Out = 0; pButton[47].In = 2; pButton[47].nx = 24; pButton[47].ny = 15;
			pButton[48].Ox = 148; pButton[48].Oy = 232; pButton[48].Out = 0; pButton[48].In = 1; pButton[48].nx = 24; pButton[48].ny = 15;
#endif
		}
		if(zoom == 3)
		{
#ifdef __ER5__
			pButton[0].Ox = 20; pButton[0].Oy = 141; pButton[0].Out = 1; pButton[0].In = 16; pButton[0].nx = 36; pButton[0].ny = 25;
			pButton[1].Ox = 70; pButton[1].Oy = 141; pButton[1].Out = 8; pButton[1].In = 16; pButton[1].nx = 36; pButton[1].ny = 25;
			pButton[2].Ox = 120; pButton[2].Oy = 141; pButton[2].Out = 8; pButton[2].In = 8; pButton[2].nx = 36; pButton[2].ny = 25;
			pButton[3].Ox = 170; pButton[3].Oy = 141; pButton[3].Out = 8; pButton[3].In = 4; pButton[3].nx = 36; pButton[3].ny = 25;
			pButton[4].Ox = 220; pButton[4].Oy = 141; pButton[4].Out = 8; pButton[4].In = 2; pButton[4].nx = 36; pButton[4].ny = 25;
			pButton[5].Ox = 270; pButton[5].Oy = 141; pButton[5].Out = 8; pButton[5].In = 1; pButton[5].nx = 36; pButton[5].ny = 25;
	
			pButton[6].Ox = 20; pButton[6].Oy = 177; pButton[6].Out = 2; pButton[6].In = 16; pButton[6].nx = 36; pButton[6].ny = 25;
			pButton[7].Ox = 70; pButton[7].Oy = 177; pButton[7].Out = 7; pButton[7].In = 16; pButton[7].nx = 36; pButton[7].ny = 25;
			pButton[8].Ox = 120; pButton[8].Oy = 177; pButton[8].Out = 7; pButton[8].In = 8; pButton[8].nx = 36; pButton[8].ny = 25;
			pButton[9].Ox = 170; pButton[9].Oy = 177; pButton[9].Out = 7; pButton[9].In = 4; pButton[9].nx = 36; pButton[9].ny = 25;
			pButton[10].Ox = 220; pButton[10].Oy = 177; pButton[10].Out = 7; pButton[10].In = 2; pButton[10].nx = 36; pButton[10].ny = 25;
			pButton[11].Ox = 270; pButton[11].Oy = 177; pButton[11].Out = 7; pButton[11].In = 1; pButton[11].nx = 36; pButton[11].ny = 25;
	
			pButton[12].Ox = 20; pButton[12].Oy = 213; pButton[12].Out = 0; pButton[12].In = 16; pButton[12].nx = 36; pButton[12].ny = 25;
			pButton[13].Ox = 70; pButton[13].Oy = 213; pButton[13].Out = 6; pButton[13].In = 16; pButton[13].nx = 36; pButton[13].ny = 25;
			pButton[14].Ox = 120; pButton[14].Oy = 213; pButton[14].Out = 6; pButton[14].In = 8; pButton[14].nx = 36; pButton[14].ny = 25;
			pButton[15].Ox = 170; pButton[15].Oy = 213; pButton[15].Out = 6; pButton[15].In = 4; pButton[15].nx = 36; pButton[15].ny = 25;
			pButton[16].Ox = 220; pButton[16].Oy = 213; pButton[16].Out = 6; pButton[16].In = 2; pButton[16].nx = 36; pButton[16].ny = 25;
			pButton[17].Ox = 270; pButton[17].Oy = 213; pButton[17].Out = 6; pButton[17].In = 1; pButton[17].nx = 36; pButton[17].ny = 25;
	
			pButton[18].Ox = 321; pButton[18].Oy = 28; pButton[18].Out = 3; pButton[18].In = 16; pButton[18].nx = 36; pButton[18].ny = 25;
			pButton[19].Ox = 371; pButton[19].Oy = 28; pButton[19].Out = 5; pButton[19].In = 16; pButton[19].nx = 36; pButton[19].ny = 25;
			pButton[20].Ox = 421; pButton[20].Oy = 28; pButton[20].Out = 5; pButton[20].In = 8; pButton[20].nx = 36; pButton[20].ny = 25;
			pButton[21].Ox = 471; pButton[21].Oy = 28; pButton[21].Out = 5; pButton[21].In = 4; pButton[21].nx = 36; pButton[21].ny = 25;
			pButton[22].Ox = 521; pButton[22].Oy = 28; pButton[22].Out = 5; pButton[22].In = 2; pButton[22].nx = 36; pButton[22].ny = 25;
			pButton[23].Ox = 571; pButton[23].Oy = 28; pButton[23].Out = 5; pButton[23].In = 1; pButton[23].nx = 36; pButton[23].ny = 25;
	
			pButton[24].Ox = 421; pButton[24].Oy = 65; pButton[24].Out = 4; pButton[24].In = 8; pButton[24].nx = 36; pButton[24].ny = 25; // y
			pButton[25].Ox = 471; pButton[25].Oy = 65; pButton[25].Out = 4; pButton[25].In = 4; pButton[25].nx = 36; pButton[25].ny = 25; // z
			pButton[26].Ox = 321; pButton[26].Oy = 65; pButton[26].Out = 4; pButton[26].In = 16; pButton[26].nx = 86; pButton[26].ny = 25; //Enter
			pButton[27].Ox = 521; pButton[27].Oy = 65; pButton[27].Out = 4; pButton[27].In = 2; pButton[27].nx = 36; pButton[27].ny = 25; //del
			pButton[28].Ox = 571; pButton[28].Oy = 65; pButton[28].Out = 4; pButton[28].In = 1; pButton[28].nx = 36; pButton[28].ny = 25; //backspace
			pButton[29].Ox = 321; pButton[29].Oy = 102; pButton[29].Out = 3; pButton[29].In = 32; pButton[29].nx = 36; pButton[29].ny = 25; //alpha
			pButton[30].Ox = 321; pButton[30].Oy = 139; pButton[30].Out = 2; pButton[30].In = 32; pButton[30].nx = 36; pButton[30].ny = 25; //shift G.
			pButton[31].Ox = 321; pButton[31].Oy = 176; pButton[31].Out = 1; pButton[31].In = 32; pButton[31].nx = 36; pButton[31].ny = 25; //shift D.
			pButton[32].Ox = 321; pButton[32].Oy = 213; pButton[32].Out = 0; pButton[32].In = 32768; pButton[32].nx = 36; pButton[32].ny = 25; // on
	
			pButton[33].Ox = 380; pButton[33].Oy = 102; pButton[33].Out = 3; pButton[33].In = 8; pButton[33].nx = 47; pButton[33].ny = 25;
			pButton[34].Ox = 440; pButton[34].Oy = 102; pButton[34].Out = 3; pButton[34].In = 4; pButton[34].nx = 47; pButton[34].ny = 25;
			pButton[35].Ox = 500; pButton[35].Oy = 102; pButton[35].Out = 3; pButton[35].In = 2; pButton[35].nx = 47; pButton[35].ny = 25;
			pButton[36].Ox = 560; pButton[36].Oy = 102; pButton[36].Out = 3; pButton[36].In = 1; pButton[36].nx = 47; pButton[36].ny = 25;
	
			pButton[37].Ox = 380; pButton[37].Oy = 139; pButton[37].Out = 2; pButton[37].In = 8; pButton[37].nx = 47; pButton[37].ny = 25;
			pButton[38].Ox = 440; pButton[38].Oy = 139; pButton[38].Out = 2; pButton[38].In = 4; pButton[38].nx = 47; pButton[38].ny = 25;
			pButton[39].Ox = 500; pButton[39].Oy = 139; pButton[39].Out = 2; pButton[39].In = 2; pButton[39].nx = 47; pButton[39].ny = 25;
			pButton[40].Ox = 560; pButton[40].Oy = 139; pButton[40].Out = 2; pButton[40].In = 1; pButton[40].nx = 47; pButton[40].ny = 25;

			pButton[41].Ox = 380; pButton[41].Oy = 176; pButton[41].Out = 1; pButton[41].In = 8; pButton[41].nx = 47; pButton[41].ny = 25;
			pButton[42].Ox = 440; pButton[42].Oy = 176; pButton[42].Out = 1; pButton[42].In = 4; pButton[42].nx = 47; pButton[42].ny = 25;
			pButton[43].Ox = 500; pButton[43].Oy = 176; pButton[43].Out = 1; pButton[43].In = 2; pButton[43].nx = 47; pButton[43].ny = 25;
			pButton[44].Ox = 560; pButton[44].Oy = 176; pButton[44].Out = 1; pButton[44].In = 1; pButton[44].nx = 47; pButton[44].ny = 25;
	
			pButton[45].Ox = 380; pButton[45].Oy = 213; pButton[45].Out = 0; pButton[45].In = 8; pButton[45].nx = 47; pButton[45].ny = 25;
			pButton[46].Ox = 440; pButton[46].Oy = 213; pButton[46].Out = 0; pButton[46].In = 4; pButton[46].nx = 47; pButton[46].ny = 25;
			pButton[47].Ox = 500; pButton[47].Oy = 213; pButton[47].Out = 0; pButton[47].In = 2; pButton[47].nx = 47; pButton[47].ny = 25;
			pButton[48].Ox = 560; pButton[48].Oy = 213; pButton[48].Out = 0; pButton[48].In = 1; pButton[48].nx = 47; pButton[48].ny = 25;
#endif
#ifdef __ER6__
			pButton[0].Ox = 20; pButton[0].Oy = 146; pButton[0].Out = 1; pButton[0].In = 16; pButton[0].nx = 36; pButton[0].ny = 20;
			pButton[1].Ox = 70; pButton[1].Oy = 146; pButton[1].Out = 8; pButton[1].In = 16; pButton[1].nx = 36; pButton[1].ny = 20;
			pButton[2].Ox = 120; pButton[2].Oy = 146; pButton[2].Out = 8; pButton[2].In = 8; pButton[2].nx = 36; pButton[2].ny = 20;
			pButton[3].Ox = 170; pButton[3].Oy = 146; pButton[3].Out = 8; pButton[3].In = 4; pButton[3].nx = 36; pButton[3].ny = 20;
			pButton[4].Ox = 220; pButton[4].Oy = 146; pButton[4].Out = 8; pButton[4].In = 2; pButton[4].nx = 36; pButton[4].ny = 20;
			pButton[5].Ox = 270; pButton[5].Oy = 146; pButton[5].Out = 8; pButton[5].In = 1; pButton[5].nx = 36; pButton[5].ny = 20;
	
			pButton[6].Ox = 20; pButton[6].Oy = 180; pButton[6].Out = 2; pButton[6].In = 16; pButton[6].nx = 36; pButton[6].ny = 20;
			pButton[7].Ox = 70; pButton[7].Oy = 180; pButton[7].Out = 7; pButton[7].In = 16; pButton[7].nx = 36; pButton[7].ny = 20;
			pButton[8].Ox = 120; pButton[8].Oy = 180; pButton[8].Out = 7; pButton[8].In = 8; pButton[8].nx = 36; pButton[8].ny = 20;
			pButton[9].Ox = 170; pButton[9].Oy = 180; pButton[9].Out = 7; pButton[9].In = 4; pButton[9].nx = 36; pButton[9].ny = 20;
			pButton[10].Ox = 220; pButton[10].Oy = 180; pButton[10].Out = 7; pButton[10].In = 2; pButton[10].nx = 36; pButton[10].ny = 20;
			pButton[11].Ox = 270; pButton[11].Oy = 180; pButton[11].Out = 7; pButton[11].In = 1; pButton[11].nx = 36; pButton[11].ny = 20;
	
			pButton[12].Ox = 321; pButton[12].Oy = 9; pButton[12].Out = 0; pButton[12].In = 16; pButton[12].nx = 36; pButton[12].ny = 20;
			pButton[13].Ox = 371; pButton[13].Oy = 9; pButton[13].Out = 6; pButton[13].In = 16; pButton[13].nx = 36; pButton[13].ny = 20;
			pButton[14].Ox = 421; pButton[14].Oy = 9; pButton[14].Out = 6; pButton[14].In = 8; pButton[14].nx = 36; pButton[14].ny = 20;
			pButton[15].Ox = 471; pButton[15].Oy = 9; pButton[15].Out = 6; pButton[15].In = 4; pButton[15].nx = 36; pButton[15].ny = 20;
			pButton[16].Ox = 521; pButton[16].Oy = 9; pButton[16].Out = 6; pButton[16].In = 2; pButton[16].nx = 36; pButton[16].ny = 20;
			pButton[17].Ox = 571; pButton[17].Oy = 9; pButton[17].Out = 6; pButton[17].In = 1; pButton[17].nx = 36; pButton[17].ny = 20;

	
			pButton[18].Ox = 321; pButton[18].Oy = 37; pButton[18].Out = 3; pButton[18].In = 16; pButton[18].nx = 36; pButton[18].ny = 20;
			pButton[19].Ox = 371; pButton[19].Oy = 37; pButton[19].Out = 5; pButton[19].In = 16; pButton[19].nx = 36; pButton[19].ny = 20;
			pButton[20].Ox = 421; pButton[20].Oy = 37; pButton[20].Out = 5; pButton[20].In = 8; pButton[20].nx = 36; pButton[20].ny = 20;
			pButton[21].Ox = 471; pButton[21].Oy = 37; pButton[21].Out = 5; pButton[21].In = 4; pButton[21].nx = 36; pButton[21].ny = 20;
			pButton[22].Ox = 521; pButton[22].Oy = 37; pButton[22].Out = 5; pButton[22].In = 2; pButton[22].nx = 36; pButton[22].ny = 20;
			pButton[23].Ox = 571; pButton[23].Oy = 37; pButton[23].Out = 5; pButton[23].In = 1; pButton[23].nx = 36; pButton[23].ny = 20;
	
			pButton[24].Ox = 421; pButton[24].Oy = 65; pButton[24].Out = 4; pButton[24].In = 8; pButton[24].nx = 36; pButton[24].ny = 20; // y
			pButton[25].Ox = 471; pButton[25].Oy = 65; pButton[25].Out = 4; pButton[25].In = 4; pButton[25].nx = 36; pButton[25].ny = 20; // z
			pButton[26].Ox = 321; pButton[26].Oy = 65; pButton[26].Out = 4; pButton[26].In = 16; pButton[26].nx = 86; pButton[26].ny = 20; //Enter
			pButton[27].Ox = 521; pButton[27].Oy = 65; pButton[27].Out = 4; pButton[27].In = 2; pButton[27].nx = 36; pButton[27].ny = 20; //del
			pButton[28].Ox = 571; pButton[28].Oy = 65; pButton[28].Out = 4; pButton[28].In = 1; pButton[28].nx = 36; pButton[28].ny = 20; //backspace
			pButton[29].Ox = 321; pButton[29].Oy = 94; pButton[29].Out = 3; pButton[29].In = 32; pButton[29].nx = 36; pButton[29].ny = 20; //alpha
			pButton[30].Ox = 321; pButton[30].Oy = 123; pButton[30].Out = 2; pButton[30].In = 32; pButton[30].nx = 36; pButton[30].ny = 20; //shift G.
			pButton[31].Ox = 321; pButton[31].Oy = 152; pButton[31].Out = 1; pButton[31].In = 32; pButton[31].nx = 36; pButton[31].ny = 20; //shift D.
			pButton[32].Ox = 321; pButton[32].Oy = 180; pButton[32].Out = 0; pButton[32].In = 32768; pButton[32].nx = 36; pButton[32].ny = 20; // on
	
			pButton[33].Ox = 380; pButton[33].Oy = 94; pButton[33].Out = 3; pButton[33].In = 8; pButton[33].nx = 47; pButton[33].ny = 20;
			pButton[34].Ox = 440; pButton[34].Oy = 94; pButton[34].Out = 3; pButton[34].In = 4; pButton[34].nx = 47; pButton[34].ny = 20;
			pButton[35].Ox = 500; pButton[35].Oy = 94; pButton[35].Out = 3; pButton[35].In = 2; pButton[35].nx = 47; pButton[35].ny = 20;
			pButton[36].Ox = 560; pButton[36].Oy = 94; pButton[36].Out = 3; pButton[36].In = 1; pButton[36].nx = 47; pButton[36].ny = 20;
	
			pButton[37].Ox = 380; pButton[37].Oy = 123; pButton[37].Out = 2; pButton[37].In = 8; pButton[37].nx = 47; pButton[37].ny = 20;
			pButton[38].Ox = 440; pButton[38].Oy = 123; pButton[38].Out = 2; pButton[38].In = 4; pButton[38].nx = 47; pButton[38].ny = 20;
			pButton[39].Ox = 500; pButton[39].Oy = 123; pButton[39].Out = 2; pButton[39].In = 2; pButton[39].nx = 47; pButton[39].ny = 20;
			pButton[40].Ox = 560; pButton[40].Oy = 123; pButton[40].Out = 2; pButton[40].In = 1; pButton[40].nx = 47; pButton[40].ny = 20;

			pButton[41].Ox = 380; pButton[41].Oy = 152; pButton[41].Out = 1; pButton[41].In = 8; pButton[41].nx = 47; pButton[41].ny = 20;
			pButton[42].Ox = 440; pButton[42].Oy = 152; pButton[42].Out = 1; pButton[42].In = 4; pButton[42].nx = 47; pButton[42].ny = 20;
			pButton[43].Ox = 500; pButton[43].Oy = 152; pButton[43].Out = 1; pButton[43].In = 2; pButton[43].nx = 47; pButton[43].ny = 20;
			pButton[44].Ox = 560; pButton[44].Oy = 152; pButton[44].Out = 1; pButton[44].In = 1; pButton[44].nx = 47; pButton[44].ny = 20;
	
			pButton[45].Ox = 380; pButton[45].Oy = 180; pButton[45].Out = 0; pButton[45].In = 8; pButton[45].nx = 47; pButton[45].ny = 20;
			pButton[46].Ox = 440; pButton[46].Oy = 180; pButton[46].Out = 0; pButton[46].In = 4; pButton[46].nx = 47; pButton[46].ny = 20;
			pButton[47].Ox = 500; pButton[47].Oy = 180; pButton[47].Out = 0; pButton[47].In = 2; pButton[47].nx = 47; pButton[47].ny = 20;
			pButton[48].Ox = 560; pButton[48].Oy = 180; pButton[48].Out = 0; pButton[48].In = 1; pButton[48].nx = 47; pButton[48].ny = 20;
#endif
		}
	}
	if(ChipsetType==3) // 49G
	{
		if(zoom == 1) // 49G
		{
		}
		if(zoom == 2) // 49G
		{
			// F1, F2, F3, F4, F5
			pButton[0].Ox = 6; pButton[0].Oy = 123; pButton[0].Out = 5; pButton[0].In = 1; pButton[0].nx = 42; pButton[0].ny = 16; pButton[0].b3d = EFalse;
			pButton[1].Ox = 50; pButton[1].Oy = 123; pButton[1].Out = 5; pButton[1].In = 2; pButton[1].nx = 42; pButton[1].ny = 16; pButton[1].b3d = EFalse;
			pButton[2].Ox = 94; pButton[2].Oy = 123; pButton[2].Out = 5; pButton[2].In = 4; pButton[2].nx = 42; pButton[2].ny = 16; pButton[2].b3d = EFalse;
			pButton[3].Ox = 138; pButton[3].Oy = 123; pButton[3].Out = 5; pButton[3].In = 8; pButton[3].nx = 42; pButton[3].ny = 16; pButton[3].b3d = EFalse;
			pButton[4].Ox = 182; pButton[4].Oy = 123; pButton[4].Out = 5; pButton[4].In = 16; pButton[4].nx = 42; pButton[4].ny = 16; pButton[4].b3d = EFalse;
			pButton[5].Ox = 226; pButton[5].Oy = 123; pButton[5].Out = 5; pButton[5].In = 32; pButton[5].nx = 42; pButton[5].ny = 16; pButton[5].b3d = EFalse;


			// apps, mode, tool, var, sto, nxt
			pButton[6].Ox = 2; pButton[6].Oy = 140; pButton[6].Out = 5; pButton[6].In = 128; pButton[6].nx = 27; pButton[6].ny = 19;
			pButton[7].Ox = 29; pButton[7].Oy = 140; pButton[7].Out = 4; pButton[7].In = 128; pButton[7].nx = 27; pButton[7].ny = 19;
			pButton[8].Ox = 56; pButton[8].Oy = 140; pButton[8].Out = 3; pButton[8].In = 128; pButton[8].nx = 27; pButton[8].ny = 19;
			pButton[9].Ox = 83; pButton[9].Oy = 140; pButton[9].Out = 2; pButton[9].In = 128; pButton[9].nx = 27; pButton[9].ny = 19;
			pButton[10].Ox = 110; pButton[10].Oy = 140; pButton[10].Out = 1; pButton[10].In = 128; pButton[10].nx = 27; pButton[10].ny = 19;
			pButton[11].Ox = 137; pButton[11].Oy = 140; pButton[11].Out = 0; pButton[11].In = 128; pButton[11].nx = 27; pButton[11].ny = 19;

			// fleches G, H, B, D
			pButton[12].Ox = 164; pButton[12].Oy = 140; pButton[12].Out = 6; pButton[12].In = 4; pButton[12].nx = 27; pButton[12].ny = 19;
			pButton[13].Ox = 191; pButton[13].Oy = 140; pButton[13].Out = 6; pButton[13].In = 8; pButton[13].nx = 27; pButton[13].ny = 19;
			pButton[14].Ox = 218; pButton[14].Oy = 140; pButton[14].Out = 6; pButton[14].In = 2; pButton[14].nx = 27; pButton[14].ny = 19;
			pButton[15].Ox = 245; pButton[15].Oy = 140; pButton[15].Out = 6; pButton[15].In = 1; pButton[15].nx = 27; pButton[15].ny = 19;

			// hist, cat, eqw, symb, back
			pButton[16].Ox = 273; pButton[16].Oy = 5; pButton[16].Out = 4; pButton[16].In = 64; pButton[16].nx = 41; pButton[16].ny = 22;
			pButton[17].Ox = 314; pButton[17].Oy = 5; pButton[17].Out = 3; pButton[17].In = 64; pButton[17].nx = 41; pButton[17].ny = 22;
			pButton[18].Ox = 355; pButton[18].Oy = 5; pButton[18].Out = 2; pButton[18].In = 64; pButton[18].nx = 41; pButton[18].ny = 22;
			pButton[19].Ox = 396; pButton[19].Oy = 5; pButton[19].Out = 1; pButton[19].In = 64; pButton[19].nx = 41; pButton[19].ny = 22;
			pButton[20].Ox = 437; pButton[20].Oy = 5; pButton[20].Out = 0; pButton[20].In = 64; pButton[20].nx = 41; pButton[20].ny = 22;

			// y^x, sqr(x), sin, cos, tan
			pButton[21].Ox = 273; pButton[21].Oy = 27; pButton[21].Out = 4; pButton[21].In = 32; pButton[21].nx = 41; pButton[21].ny = 22;
			pButton[22].Ox = 314; pButton[22].Oy = 27; pButton[22].Out = 3; pButton[22].In = 32; pButton[22].nx = 41; pButton[22].ny = 22;
			pButton[23].Ox = 355; pButton[23].Oy = 27; pButton[23].Out = 2; pButton[23].In = 32; pButton[23].nx = 41; pButton[23].ny = 22;
			pButton[24].Ox = 396; pButton[24].Oy = 27; pButton[24].Out = 1; pButton[24].In = 32; pButton[24].nx = 41; pButton[24].ny = 22;
			pButton[25].Ox = 437; pButton[25].Oy = 27; pButton[25].Out = 0; pButton[25].In = 32; pButton[25].nx = 41; pButton[25].ny = 22;

			// eex, +/-, X, 1/X, div
			pButton[26].Ox = 273; pButton[26].Oy = 49; pButton[26].Out = 4; pButton[26].In = 16; pButton[26].nx = 41; pButton[26].ny = 22;
			pButton[27].Ox = 314; pButton[27].Oy = 49; pButton[27].Out = 3; pButton[27].In = 16; pButton[27].nx = 41; pButton[27].ny = 22;
			pButton[28].Ox = 355; pButton[28].Oy = 49; pButton[28].Out = 2; pButton[28].In = 16; pButton[28].nx = 41; pButton[28].ny = 22;
			pButton[29].Ox = 396; pButton[29].Oy = 49; pButton[29].Out = 1; pButton[29].In = 16; pButton[29].nx = 41; pButton[29].ny = 22;
			pButton[30].Ox = 437; pButton[30].Oy = 49; pButton[30].Out = 0; pButton[30].In = 16; pButton[30].nx = 41; pButton[30].ny = 22;

			// alpha, 7, 8, 9, *
			pButton[31].Ox = 273; pButton[31].Oy = 71; pButton[31].Out = 7; pButton[31].In = 8; pButton[31].nx = 41; pButton[31].ny = 22;
			pButton[32].Ox = 314; pButton[32].Oy = 71; pButton[32].Out = 3; pButton[32].In = 8; pButton[32].nx = 41; pButton[32].ny = 22;
			pButton[33].Ox = 355; pButton[33].Oy = 71; pButton[33].Out = 2; pButton[33].In = 8; pButton[33].nx = 41; pButton[33].ny = 22;
			pButton[34].Ox = 396; pButton[34].Oy = 71; pButton[34].Out = 1; pButton[34].In = 8; pButton[34].nx = 41; pButton[34].ny = 22;
			pButton[35].Ox = 437; pButton[35].Oy = 71; pButton[35].Out = 0; pButton[35].In = 8; pButton[35].nx = 41; pButton[35].ny = 22;

			// shG, 4, 5, 6, -

			pButton[36].Ox = 273; pButton[36].Oy = 93; pButton[36].Out = 7; pButton[36].In = 4; pButton[36].nx = 41; pButton[36].ny = 22;
			pButton[37].Ox = 314; pButton[37].Oy = 93; pButton[37].Out = 3; pButton[37].In = 4; pButton[37].nx = 41; pButton[37].ny = 22;
			pButton[38].Ox = 355; pButton[38].Oy = 93; pButton[38].Out = 2; pButton[38].In = 4; pButton[38].nx = 41; pButton[38].ny = 22;
			pButton[39].Ox = 396; pButton[39].Oy = 93; pButton[39].Out = 1; pButton[39].In = 4; pButton[39].nx = 41; pButton[39].ny = 22;
			pButton[40].Ox = 437; pButton[40].Oy = 93; pButton[40].Out = 0; pButton[40].In = 4; pButton[40].nx = 41; pButton[40].ny = 22;
	
			// shD, 1, 2, 3, +
			pButton[41].Ox = 273; pButton[41].Oy = 115; pButton[41].Out = 7; pButton[41].In = 2; pButton[41].nx = 41; pButton[41].ny = 22;
			pButton[42].Ox = 314; pButton[42].Oy = 115; pButton[42].Out = 3; pButton[42].In = 2; pButton[42].nx = 41; pButton[42].ny = 22;
			pButton[43].Ox = 355; pButton[43].Oy = 115; pButton[43].Out = 2; pButton[43].In = 2; pButton[43].nx = 41; pButton[43].ny = 22;
			pButton[44].Ox = 396; pButton[44].Oy = 115; pButton[44].Out = 1; pButton[44].In = 2; pButton[44].nx = 41; pButton[44].ny = 22;
			pButton[45].Ox = 437; pButton[45].Oy = 115; pButton[45].Out = 0; pButton[45].In = 2; pButton[45].nx = 41; pButton[45].ny = 22;

			// on, 0, ., spc, enter
			pButton[46].Ox = 273; pButton[46].Oy = 137; pButton[46].Out = 0; pButton[46].In = 32768; pButton[46].nx = 41; pButton[46].ny = 22;
			pButton[47].Ox = 314; pButton[47].Oy = 137; pButton[47].Out = 3; pButton[47].In = 1; pButton[47].nx = 41; pButton[47].ny = 22;
			pButton[48].Ox = 355; pButton[48].Oy = 137; pButton[48].Out = 2; pButton[48].In = 1; pButton[48].nx = 41; pButton[48].ny = 22;
			pButton[49].Ox = 396; pButton[49].Oy = 137; pButton[49].Out = 1; pButton[49].In = 1; pButton[49].nx = 41; pButton[49].ny = 22;
			pButton[50].Ox = 437; pButton[50].Oy = 137; pButton[50].Out = 0; pButton[50].In = 1; pButton[50].nx = 41; pButton[50].ny = 22;
		}
		if(zoom == 3) // 49G
		{
#ifdef __ER5__
			// F1, F2, F3, F4, F5
			pButton[0].Ox = 22; pButton[0].Oy = 148; pButton[0].Out = 5; pButton[0].In = 1; pButton[0].nx = 36; pButton[0].ny = 22;
			pButton[1].Ox = 71; pButton[1].Oy = 148; pButton[1].Out = 5; pButton[1].In = 2; pButton[1].nx = 36; pButton[1].ny = 22;
			pButton[2].Ox = 120; pButton[2].Oy = 148; pButton[2].Out = 5; pButton[2].In = 4; pButton[2].nx = 36; pButton[2].ny = 22;
			pButton[3].Ox = 169; pButton[3].Oy = 148; pButton[3].Out = 5; pButton[3].In = 8; pButton[3].nx = 36; pButton[3].ny = 22;
			pButton[4].Ox = 218; pButton[4].Oy = 148; pButton[4].Out = 5; pButton[4].In = 16; pButton[4].nx = 36; pButton[4].ny = 22;
			pButton[5].Ox = 267; pButton[5].Oy = 148; pButton[5].Out = 5; pButton[5].In = 32; pButton[5].nx = 36; pButton[5].ny = 22;

			// apps, mode, tool, var, sto, nxt
			pButton[6].Ox = 20; pButton[6].Oy = 182; pButton[6].Out = 5; pButton[6].In = 128; pButton[6].nx = 41; pButton[6].ny = 22;
			pButton[7].Ox = 81; pButton[7].Oy = 182; pButton[7].Out = 4; pButton[7].In = 128; pButton[7].nx = 41; pButton[7].ny = 22;
			pButton[8].Ox = 142; pButton[8].Oy = 182; pButton[8].Out = 3; pButton[8].In = 128; pButton[8].nx = 41; pButton[8].ny = 22;
			pButton[9].Ox = 20; pButton[9].Oy = 216; pButton[9].Out = 2; pButton[9].In = 128; pButton[9].nx = 41; pButton[9].ny = 22;
			pButton[10].Ox = 81; pButton[10].Oy = 216; pButton[10].Out = 1; pButton[10].In = 128; pButton[10].nx = 41; pButton[10].ny = 22;
			pButton[11].Ox = 142; pButton[11].Oy = 216; pButton[11].Out = 0; pButton[11].In = 128; pButton[11].nx = 41; pButton[11].ny = 22;

			// fleches G, H, B, D
			pButton[12].Ox = 203; pButton[12].Oy = 216; pButton[12].Out = 6; pButton[12].In = 4; pButton[12].nx = 41; pButton[12].ny = 22;
			pButton[13].Ox = 203; pButton[13].Oy = 182; pButton[13].Out = 6; pButton[13].In = 8; pButton[13].nx = 41; pButton[13].ny = 22;
			pButton[14].Ox = 264; pButton[14].Oy = 182; pButton[14].Out = 6; pButton[14].In = 2; pButton[14].nx = 41; pButton[14].ny = 22;

			pButton[15].Ox = 264; pButton[15].Oy = 216; pButton[15].Out = 6; pButton[15].In = 1; pButton[15].nx = 41; pButton[15].ny = 22;

			// hist, cat, eqw, symb, back
			pButton[16].Ox = 325; pButton[16].Oy = 12; pButton[16].Out = 4; pButton[16].In = 64; pButton[16].nx = 41; pButton[16].ny = 22;
			pButton[17].Ox = 386; pButton[17].Oy = 12; pButton[17].Out = 3; pButton[17].In = 64; pButton[17].nx = 41; pButton[17].ny = 22;
			pButton[18].Ox = 447; pButton[18].Oy = 12; pButton[18].Out = 2; pButton[18].In = 64; pButton[18].nx = 41; pButton[18].ny = 22;
			pButton[19].Ox = 508; pButton[19].Oy = 12; pButton[19].Out = 1; pButton[19].In = 64; pButton[19].nx = 41; pButton[19].ny = 22;
			pButton[20].Ox = 569; pButton[20].Oy = 12; pButton[20].Out = 0; pButton[20].In = 64; pButton[20].nx = 41; pButton[20].ny = 22;

			// y^x, sqr(x), sin, cos, tan
			pButton[21].Ox = 325; pButton[21].Oy = 46; pButton[21].Out = 4; pButton[21].In = 32; pButton[21].nx = 41; pButton[21].ny = 22;
			pButton[22].Ox = 386; pButton[22].Oy = 46; pButton[22].Out = 3; pButton[22].In = 32; pButton[22].nx = 41; pButton[22].ny = 22;
			pButton[23].Ox = 447; pButton[23].Oy = 46; pButton[23].Out = 2; pButton[23].In = 32; pButton[23].nx = 41; pButton[23].ny = 22;
			pButton[24].Ox = 508; pButton[24].Oy = 46; pButton[24].Out = 1; pButton[24].In = 32; pButton[24].nx = 41; pButton[24].ny = 22;
			pButton[25].Ox = 569; pButton[25].Oy = 46; pButton[25].Out = 0; pButton[25].In = 32; pButton[25].nx = 41; pButton[25].ny = 22;

			// eex, +/-, X, 1/X, div
			pButton[26].Ox = 325; pButton[26].Oy = 80; pButton[26].Out = 4; pButton[26].In = 16; pButton[26].nx = 41; pButton[26].ny = 22;
			pButton[27].Ox = 386; pButton[27].Oy = 80; pButton[27].Out = 3; pButton[27].In = 16; pButton[27].nx = 41; pButton[27].ny = 22;
			pButton[28].Ox = 447; pButton[28].Oy = 80; pButton[28].Out = 2; pButton[28].In = 16; pButton[28].nx = 41; pButton[28].ny = 22;
			pButton[29].Ox = 508; pButton[29].Oy = 80; pButton[29].Out = 1; pButton[29].In = 16; pButton[29].nx = 41; pButton[29].ny = 22;
			pButton[30].Ox = 569; pButton[30].Oy = 80; pButton[30].Out = 0; pButton[30].In = 16; pButton[30].nx = 41; pButton[30].ny = 22;

			// alpha, 7, 8, 9, *
			pButton[31].Ox = 325; pButton[31].Oy = 114; pButton[31].Out = 7; pButton[31].In = 8; pButton[31].nx = 41; pButton[31].ny = 22;
			pButton[32].Ox = 386; pButton[32].Oy = 114; pButton[32].Out = 3; pButton[32].In = 8; pButton[32].nx = 41; pButton[32].ny = 22;
			pButton[33].Ox = 447; pButton[33].Oy = 114; pButton[33].Out = 2; pButton[33].In = 8; pButton[33].nx = 41; pButton[33].ny = 22;
			pButton[34].Ox = 508; pButton[34].Oy = 114; pButton[34].Out = 1; pButton[34].In = 8; pButton[34].nx = 41; pButton[34].ny = 22;
			pButton[35].Ox = 569; pButton[35].Oy = 114; pButton[35].Out = 0; pButton[35].In = 8; pButton[35].nx = 41; pButton[35].ny = 22;

			// shG, 4, 5, 6, -
			pButton[36].Ox = 325; pButton[36].Oy = 148; pButton[36].Out = 7; pButton[36].In = 4; pButton[36].nx = 41; pButton[36].ny = 22;
			pButton[37].Ox = 386; pButton[37].Oy = 148; pButton[37].Out = 3; pButton[37].In = 4; pButton[37].nx = 41; pButton[37].ny = 22;
			pButton[38].Ox = 447; pButton[38].Oy = 148; pButton[38].Out = 2; pButton[38].In = 4; pButton[38].nx = 41; pButton[38].ny = 22;
			pButton[39].Ox = 508; pButton[39].Oy = 148; pButton[39].Out = 1; pButton[39].In = 4; pButton[39].nx = 41; pButton[39].ny = 22;
			pButton[40].Ox = 569; pButton[40].Oy = 148; pButton[40].Out = 0; pButton[40].In = 4; pButton[40].nx = 41; pButton[40].ny = 22;
	
			// shD, 1, 2, 3, +
			pButton[41].Ox = 325; pButton[41].Oy = 182; pButton[41].Out = 7; pButton[41].In = 2; pButton[41].nx = 41; pButton[41].ny = 22;
			pButton[42].Ox = 386; pButton[42].Oy = 182; pButton[42].Out = 3; pButton[42].In = 2; pButton[42].nx = 41; pButton[42].ny = 22;
			pButton[43].Ox = 447; pButton[43].Oy = 182; pButton[43].Out = 2; pButton[43].In = 2; pButton[43].nx = 41; pButton[43].ny = 22;
			pButton[44].Ox = 508; pButton[44].Oy = 182; pButton[44].Out = 1; pButton[44].In = 2; pButton[44].nx = 41; pButton[44].ny = 22;
			pButton[45].Ox = 569; pButton[45].Oy = 182; pButton[45].Out = 0; pButton[45].In = 2; pButton[45].nx = 41; pButton[45].ny = 22;

			// on, 0, ., spc, enter
			pButton[46].Ox = 325; pButton[46].Oy = 216; pButton[46].Out = 0; pButton[46].In = 32768; pButton[46].nx = 41; pButton[46].ny = 22;
			pButton[47].Ox = 386; pButton[47].Oy = 216; pButton[47].Out = 3; pButton[47].In = 1; pButton[47].nx = 41; pButton[47].ny = 22;
			pButton[48].Ox = 447; pButton[48].Oy = 216; pButton[48].Out = 2; pButton[48].In = 1; pButton[48].nx = 41; pButton[48].ny = 22;
			pButton[49].Ox = 508; pButton[49].Oy = 216; pButton[49].Out = 1; pButton[49].In = 1; pButton[49].nx = 41; pButton[49].ny = 22;
			pButton[50].Ox = 569; pButton[50].Oy = 216; pButton[50].Out = 0; pButton[50].In = 1; pButton[50].nx = 41; pButton[50].ny = 22;
#endif
#ifdef __ER6__
			// F1, F2, F3, F4, F5, F6
			pButton[0].Ox = 15; pButton[0].Oy = 10; pButton[0].Out = 5; pButton[0].In = 1; pButton[0].nx = 20; pButton[0].ny = 20;
			pButton[1].Ox = 15; pButton[1].Oy = 32; pButton[1].Out = 5; pButton[1].In = 2; pButton[1].nx = 20; pButton[1].ny = 20;
			pButton[2].Ox = 15; pButton[2].Oy = 54; pButton[2].Out = 5; pButton[2].In = 4; pButton[2].nx = 20; pButton[2].ny = 20;
			pButton[3].Ox = 15; pButton[3].Oy = 76; pButton[3].Out = 5; pButton[3].In = 8; pButton[3].nx = 20; pButton[3].ny = 20;
			pButton[4].Ox = 15; pButton[4].Oy = 98; pButton[4].Out = 5; pButton[4].In = 16; pButton[4].nx = 20; pButton[4].ny = 20;
			pButton[5].Ox = 15; pButton[5].Oy = 120; pButton[5].Out = 5; pButton[5].In = 32; pButton[5].nx = 20; pButton[5].ny = 20;

			// apps, mode, tool, var, sto, nxt
			pButton[6].Ox = 60; pButton[6].Oy = 150; pButton[6].Out = 5; pButton[6].In = 128; pButton[6].nx = 36; pButton[6].ny = 20;
			pButton[7].Ox = 110; pButton[7].Oy = 150; pButton[7].Out = 4; pButton[7].In = 128; pButton[7].nx = 36; pButton[7].ny = 20;
			pButton[8].Ox = 160; pButton[8].Oy = 150; pButton[8].Out = 3; pButton[8].In = 128; pButton[8].nx = 36; pButton[8].ny = 20;
			pButton[9].Ox = 60; pButton[9].Oy = 180; pButton[9].Out = 2; pButton[9].In = 128; pButton[9].nx = 36; pButton[9].ny = 20;
			pButton[10].Ox = 110; pButton[10].Oy = 180; pButton[10].Out = 1; pButton[10].In = 128; pButton[10].nx = 36; pButton[10].ny = 20;
			pButton[11].Ox = 160; pButton[11].Oy = 180; pButton[11].Out = 0; pButton[11].In = 128; pButton[11].nx = 36; pButton[11].ny = 20;

			// fleches G, H, B, D
			pButton[12].Ox = 210; pButton[12].Oy = 180; pButton[12].Out = 6; pButton[12].In = 4; pButton[12].nx = 36; pButton[12].ny = 20;
			pButton[13].Ox = 210; pButton[13].Oy = 150; pButton[13].Out = 6; pButton[13].In = 8; pButton[13].nx = 36; pButton[13].ny = 20;
			pButton[14].Ox = 260; pButton[14].Oy = 150; pButton[14].Out = 6; pButton[14].In = 2; pButton[14].nx = 36; pButton[14].ny = 20;
			pButton[15].Ox = 260; pButton[15].Oy = 180; pButton[15].Out = 6; pButton[15].In = 1; pButton[15].nx = 36; pButton[15].ny = 20;

			// hist, cat, eqw, symb, back
			pButton[16].Ox = 371; pButton[16].Oy = 9; pButton[16].Out = 4; pButton[16].In = 64; pButton[16].nx = 36; pButton[16].ny = 20;
			pButton[17].Ox = 421; pButton[17].Oy = 9; pButton[17].Out = 3; pButton[17].In = 64; pButton[17].nx = 36; pButton[17].ny = 20;
			pButton[18].Ox = 471; pButton[18].Oy = 9; pButton[18].Out = 2; pButton[18].In = 64; pButton[18].nx = 36; pButton[18].ny = 20;
			pButton[19].Ox = 521; pButton[19].Oy = 9; pButton[19].Out = 1; pButton[19].In = 64; pButton[19].nx = 36; pButton[19].ny = 20;
			pButton[20].Ox = 571; pButton[20].Oy = 9; pButton[20].Out = 0; pButton[20].In = 64; pButton[20].nx = 36; pButton[20].ny = 20;

			// y^x, sqr(x), sin, cos, tan
			pButton[21].Ox = 371; pButton[21].Oy = 37; pButton[21].Out = 4; pButton[21].In = 32; pButton[21].nx = 36; pButton[21].ny = 20;
			pButton[22].Ox = 421; pButton[22].Oy = 37; pButton[22].Out = 3; pButton[22].In = 32; pButton[22].nx = 36; pButton[22].ny = 20;
			pButton[23].Ox = 471; pButton[23].Oy = 37; pButton[23].Out = 2; pButton[23].In = 32; pButton[23].nx = 36; pButton[23].ny = 20;
			pButton[24].Ox = 521; pButton[24].Oy = 37; pButton[24].Out = 1; pButton[24].In = 32; pButton[24].nx = 36; pButton[24].ny = 20;
			pButton[25].Ox = 571; pButton[25].Oy = 37; pButton[25].Out = 0; pButton[25].In = 32; pButton[25].nx = 36; pButton[25].ny = 20;

			// eex, +/-, X, 1/X, div
			pButton[26].Ox = 371; pButton[26].Oy = 65; pButton[26].Out = 4; pButton[26].In = 16; pButton[26].nx = 36; pButton[26].ny = 20;
			pButton[27].Ox = 421; pButton[27].Oy = 65; pButton[27].Out = 3; pButton[27].In = 16; pButton[27].nx = 36; pButton[27].ny = 20;
			pButton[28].Ox = 471; pButton[28].Oy = 65; pButton[28].Out = 2; pButton[28].In = 16; pButton[28].nx = 36; pButton[28].ny = 20;
			pButton[29].Ox = 521; pButton[29].Oy = 65; pButton[29].Out = 1; pButton[29].In = 16; pButton[29].nx = 36; pButton[29].ny = 20;
			pButton[30].Ox = 571; pButton[30].Oy = 65; pButton[30].Out = 0; pButton[30].In = 16; pButton[30].nx = 36; pButton[30].ny = 20;

			// alpha, 7, 8, 9, *
			pButton[31].Ox = 321; pButton[31].Oy = 94; pButton[31].Out = 7; pButton[31].In = 8; pButton[31].nx = 36; pButton[31].ny = 20;
			pButton[32].Ox = 380; pButton[32].Oy = 94; pButton[32].Out = 3; pButton[32].In = 8; pButton[32].nx = 47; pButton[32].ny = 20;
			pButton[33].Ox = 440; pButton[33].Oy = 94; pButton[33].Out = 2; pButton[33].In = 8; pButton[33].nx = 47; pButton[33].ny = 20;
			pButton[34].Ox = 500; pButton[34].Oy = 94; pButton[34].Out = 1; pButton[34].In = 8; pButton[34].nx = 47; pButton[34].ny = 20;
			pButton[35].Ox = 560; pButton[35].Oy = 94; pButton[35].Out = 0; pButton[35].In = 8; pButton[35].nx = 47; pButton[35].ny = 20;

			// shG, 4, 5, 6, -
			pButton[36].Ox = 321; pButton[36].Oy = 123; pButton[36].Out = 7; pButton[36].In = 4; pButton[36].nx = 36; pButton[36].ny = 20;
			pButton[37].Ox = 380; pButton[37].Oy = 123; pButton[37].Out = 3; pButton[37].In = 4; pButton[37].nx = 47; pButton[37].ny = 20;
			pButton[38].Ox = 440; pButton[38].Oy = 123; pButton[38].Out = 2; pButton[38].In = 4; pButton[38].nx = 47; pButton[38].ny = 20;
			pButton[39].Ox = 500; pButton[39].Oy = 123; pButton[39].Out = 1; pButton[39].In = 4; pButton[39].nx = 47; pButton[39].ny = 20;
			pButton[40].Ox = 560; pButton[40].Oy = 123; pButton[40].Out = 0; pButton[40].In = 4; pButton[40].nx = 47; pButton[40].ny = 20;
	
			// shD, 1, 2, 3, +
			pButton[41].Ox = 321; pButton[41].Oy = 152; pButton[41].Out = 7; pButton[41].In = 2; pButton[41].nx = 36; pButton[41].ny = 20;
			pButton[42].Ox = 380; pButton[42].Oy = 152; pButton[42].Out = 3; pButton[42].In = 2; pButton[42].nx = 47; pButton[42].ny = 20;
			pButton[43].Ox = 440; pButton[43].Oy = 152; pButton[43].Out = 2; pButton[43].In = 2; pButton[43].nx = 47; pButton[43].ny = 20;
			pButton[44].Ox = 500; pButton[44].Oy = 152; pButton[44].Out = 1; pButton[44].In = 2; pButton[44].nx = 47; pButton[44].ny = 20;
			pButton[45].Ox = 560; pButton[45].Oy = 152; pButton[45].Out = 0; pButton[45].In = 2; pButton[45].nx = 47; pButton[45].ny = 20;

			// on, 0, ., spc, enter
			pButton[46].Ox = 321; pButton[46].Oy = 180; pButton[46].Out = 0; pButton[46].In = 32768; pButton[46].nx = 36; pButton[46].ny = 20;
			pButton[47].Ox = 380; pButton[47].Oy = 180; pButton[47].Out = 3; pButton[47].In = 1; pButton[47].nx = 47; pButton[47].ny = 20;
			pButton[48].Ox = 440; pButton[48].Oy = 180; pButton[48].Out = 2; pButton[48].In = 1; pButton[48].nx = 47; pButton[48].ny = 20;
			pButton[49].Ox = 500; pButton[49].Oy = 180; pButton[49].Out = 1; pButton[49].In = 1; pButton[49].nx = 47; pButton[49].ny = 20;
			pButton[50].Ox = 560; pButton[50].Oy = 180; pButton[50].Out = 0; pButton[50].In = 1; pButton[50].nx = 47; pButton[50].ny = 20;
#endif
		}
	}
	return;
}

