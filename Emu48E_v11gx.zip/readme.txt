Emu48E v1.1 : A freeware HP48 emulator for Epoc32. (30/03/2003)
---------------------------------------------------------------
Author : Raphael MASSOT, based on the Emu48 sources of Sebastien CARLIER


1) About Emu48E.
----------------
Emu48E is a port of Emu48 on EPOC32, it works on Psion Revo, series 5 and Osaris (and perhaps other ones). It's an Eikon application programmed in c++.


2) Installation.
----------------
Installation is done by the .sis file (language : french or english).
Removing the program don't delete .bak files, you don't have to use the .bak of a Sx with a Gx Rom and vice versa (I haven't test it but I think it can cause strange behaviours).

The program is installed on drive C or D into \system\Apps\Emu48E\ :
With an installation on drive D, you can move the files app, aif and rsc on the drive C (into \system\Apps\Emu48E\) for a faster execution.

  - Emu48E.app : the application
  - Emu48E.aif : application aif file
  - Emu48E.rsc : application resources
  - annunc.mbm : annunciators bitmap
  - mainGx or mainSx : calculator bitmap
  - gx.rom or sx.rom : ROM file supplied by HP.

and after the first use : 
  - chipset.bak : Saturn processor backup (480 bytes)
  - ramP0.bak : RAM port 0 backup (32KB for a Sx, 128KB for a Gx)
  - ramP1.bak : RAM port 1 backup (1 byte if empty, 128KB if used)

Note : This 3 files .bak can be backed-up and restored in case of big crash.

3) Using the emulator.
----------------------
If there is a gx.rom in the default directory it's loaded otherwise it try to load the sx.rom file.
It's the same thing for mainGx and mainSx.

Sx version
  - use 375KB on the disk and 128KB additional if the RAM of port P1 is used.
  - need 1 MB of memory to work.
Gx version
  - use 727KB on the disk and 128KB additional if the RAM of port P1 is used.
  - need 1.7 MB of memory to work.
 
At startup, the backup files (*.bak) are loaded if the emulator find them, otherwise the RAM is zeroed.
When the programm is closed, the backup files are saved automatically.

 File menu :
 -----------
  - New : delete all backups and zero the RAM.
  - Reset : calculator reset (the RAM isn't zeroed)
  - Exit : close the emulator and backup RAM and chipset on disk.

 View Menu :
 -----------
  - Settings : display updating mode
      * at shutdown : display is updated only when the HP48 processeur goes to shutdown. It's the faster mode.
      * real : display is updated every time the display memory is writed. The update is doing slowly.
  - View select :
      * small : simple Lcd bitmap, for the Revo
      * medium : Lcd bitmap doubled, large keys, no label above the keys, for Revo and large screen.
      * large : Lcd bitmap doubled, large keys, labels above the keys, for large screen.


4) Versions / Limitations / future evolutions
---------------------------------------------

 * v1.1:
 -------
There is now 3 views whith differents sizes for the Revo and lage screen.
Bugfix when the program is installed on drive D.
Bugfix of the dark screen when the calculator is turned off.
Bugfix of the E32User-CBase 42 error at startup after the program was closed with a blinking cursor.

 * v1.0:
 -------
It's the first release, then it's minimal comparing to Emu48.
The emulation speed is lower than the speed of a real HP 48.
The copy from/to the stack from/to the clipboard is not yet implemented.


5) Bugs
-------
The time is not displayed correctly, it's updating when it wants.
A too short pen click on a key can cause the key not to be detected.


--
Raphael MASSOT
Besancon, France
Mail : massot@m6net.fr
