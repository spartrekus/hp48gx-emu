/*
 *   Emu48.c
 *
 *   This file is part of Emu48
 *
 *   Copyright (C) 2004 Christoph Gie�elink
 *
 */
#include "pch.h"
#include "resource.h"
#include "Emu48.h"
#include "io.h"
#include "kml.h"

#define VERSION   "1.25"

#define MAXPORTS  9							// number of COM ports

#ifdef _DEBUG
LPCTSTR szNoTitle = _T("Emu48 ")_T(VERSION)_T(" Debug");
#else
LPCTSTR szNoTitle = _T("Emu48 ")_T(VERSION);
#endif
LPTSTR szTitle = NULL;

static const LPCTSTR szLicence =
	_T("This program is free software; you can redistribute it and/or modify ")
	_T("it under the terms of the GNU General Public License as published by ")
	_T("the Free Software Foundation; either version 2 of the License, or ")
	_T("(at your option) any later version.\r\n")
	_T("\r\n")
	_T("This program is distributed in the hope that it will be useful, ")
	_T("but WITHOUT ANY WARRANTY; without even the implied warranty of ")
	_T("MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. ")
	_T("See the GNU General Public License for more details.\r\n")
	_T("\r\n")
	_T("You should have received a copy of the GNU General Public License ")
	_T("along with this program; if not, write to the Free Software Foundation, ")
	_T("Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA");

CRITICAL_SECTION csGDILock;					// critical section for hWindowDC
CRITICAL_SECTION csKeyLock;					// critical section for key scan
CRITICAL_SECTION csIOLock;					// critical section for I/O access
CRITICAL_SECTION csT1Lock;					// critical section for timer1 access
CRITICAL_SECTION csT2Lock;					// critical section for timer2 access
CRITICAL_SECTION csTxdLock;					// critical section for transmit byte
CRITICAL_SECTION csRecvLock;				// critical section for receive byte
CRITICAL_SECTION csSlowLock;				// critical section for speed slow down

INT              nArgc;						// no. of command line arguments
LPCTSTR          *ppArgv;					// command line arguments
LARGE_INTEGER    lFreq;						// high performance counter frequency
LARGE_INTEGER    lAppStart;					// high performance counter value at Appl. start
LONG             lrcTop;
HANDLE           hThread;
HANDLE           hEventShutdn;				// event handle to stop cpu thread

HINSTANCE        hApp = NULL;
HWND             hWnd = NULL;
HWND             hCmdBar = NULL;			// normal menu
HMENU            hCmdPopup = NULL;			// popup menu
HDC              hWindowDC = NULL;
HPALETTE         hPalette = NULL;
HPALETTE         hOldPalette = NULL;		// old palette of hWindowDC
UINT             nAppZoom = 1;				// application zoom factor
UINT             uWaveDevId = WAVE_MAPPER;	// default audio device
DWORD            dwWakeupDelay = 200;		// ON key hold time to switch on calculator
BOOL             bAutoSave = FALSE;
BOOL             bAutoSaveOnExit = TRUE;
BOOL             bSaveDefConfirm = TRUE;	// yes
BOOL             bStartupBackup = FALSE;
BOOL             bAlwaysDisplayLog = TRUE;
BOOL             bLoadObjectWarning = TRUE;


//################
//#
//#    Window Status
//#
//################

VOID SetWindowTitle(LPCTSTR szString)
{
	if (szTitle) free(szTitle);

	_ASSERT(hWnd != NULL);
	if (szString)
	{
		LPCTSTR szName;

		// remove path from title
		if ((szName = _tcsrchr(szString,_T('\\'))) != NULL)
		{
			szString = szName + 1;			// cut path before
		}

		szTitle = DuplicateString(szString);
		SetWindowText(hWnd, szTitle);
	}
	else
	{
		szTitle = NULL;
		SetWindowText(hWnd, szNoTitle);
	}
	return;
}

BOOL StackCopyPasteEnabled(VOID)
{
	// Copy/Paste Stack supported by calculator model
	// disable stack loading items on HP38G, HP39/40G
	return    cCurrentRomType != '6'
		   && cCurrentRomType != 'A'
		   && cCurrentRomType != 'E';
}



//################
//#
//#    Settings
//#
//################

// get R/W state of file
static BOOL IsFileWriteable(LPCTSTR szFilename)
{
	DWORD dwFileAtt;

	BOOL bWriteable = FALSE;

	dwFileAtt = GetFileAttributes(FullFilename(szFilename));
	if (dwFileAtt != 0xFFFFFFFF)
		bWriteable = ((dwFileAtt & FILE_ATTRIBUTE_READONLY) == 0);
	return bWriteable;
}

// set listfield for serial combo boxes
static VOID SetCommList(HWND hDlg,LPCTSTR szWireSetting,LPCTSTR szIrSetting)
{
	HANDLE hComm;
	TCHAR  szBuffer[16];
	WPARAM wSelectWire,wSelectIr,wSelIndexWire,wSelIndexIr;
	BOOL   bAddWire,bAddIr;
	WORD   wCount;

	wSelectWire   = wSelectIr   = 0;		// set selections to disabled
	wSelIndexWire = wSelIndexIr = 1;		// preset selector

	SendDlgItemMessage(hDlg,IDC_WIRE,CB_ADDSTRING,0,(LPARAM) _T(NO_SERIAL));
	SendDlgItemMessage(hDlg,IDC_IR  ,CB_ADDSTRING,0,(LPARAM) _T(NO_SERIAL));

	for (wCount = 1;wCount <= MAXPORTS;++wCount)
	{
		wsprintf(szBuffer,_T("COM%u:"),wCount);
		if ((bAddWire = (_tcsncmp(szBuffer,szWireSetting,lstrlen(szBuffer)-1) == 0)))
			wSelectWire = wSelIndexWire;
		if ((bAddIr = (_tcsncmp(szBuffer,szIrSetting,lstrlen(szBuffer)-1) == 0)))
			wSelectIr = wSelIndexIr;

		// test if COM port is valid
		hComm = CreateFile(szBuffer,GENERIC_READ | GENERIC_WRITE,0,NULL,OPEN_EXISTING,0,NULL);
		if (hComm != INVALID_HANDLE_VALUE)
		{
			VERIFY(CloseHandle(hComm));
			bAddWire = bAddIr = TRUE;
		}

		_ASSERT(lstrlen(szBuffer) > 0);
		szBuffer[lstrlen(szBuffer)-1] = 0;	// remove last character (:)
		if (bAddWire)						// add item to combobox
		{
			SendDlgItemMessage(hDlg,IDC_WIRE,CB_ADDSTRING,0,(LPARAM) szBuffer);
			++wSelIndexWire;
		}
		if (bAddIr)							// add item to combobox
		{
			SendDlgItemMessage(hDlg,IDC_IR,CB_ADDSTRING,0,(LPARAM) szBuffer);
			++wSelIndexIr;
		}
	}

	// set cursors
	SendDlgItemMessage(hDlg,IDC_WIRE,CB_SETCURSEL,wSelectWire,0L);
	SendDlgItemMessage(hDlg,IDC_IR  ,CB_SETCURSEL,wSelectIr  ,0L);
	return;
}

static BOOL CALLBACK SettingsGeneralProc(HWND hDlg, UINT uMsg, DWORD wParam, LONG lParam)
{
	switch (uMsg)
	{
	case WM_INITDIALOG:
		// init speed checkbox
		SendDlgItemMessage(hDlg,IDC_REALSPEED,BM_SETCHECK,bRealSpeed,0);
		SendDlgItemMessage(hDlg,IDC_AUTOSAVE,BM_SETCHECK,bAutoSave,0);
		SendDlgItemMessage(hDlg,IDC_AUTOSAVEONEXIT,BM_SETCHECK,bAutoSaveOnExit,0);
		SendDlgItemMessage(hDlg,IDC_OBJECTLOADWARNING,BM_SETCHECK,bLoadObjectWarning,0);
		SendDlgItemMessage(hDlg,IDC_ALWAYSDISPLOG,BM_SETCHECK,bAlwaysDisplayLog,0);
		return TRUE;
	case WM_NOTIFY:
		switch (((LPNMHDR) lParam)->code)
		{
		case PSN_KILLACTIVE:
			// get speed checkbox value
			bRealSpeed = SendDlgItemMessage(hDlg,IDC_REALSPEED,BM_GETCHECK,0,0);
			bAutoSave = SendDlgItemMessage(hDlg,IDC_AUTOSAVE,BM_GETCHECK,0,0);
			bAutoSaveOnExit = SendDlgItemMessage(hDlg,IDC_AUTOSAVEONEXIT,BM_GETCHECK,0,0);
			bLoadObjectWarning = SendDlgItemMessage(hDlg,IDC_OBJECTLOADWARNING,BM_GETCHECK,0,0);
			bAlwaysDisplayLog = SendDlgItemMessage(hDlg,IDC_ALWAYSDISPLOG,BM_GETCHECK,0,0);
			SetSpeed(bRealSpeed);			// set speed
			return TRUE;
		}
		break;
	}
	return FALSE;
	UNREFERENCED_PARAMETER(lParam);
}

static BOOL CALLBACK SettingsMemoryProc(HWND hDlg, UINT uMsg, DWORD wParam, LONG lParam)
{
	LPCTSTR szActPort2Filename = _T("");

	BOOL bPort2CfgChange = FALSE;
	BOOL bPort2AttChange = FALSE;

	switch (uMsg)
	{
	case WM_INITDIALOG:
		// HP48SX/GX
		if (cCurrentRomType=='S' || cCurrentRomType=='G' || cCurrentRomType==0)
		{
			// init port1 enable checkbox
			SendDlgItemMessage(hDlg,IDC_PORT1EN,BM_SETCHECK,(Chipset.cards_status & PORT1_PRESENT) != 0,0);
			SendDlgItemMessage(hDlg,IDC_PORT1WR,BM_SETCHECK,(Chipset.cards_status & PORT1_WRITE) != 0,0);

			if (nArgc < 3)					// port2 filename from Emu48.ini file
			{
				szActPort2Filename = szPort2Filename;
			}
			else							// port2 filename given from command line
			{
				szActPort2Filename = ppArgv[2];
				EnableWindow(GetDlgItem(hDlg,IDC_PORT2),FALSE);
			}

			// init port2 shared and writeable checkbox and set port2 filename
			SendDlgItemMessage(hDlg,IDC_PORT2ISSHARED,BM_SETCHECK,bPort2IsShared,0);
			SendDlgItemMessage(hDlg,IDC_PORT2WR,BM_SETCHECK,IsFileWriteable(szActPort2Filename),0);
			SetDlgItemText(hDlg,IDC_PORT2,szActPort2Filename);
			if (nState == SM_INVALID)		// Invalid State
			{
				EnableWindow(GetDlgItem(hDlg,IDC_PORT1EN),FALSE);
				EnableWindow(GetDlgItem(hDlg,IDC_PORT1WR),FALSE);
			}
		}
		else								// HP38G/HP39G/HP40G/HP49G
		{
			EnableWindow(GetDlgItem(hDlg,IDC_PORT1EN),FALSE);
			EnableWindow(GetDlgItem(hDlg,IDC_PORT1WR),FALSE);
			EnableWindow(GetDlgItem(hDlg,IDC_PORT2ISSHARED),FALSE);
			EnableWindow(GetDlgItem(hDlg,IDC_PORT2WR),FALSE);
			EnableWindow(GetDlgItem(hDlg,IDC_PORT2),FALSE);
		}
		return TRUE;
	case WM_NOTIFY:
		switch (((LPNMHDR) lParam)->code)
		{
		case PSN_KILLACTIVE:
			if (Chipset.Port1Size && cCurrentRomType!='X')
			{
				UINT nOldState = SwitchToState(SM_SLEEP);
				// save old card status
				BYTE bCardsStatus = Chipset.cards_status;

				// port1 disabled?
				Chipset.cards_status &= ~(PORT1_PRESENT | PORT1_WRITE);
				if (SendDlgItemMessage(hDlg,IDC_PORT1EN,BM_GETCHECK,0,0))
				{
					Chipset.cards_status |= PORT1_PRESENT;
					if (SendDlgItemMessage(hDlg,IDC_PORT1WR,BM_GETCHECK,0,0))
						Chipset.cards_status |= PORT1_WRITE;
				}

				// changed card status in slot1?
				if (   ((bCardsStatus ^ Chipset.cards_status) & (PORT1_PRESENT | PORT1_WRITE)) != 0
					&& (Chipset.IORam[CARDCTL] & ECDT) != 0 && (Chipset.IORam[TIMER2_CTRL] & RUN) != 0
				   )
				{
					Chipset.HST |= MP;			// set Module Pulled
					IOBit(SRQ2,NINT,FALSE);		// set NINT to low
					Chipset.SoftInt = TRUE;		// set interrupt
					bInterrupt = TRUE;
				}
				Map(0x00,0xFF);
				SwitchToState(nOldState);
			}
			// HP48SX/GX port2 change settings detection
			if (cCurrentRomType=='S' || cCurrentRomType=='G' || cCurrentRomType==0)
			{
				TCHAR szFilename[MAX_PATH];
				BOOL  bOldPort2IsShared = bPort2IsShared;

				szActPort2Filename = (nArgc < 3) ? szPort2Filename : ppArgv[2];

				// shared port
				bPort2IsShared = SendDlgItemMessage(hDlg,IDC_PORT2ISSHARED,BM_GETCHECK,0,0);
				if (bPort2IsShared != bOldPort2IsShared)
				{
					bPort2CfgChange = TRUE;	// slot2 configuration changed
				}

				if (nArgc < 3)				// port2 filename from Emu48.ini file
				{
					// get current filename and notify difference
					GetDlgItemText(hDlg,IDC_PORT2,szFilename,ARRAYSIZEOF(szFilename));
					if (lstrcmp(szPort2Filename,szFilename) != 0)
					{
						_tcsncpy(szPort2Filename,szFilename,ARRAYSIZEOF(szPort2Filename));
						bPort2CfgChange = TRUE;	// slot2 configuration changed
					}
				}

				// R/W port
				if (   *szActPort2Filename != 0
					&& SendDlgItemMessage(hDlg,IDC_PORT2WR,BM_GETCHECK,0,0) != IsFileWriteable(szActPort2Filename))
				{
					bPort2AttChange = TRUE;	// slot2 file R/W attribute changed
					bPort2CfgChange = TRUE;	// slot2 configuration changed
				}
			}
			if (bPort2CfgChange)			// slot2 configuration changed
			{
				UINT nOldState = SwitchToState(SM_INVALID);

				UnmapPort2();				// unmap port2

				if (bPort2AttChange)		// slot2 R/W mode changed
				{
					DWORD dwFileAtt;

					dwFileAtt = GetFileAttributes(FullFilename(szActPort2Filename));
					if (dwFileAtt != 0xFFFFFFFF)
					{
						if (SendDlgItemMessage(hDlg,IDC_PORT2WR,BM_GETCHECK,0,0))
							dwFileAtt &= ~FILE_ATTRIBUTE_READONLY;
						else
							dwFileAtt |= FILE_ATTRIBUTE_READONLY;

						SetFileAttributes(FullFilename(szActPort2Filename),dwFileAtt);
					}
				}

				if (cCurrentRomType)		// ROM defined
				{
					MapPort2(szActPort2Filename);

					// port2 changed and card detection enabled
					if (   (bPort2AttChange || Chipset.wPort2Crc != wPort2Crc)
						&& (Chipset.IORam[CARDCTL] & ECDT) != 0 && (Chipset.IORam[TIMER2_CTRL] & RUN) != 0
					   )
					{
						Chipset.HST |= MP;		// set Module Pulled
						IOBit(SRQ2,NINT,FALSE);	// set NINT to low
						Chipset.SoftInt = TRUE;	// set interrupt
						bInterrupt = TRUE;
					}
					// save fingerprint of port2
					Chipset.wPort2Crc = wPort2Crc;
				}
				SwitchToState(nOldState);
			}
			return TRUE;
		}
		break;
	}
	return FALSE;
}

static BOOL CALLBACK SettingsPortProc(HWND hDlg, UINT uMsg, DWORD wParam, LONG lParam)
{
	switch (uMsg)
	{
	case WM_INITDIALOG:
		// set combobox parameter
		SetCommList(hDlg,szSerialWire,szSerialIr);
		if (bCommInit)						// disable when port open
		{
			EnableWindow(GetDlgItem(hDlg,IDC_WIRE),FALSE);
			EnableWindow(GetDlgItem(hDlg,IDC_IR),FALSE);
		}

		if (cCurrentRomType=='X')		// HP49G
		{
			SendDlgItemMessage(hDlg,IDC_IR,CB_RESETCONTENT,0,0);
			EnableWindow(GetDlgItem(hDlg,IDC_IR),FALSE);
		}
		return TRUE;
	case WM_NOTIFY:
		switch (((LPNMHDR) lParam)->code)
		{
		case PSN_KILLACTIVE:
			// set combobox parameter
			GetDlgItemText(hDlg,IDC_WIRE,szSerialWire,ARRAYSIZEOF(szSerialWire));
			if (cCurrentRomType!='X')		// HP49G Ir port is not connected
				GetDlgItemText(hDlg,IDC_IR,szSerialIr,ARRAYSIZEOF(szSerialIr));
			return TRUE;
		}
		break;
	}
	return FALSE;
}



//################
//#
//#    Save Helper
//#
//################

//
// UINT SaveChanges(BOOL bAuto);
// Return code :
// IDYES    File successfuly saved
// IDNO     File not saved
// IDCANCEL Cancel command
//
static UINT SaveChanges(BOOL bAuto)
{
	UINT uReply;

	if (bDocumentAvail == FALSE) return IDNO;

	if (bAuto)
		uReply = IDYES;
	else
	{
		UINT uStyle = bSaveDefConfirm ? 0 : MB_DEFBUTTON2;
		uReply = YesNoCancelMessage(_T("Do you want to save changes?"),uStyle);
	}

	if (uReply != IDYES) return uReply;

	if (szCurrentFilename[0] == 0)
	{ // Save As...
		if (GetSaveAsFilename())
		{
			if (SaveDocumentAs(szBufferFilename))
				return IDYES;
			else
				return IDCANCEL;
		}
		return IDNO;
	}

	SaveDocument();
	return IDYES;
}



//################
//#
//#    Message Handlers
//#
//################

//
// WM_CREATE
//
static LRESULT OnCreate(HWND hWindow)
{
	InitializeCriticalSection(&csGDILock);
	InitializeCriticalSection(&csKeyLock);
	InitializeCriticalSection(&csIOLock);
	InitializeCriticalSection(&csT1Lock);
	InitializeCriticalSection(&csT2Lock);
	InitializeCriticalSection(&csTxdLock);
	InitializeCriticalSection(&csRecvLock);
	InitializeCriticalSection(&csSlowLock);

	hWnd = hWindow;
	hWindowDC = GetDC(hWnd);
	return 0;
}

//
// WM_DESTROY
//
static LRESULT OnDestroy(HWND hWindow)
{
	SwitchToState(SM_RETURN);				// exit emulation thread
	if (hCmdBar) CommandBar_Destroy(hCmdBar);
	if (hCmdPopup) DestroyMenu(hCmdPopup);
	SetWindowTitle(NULL);					// free memory of title
	ReleaseDC(hWnd, hWindowDC);
	hCmdBar = NULL;
	hCmdPopup = NULL;
	hWindowDC = NULL;						// hWindowDC isn't valid any more
	hWnd = NULL;

	DeleteCriticalSection(&csGDILock);
	DeleteCriticalSection(&csKeyLock);
	DeleteCriticalSection(&csIOLock);
	DeleteCriticalSection(&csT1Lock);
	DeleteCriticalSection(&csT2Lock);
	DeleteCriticalSection(&csTxdLock);
	DeleteCriticalSection(&csRecvLock);
	DeleteCriticalSection(&csSlowLock);

	PostQuitMessage(0);						// exit message loop
	return 0;
	UNREFERENCED_PARAMETER(hWindow);
}

//
// WM_PAINT
//
static LRESULT OnPaint(HWND hWindow)
{
	PAINTSTRUCT Paint;
	HDC hPaintDC;
	DWORD dwScreenFlags;
	LPARAM lStackEnabled;

	if ((nFullScreen & MENUBAR_OFF) == 0)	// menu bar on
	{
		if (hCmdBar == NULL)				// switch menu bar on
		{
			SHMENUBARINFO mbi;

			if (hCmdPopup)					// deactivate popup menu first
			{
				DestroyMenu(hCmdPopup);
				hCmdPopup = NULL;
			}

			// create command bar
			ZeroMemory(&mbi,sizeof(mbi));
			// workaround for structure to be PPC2000 compatible
			mbi.cbSize     = offsetof(SHMENUBARINFO,clrBk);
			mbi.hwndParent = hWnd;
			mbi.nToolBarId = IDR_MENU;
			mbi.hInstRes   = hApp;
			if (SHCreateMenuBar(&mbi))
			{
				// workaround for WM5..6 VGA menu bar bug
				// create menu bar bitmap buttons manually
				VERIFY(CommandBar_AddBitmap(mbi.hwndMB,hApp,IDR_MENU,3,0,0) != -1);
				hCmdBar = mbi.hwndMB;
			}
		}

		// update stack menu bar buttons
		lStackEnabled = (   (nState == SM_RUN || nState == SM_SLEEP)
						 && StackCopyPasteEnabled())
					  ? MAKELONG(TBSTATE_ENABLED,0)
					  : MAKELONG(0,0);
		SendMessage(hCmdBar,TB_SETSTATE,ID_STACK_COPY,lStackEnabled);
		SendMessage(hCmdBar,TB_SETSTATE,ID_STACK_PASTE,lStackEnabled);
	}
	else									// menu bar off
	{
		if (hCmdPopup == NULL)				// switch popup menu on
		{
			if (hCmdBar)					// deactivate menu bar first
			{
				CommandBar_Destroy(hCmdBar);
				hCmdBar = NULL;
			}

			hCmdPopup = LoadMenu(hApp,MAKEINTRESOURCE(IDM_MENU));
		}
	}

	// screen settings
	dwScreenFlags =  ((nFullScreen & TOPBAR_OFF) != 0)
				  ?  (SHFS_HIDETASKBAR | SHFS_HIDESTARTICON)
				  :  (SHFS_SHOWTASKBAR | SHFS_SHOWSTARTICON);
	dwScreenFlags |= ((nFullScreen & MENUBAR_OFF) != 0)
				  ?  SHFS_HIDESIPBUTTON
				  :  SHFS_SHOWSIPBUTTON;

	// top bar off screen mode
	if ((dwScreenFlags & (SHFS_HIDETASKBAR | SHFS_HIDESTARTICON)) != 0)
	{
		// workaround for Windows Mobile 2003 (SE) devices
		SHFullScreen(hWindow, SHFS_HIDETASKBAR | SHFS_HIDESIPBUTTON | SHFS_HIDESTARTICON);
	}
	SHFullScreen(hWindow, dwScreenFlags);	// change client size

	// draw main window
	hPaintDC = BeginPaint(hWindow, &Paint);
	if (hMainDC != NULL)
	{
		RECT rcMainPaint;

		rcMainPaint = Paint.rcPaint;		// coordinates in source bitmap
		rcMainPaint.left   += nBackgroundX * nAppZoom;
		rcMainPaint.top    += nBackgroundY * nAppZoom;
		rcMainPaint.right  += nBackgroundX * nAppZoom;
		rcMainPaint.bottom += nBackgroundY * nAppZoom;

		EnterCriticalSection(&csGDILock);
		{
			UINT nLines = (Chipset.lcounter == 0) ? 64 : (Chipset.lcounter + 1);

			// redraw background bitmap
			BitBlt(hPaintDC, Paint.rcPaint.left, Paint.rcPaint.top,
				   Paint.rcPaint.right-Paint.rcPaint.left, Paint.rcPaint.bottom-Paint.rcPaint.top,
				   hMainDC, rcMainPaint.left, rcMainPaint.top,
				   SRCCOPY);

			_ASSERT(hLcdDC);				// LCD display already initialized

			if (nVertical > 0)				// landscape mode
			{
				// redraw inside diplay area?
				if (   rcMainPaint.right  >  (LONG) (nLcdX * nAppZoom)
					&& rcMainPaint.bottom >  (LONG) (nLcdY * nAppZoom)
					&& rcMainPaint.left   <= (LONG) ((nLcdX +  64 * nLcdZoom) * nAppZoom)
					&& rcMainPaint.top    <= (LONG) ((nLcdY + 131 * nLcdZoom) * nAppZoom))
				{
					// rotating 180 degree flag
					INT nRot180 = (nVertical > 1) ? -1 : 1;

					// main area
					StretchBlt(hPaintDC,
							   (nLcdX - nBackgroundX) * nAppZoom,
							   (nLcdY - nBackgroundY) * nAppZoom,
							   nRot180 * MulDiv(nLines,nLcdZoom,nLcdDiv) * nAppZoom,
							   nRot180 * MulDiv(131,nLcdZoom,nLcdDiv) * nAppZoom,
							   hLcdDC,
							   0, ((36*4)-131)-Chipset.boffset,
							   nLines, 131,
							   SRCCOPY);
					// menu area
					StretchBlt(hPaintDC,
						       (nLcdX - nBackgroundX + nRot180 * MulDiv(nLines,nLcdZoom,nLcdDiv)) * nAppZoom,
							   (nLcdY - nBackgroundY) * nAppZoom,
							   nRot180 * MulDiv((64-nLines),nLcdZoom,nLcdDiv) * nAppZoom,
							   nRot180 * MulDiv(131,nLcdZoom,nLcdDiv) * nAppZoom,
							   hLcdDC,
							   nLines, (36*4)-131,
							   64-nLines, 131,
							   SRCCOPY);
				}
			}
			else							// portrait mode
			{
				// redraw inside diplay area?
				if (   rcMainPaint.right  >  (LONG) (nLcdX * nAppZoom)
					&& rcMainPaint.bottom >  (LONG) (nLcdY * nAppZoom)
					&& rcMainPaint.left   <= (LONG) ((nLcdX + 131 * nLcdZoom) * nAppZoom)
					&& rcMainPaint.top    <= (LONG) ((nLcdY +  64 * nLcdZoom) * nAppZoom))
				{
					// redraw main display area
					StretchBlt(hPaintDC,
							   (nLcdX - nBackgroundX) * nAppZoom,
							   (nLcdY - nBackgroundY) * nAppZoom,
							   MulDiv(131,nLcdZoom,nLcdDiv) * nAppZoom,
							   MulDiv(nLines,nLcdZoom,nLcdDiv) * nAppZoom,
							   hLcdDC,
							   Chipset.boffset, 0,
							   131, nLines,
							   SRCCOPY);
					// menu area
					StretchBlt(hPaintDC,
							   (nLcdX - nBackgroundX) * nAppZoom,
							   (nLcdY - nBackgroundY + MulDiv(nLines,nLcdZoom,nLcdDiv)) * nAppZoom,
							   MulDiv(131,nLcdZoom,nLcdDiv) * nAppZoom,
							   MulDiv((64-nLines),nLcdZoom,nLcdDiv) * nAppZoom,
							   hLcdDC,
							   0, nLines,
							   131, 64-nLines,
							   SRCCOPY);
				}
			}
		}
		LeaveCriticalSection(&csGDILock);
		UpdateAnnunciators();
		RefreshButtons(&rcMainPaint);
	}
	EndPaint(hWindow, &Paint);
	return 0;
}

//
// ID_FILE_NEW
//
static LRESULT OnFileNew(VOID)
{
	if (bDocumentAvail)
	{
		SwitchToState(SM_INVALID);
		if (IDCANCEL == SaveChanges(bAutoSave))
			goto cancel;
	}
	if (NewDocument()) SetWindowTitle(_T("Untitled"));
cancel:
	if (pbyRom) SwitchToState(SM_RUN);
	return 0;
}

//
// ID_FILE_OPEN
//
static LRESULT OnFileOpen(VOID)
{
	if (bDocumentAvail)
	{
		SwitchToState(SM_INVALID);
		if (IDCANCEL == SaveChanges(bAutoSave))
			goto cancel;
	}
	if (GetOpenFilename())
	{
		if (OpenDocument(szBufferFilename))
			MruAdd(szBufferFilename);
	}
cancel:
	if (pbyRom) SwitchToState(SM_RUN);
	return 0;
}

//
// ID_FILE_MRU_FILE1
//
static LRESULT OnFileMruOpen(UINT wID)
{
	LPCTSTR lpszFilename;

	wID -= ID_FILE_MRU_FILE1;				// zero based MRU index
	lpszFilename = MruFilename(wID);		// full filename from MRU list
	if (lpszFilename == NULL) return 0;		// MRU slot not filled

	if (bDocumentAvail)
	{
		SwitchToState(SM_INVALID);
		if (IDCANCEL == SaveChanges(bAutoSave))
			goto cancel;
	}
	if (!OpenDocument(lpszFilename))		// document loading failed
	{
		MruRemove(wID);						// entry not valid any more
	}
	else
	{
		MruMoveTop(wID);					// move entry to top of MRU list
	}
cancel:
	if (pbyRom) SwitchToState(SM_RUN);
	return 0;
}

//
// ID_FILE_SAVE
//
static LRESULT OnFileSave(VOID)
{
	if (bDocumentAvail)
	{
		SwitchToState(SM_INVALID);
		SaveChanges(TRUE);
		SwitchToState(SM_RUN);
	}
	return 0;
}

//
// ID_FILE_SAVEAS
//
static LRESULT OnFileSaveAs(VOID)
{
	if (bDocumentAvail)
	{
		SwitchToState(SM_INVALID);
		if (GetSaveAsFilename())
		{
			if (SaveDocumentAs(szBufferFilename))
				MruAdd(szCurrentFilename);
		}
		SwitchToState(SM_RUN);
	}
	return 0;
}

//
// ID_FILE_CLOSE
//
static LRESULT OnFileClose(VOID)
{
	if (bDocumentAvail)
	{
		SwitchToState(SM_INVALID);
		if (SaveChanges(bAutoSave) != IDCANCEL)
		{
			ResetDocument();
			SetWindowTitle(NULL);
		}
		else
		{
			SwitchToState(SM_RUN);
		}
	}
	return 0;
}

//
// ID_FILE_EXIT
//
// WM_CLOSE
//
// WM_SYS_CLOSE
//
static LRESULT OnFileExit(VOID)
{
	SwitchToState(SM_INVALID);				// hold emulation thread
	if (SaveChanges(bAutoSaveOnExit) == IDCANCEL)
	{
		SwitchToState(SM_RUN);				// on cancel restart emulation thread
		return 0;
	}
	DestroyWindow(hWnd);
	return 0;
}

//
// ID_VIEW_RESET
//
static LRESULT OnViewReset(VOID)
{
	if (nState != SM_RUN) return 0;
	if (YesNoMessage(_T("Are you sure you want to press the Reset Button?"))==IDYES)
	{
		SwitchToState(SM_SLEEP);
		CpuReset();							// register setting after Cpu Reset
		SwitchToState(SM_RUN);
	}
	return 0;
}

//
// ID_VIEW_SETTINGS
//
static int CALLBACK PropSheetProc(HWND hDlg, UINT uMsg, LPARAM lParam)
{
	if (uMsg == PSCB_INITIALIZED)
	{
		// get tab control
		HWND hwndTabs = GetDlgItem(hDlg,0x3020);

		DWORD dwStyle = GetWindowLong(hwndTabs,GWL_STYLE);
		SetWindowLong(hwndTabs,GWL_STYLE,dwStyle | TCS_BOTTOM);
	}
	else if (uMsg == PSCB_GETVERSION)
		return COMCTL32_VERSION;

	return 0;
}

static LRESULT OnViewSettings(VOID)
{
	PROPSHEETPAGE psp[3];
	PROPSHEETHEADER psh;

	UINT nOldState = nState;

	if (nState == SM_RUN)					// currently running
		SwitchToState(SM_SLEEP);			// suspend emulation

	SHFullScreen(hWnd, SHFS_SHOWTASKBAR | SHFS_SHOWSIPBUTTON | SHFS_SHOWSTARTICON);

	psp[0].dwSize = sizeof(PROPSHEETPAGE);
	psp[0].dwFlags = PSP_DEFAULT;
	psp[0].hInstance = hApp;
	psp[0].pszTemplate = MAKEINTRESOURCE(IDD_SET_GENERAL);
	psp[0].hIcon = NULL;
	psp[0].pszTitle = NULL;
	psp[0].pfnDlgProc = (DLGPROC) SettingsGeneralProc;
	psp[0].lParam = 0;
	psp[0].pfnCallback = NULL;

	psp[1].dwSize = sizeof(PROPSHEETPAGE);
	psp[1].dwFlags = PSP_DEFAULT;
	psp[1].hInstance = hApp;
	psp[1].pszTemplate = MAKEINTRESOURCE(IDD_SET_PORT);
	psp[1].hIcon = NULL;
	psp[1].pszTitle = NULL;
	psp[1].pfnDlgProc = (DLGPROC) SettingsMemoryProc;
	psp[1].lParam = 0;
	psp[1].pfnCallback = NULL;

	psp[2].dwSize = sizeof(PROPSHEETPAGE);
	psp[2].dwFlags = PSP_DEFAULT;
	psp[2].hInstance = hApp;
	psp[2].pszTemplate = MAKEINTRESOURCE(IDD_SET_SERIAL);
	psp[2].hIcon = NULL;
	psp[2].pszTitle = NULL;
	psp[2].pfnDlgProc = (DLGPROC) SettingsPortProc;
	psp[2].lParam = 0;
	psp[2].pfnCallback = NULL;

	psh.dwSize = sizeof(PROPSHEETHEADER);
	psh.dwFlags = PSH_PROPSHEETPAGE | PSH_MAXIMIZE | PSH_USECALLBACK;
	psh.hwndParent = hWnd;
	psh.hInstance = hApp;
	psh.hIcon = NULL;
	psh.pszCaption = _T("Settings");
	psh.nPages = ARRAYSIZEOF(psp);
	psh.nStartPage = 0;
	psh.ppsp = (LPCPROPSHEETPAGE) &psp;
	psh.pfnCallback = PropSheetProc;

	if (PropertySheet(&psh) == -1)
		AbortMessage(_T("Settings Property Sheet Creation Error !"));

	WriteSettings();						// update INI file
	SwitchToState(nOldState);				// switch back to old state
	return 0;
}

//
// ID_VIEW_SCRIPT
//
static LRESULT OnViewScript(VOID)
{
	TCHAR szKmlFile[MAX_PATH];
	BOOL  bKMLChanged,bSucc;

	BYTE cType = cCurrentRomType;
	if (nState != SM_RUN)
	{
		InfoMessage(_T("You cannot change the KML script when Emu48 is not running.\n")
					_T("Use the File,New menu item to create a new calculator."));
		return 0;
	}
	SwitchToState(SM_INVALID);

	// make a copy of the current KML script file name
	_ASSERT(sizeof(szKmlFile) == sizeof(szCurrentKml));
	_tcsncpy(szKmlFile,szCurrentKml,ARRAYSIZEOF(szKmlFile));

	bKMLChanged = FALSE;					// KML script not changed
	bSucc = TRUE;							// KML script successful loaded

	do
	{
		if (!DisplayChooseKml(cType))		// quit with Cancel
		{
			if (!bKMLChanged)				// KML script not changed
				 break;						// exit loop with current loaded KML script

			// restore KML script file name
			_tcsncpy(szCurrentKml,szKmlFile,ARRAYSIZEOF(szCurrentKml));

			// try to restore old KML script
			if ((bSucc = InitKML(szCurrentKml,FALSE)))
				break;						// exit loop with success

			// restoring failed, save document
			if (IDCANCEL != SaveChanges(bAutoSave))
				break;						// exit loop with no success

			_ASSERT(bSucc == FALSE);		// for continuing loop
		}
		else								// quit with Ok
		{
			bKMLChanged = TRUE;				// KML script changed
			bSucc = InitKML(szCurrentKml,FALSE);
		}
	}
	while (!bSucc);							// retry if KML script is invalid

	if (bSucc)
	{
		if (Chipset.wRomCrc != wRomCrc)		// ROM changed
		{
			CpuReset();
			Chipset.Shutdn = FALSE;			// automatic restart

			Chipset.wRomCrc = wRomCrc;		// update current ROM fingerprint
		}
		if (pbyRom) SwitchToState(SM_RUN);	// continue emulation
	}
	else
	{
		ResetDocument();					// close document
		SetWindowTitle(NULL);
	}
	return 0;
}

//
// ID_BACKUP_SAVE
//
static LRESULT OnBackupSave(VOID)
{
	UINT nOldState;
	if (pbyRom == NULL) return 0;
	nOldState = SwitchToState(SM_INVALID);
	SaveBackup();
	SwitchToState(nOldState);
	return 0;
}

//
// ID_BACKUP_RESTORE
//
static LRESULT OnBackupRestore(VOID)
{
	SwitchToState(SM_INVALID);
	RestoreBackup();
	if (pbyRom) SwitchToState(SM_RUN);
	return 0;
}

//
// ID_BACKUP_DELETE
//
static LRESULT OnBackupDelete(VOID)
{
	ResetBackup();
	return 0;
}

static LRESULT OnObjectLoad(VOID)
{
	// calculator off, turn on
	if (!(Chipset.IORam[BITOFFSET]&DON))
	{
		KeyboardEvent(TRUE,0,0x8000);
		Sleep(dwWakeupDelay);
		KeyboardEvent(FALSE,0,0x8000);

		// wait for sleep mode
		while (Chipset.Shutdn == FALSE) Sleep(0);
	}

	if (nState != SM_RUN)
	{
		InfoMessage(_T("The emulator must be running to load an object."));
		goto cancel;
	}

	if (WaitForSleepState())				// wait for cpu SHUTDN then sleep state
	{
		InfoMessage(_T("The emulator is busy."));
		goto cancel;
	}

	_ASSERT(nState == SM_SLEEP);

	if (bLoadObjectWarning)
	{
		UINT uReply = YesNoCancelMessage(
			_T("Warning: Trying to load an object while the emulator is busy ")
			_T("will certainly result in a memory lost. Before loading an object ")
			_T("you should be sure that the calculator is in idle state. ")
			_T("Do you want to see this warning next time you try to load an object?\n"),0);
		switch (uReply)
		{
		case IDYES:
			break;
		case IDNO:
			bLoadObjectWarning = FALSE;
			break;
		case IDCANCEL:
			SwitchToState(SM_RUN);
			goto cancel;
		}
	}

	if (!GetLoadObjectFilename())
	{
		SwitchToState(SM_RUN);
		goto cancel;
	}

	if (!LoadObject(szBufferFilename))
	{
		SwitchToState(SM_RUN);
		goto cancel;
	}

	SwitchToState(SM_RUN);					// run state
	while (nState!=nNextState) Sleep(0);
	_ASSERT(nState == SM_RUN);
	KeyboardEvent(TRUE,0,0x8000);
	Sleep(dwWakeupDelay);
	KeyboardEvent(FALSE,0,0x8000);
	while (Chipset.Shutdn == FALSE) Sleep(0);

cancel:
	return 0;
}

//
// ID_OBJECT_SAVE
//
static LRESULT OnObjectSave(VOID)
{
	if (nState != SM_RUN)
	{
		InfoMessage(_T("The emulator must be running to save an object."));
		return 0;
	}

	if (WaitForSleepState())				// wait for cpu SHUTDN then sleep state
	{
		InfoMessage(_T("The emulator is busy."));
		return 0;
	}

	_ASSERT(nState == SM_SLEEP);

	if (GetSaveObjectFilename())
	{
		SaveObject(szBufferFilename);
	}

	SwitchToState(SM_RUN);
	return 0;
}

//
// ID_HELP_TOPICS
//
static LRESULT OnTopics(VOID)
{
	SHELLEXECUTEINFO info;
	ZeroMemory(&info,sizeof(info));
	info.cbSize = sizeof(info);
	info.hwnd = hWnd;
	info.lpVerb = _T("open");
	info.lpFile = FullFilename(_T("Emu48ppc.htm"));
	info.lpDirectory = _T("");;
	info.nShow = SW_SHOW;
	info.hInstApp = hApp;
	ShellExecuteEx(&info);
	return 0;
}

//
// ID_ABOUT
//
static BOOL CALLBACK About(HWND hDlg, UINT uMsg, DWORD wParam, LONG lParam)
{
	switch (uMsg)
	{
	case WM_INITDIALOG:
		SetDlgItemText(hDlg,IDC_VERSION,szNoTitle);
		SetDlgItemText(hDlg,IDC_LICENSE,szLicence);
		FULLSCREEN(hDlg,SHIDIF_DONEBUTTON);
		return TRUE;
	case WM_COMMAND:
		wParam = LOWORD(wParam);
		if ((wParam==IDOK)||(wParam==IDCANCEL))
		{
			EndDialog(hDlg, wParam);
			return TRUE;
		}
		break;
	}
	return FALSE;
	UNREFERENCED_PARAMETER(lParam);
}

static LRESULT OnAbout(VOID)
{
	if (DialogBox(hApp, MAKEINTRESOURCE(IDD_ABOUT), hWnd, (DLGPROC)About) == -1)
		AbortMessage(_T("About Dialog Box Creation Error!"));
	return 0;
}

static LRESULT OnPopupMenu(HMENU hMenu,UINT uPos)
{
	// disable stack loading items on HP38G, HP39/40G
	BOOL bStackEnable = StackCopyPasteEnabled();
	BOOL bRun         = nState == SM_RUN || nState == SM_SLEEP;

	UINT uStackEnable  = (bRun && bStackEnable)  ? MF_ENABLED : MF_GRAYED;
	UINT uRun          = bRun                    ? MF_ENABLED : MF_GRAYED;
	UINT uBackup       = bBackup                 ? MF_ENABLED : MF_GRAYED;

	if (hCmdPopup)							// popup menu activated
	{
		UINT uSubMenu[] = { ID_FILE, ID_EDIT, ID_VIEW, ID_TOOLS, ID_HELP };

		HMENU hRootMenu;
		INT i;

		hRootMenu = GetSubMenu(hCmdPopup,0); // get root menu handle
		if (hRootMenu == hMenu) return 0;	// this is the root menu

		uPos = 0;							// delete item position
		for (i = 0; i < ARRAYSIZEOF(uSubMenu); i++)
		{
			// is it a main menu item?
			if (GetSubMenu(hRootMenu,i) == hMenu)
			{
				uPos = uSubMenu[i];			// translate popup position to ID
				break;
			}
		}
	}

	switch (uPos)
	{
	case ID_FILE:
		EnableMenuItem(hMenu,ID_FILE_SAVE,(bRun && szCurrentFilename[0]) ? MF_ENABLED : MF_GRAYED);
		EnableMenuItem(hMenu,ID_FILE_SAVEAS,uRun);
		EnableMenuItem(hMenu,ID_FILE_CLOSE,uRun);
		MruUpdateMenu(hMenu);				// update MRU list
		break;
	case ID_EDIT:
		EnableMenuItem(hMenu,ID_OBJECT_LOAD,uStackEnable);
		EnableMenuItem(hMenu,ID_OBJECT_SAVE,uStackEnable);
		EnableMenuItem(hMenu,ID_STACK_COPY,uStackEnable);
		EnableMenuItem(hMenu,ID_STACK_PASTE,uStackEnable);
		EnableMenuItem(hMenu,ID_VIEW_RESET,uRun);
		EnableMenuItem(hMenu,ID_BACKUP_SAVE,uRun);
		EnableMenuItem(hMenu,ID_BACKUP_RESTORE,uBackup);
		EnableMenuItem(hMenu,ID_BACKUP_DELETE,uBackup);
		break;
	case ID_VIEW:
		EnableMenuItem(hMenu,ID_VIEW_SCRIPT,uRun);
		break;
	case ID_TOOLS:
		EnableMenuItem(hMenu,ID_TOOL_MACRO_RECORD,(bRun && nMacroState == MACRO_OFF) ? MF_ENABLED : MF_GRAYED);
		EnableMenuItem(hMenu,ID_TOOL_MACRO_PLAY,(bRun && nMacroState == MACRO_OFF) ? MF_ENABLED : MF_GRAYED);
		EnableMenuItem(hMenu,ID_TOOL_MACRO_STOP,(bRun && nMacroState != MACRO_OFF) ? MF_ENABLED : MF_GRAYED);
		break;
	}
	return 0;
}

static LRESULT OnLButtonDown(UINT nFlags, WORD x, WORD y)
{
	if (hCmdPopup && !IsButtonArea(x,y))	// popup menu and outside virtual button area
	{
		SHRGINFO shrg;

		shrg.cbSize = sizeof(shrg);
		shrg.hwndClient = hWnd;
		shrg.ptDown.x = x;
		shrg.ptDown.y = y;
		shrg.dwFlags = SHRG_RETURNCMD;

		if (SHRecognizeGesture(&shrg) == GN_CONTEXTMENU)
		{
			TrackPopupMenuEx(GetSubMenu(hCmdPopup,0),TPM_LEFTALIGN,x,y,hWnd,NULL);
			return 0;
		}
	}

	if (nMacroState == MACRO_PLAY) return 0; // playing macro
	if (nState == SM_RUN) MouseButtonDownAt(nFlags, x,y);
	return 0;
}

static LRESULT OnLButtonUp(UINT nFlags, WORD x, WORD y)
{
	if (nMacroState == MACRO_PLAY) return 0; // playing macro
	if (nState == SM_RUN) MouseButtonUpAt(nFlags, x,y);
	return 0;
}

static LRESULT OnMouseMove(UINT nFlags, WORD x, WORD y)
{
	if (nMacroState == MACRO_PLAY) return 0; // playing macro
	if (nState == SM_RUN) MouseMovesTo(nFlags, x,y);
	return 0;
}

static LRESULT OnKeyDown(int nVirtKey, DWORD lKeyData)
{
	if (nMacroState == MACRO_PLAY) return 0; // playing macro
	// call RunKey() only once (suppress autorepeat feature)
	if (nState == SM_RUN && (lKeyData & 0x40000000) == 0)
		RunKey((BYTE)nVirtKey, TRUE);
	return 0;
}

static LRESULT OnKeyUp(int nVirtKey, DWORD lKeyData)
{
	if (nMacroState == MACRO_PLAY) return 0; // playing macro
	if (nState == SM_RUN) RunKey((BYTE)nVirtKey, FALSE);
	return 0;
	UNREFERENCED_PARAMETER(lKeyData);
}

LRESULT CALLBACK MainWndProc(HWND hWindow, UINT uMsg, WPARAM wParam, LPARAM lParam)
{
	switch (uMsg)
	{
	case WM_CREATE:     return OnCreate(hWindow);
	case WM_DESTROY:    return OnDestroy(hWindow);
	case WM_PAINT:      return OnPaint(hWindow);
	case WM_CLOSE:      return OnFileExit();
	case WM_ACTIVATE:
		if (LOWORD(wParam)==WA_INACTIVE) break;
	case WM_QUERYNEWPALETTE:
		if (hPalette)
		{
			SelectPalette(hWindowDC, hPalette, FALSE);
			if (RealizePalette(hWindowDC))
			{
				InvalidateRect(hWindow,NULL,TRUE);
				return TRUE;
			}
		}
		return FALSE;
	case WM_PALETTECHANGED:
		if ((HWND)wParam == hWindow) break;
		if (hPalette)
		{
			SelectPalette(hWindowDC, hPalette, FALSE);
			if (RealizePalette(hWindowDC))
			{
				// UpdateColors(hWindowDC);
				InvalidateRect (hWnd, (LPRECT) (NULL), 1);
			}
		}
		return FALSE;
	case WM_COMMAND:
		switch (LOWORD(wParam))
		{
		case ID_FILE_NEW:            return OnFileNew();
		case ID_FILE_OPEN:           return OnFileOpen();
		case ID_FILE_SAVE:           return OnFileSave();
		case ID_FILE_SAVEAS:         return OnFileSaveAs();
		case ID_FILE_CLOSE:          return OnFileClose();
		case ID_FILE_EXIT:           return OnFileExit();
		case ID_STACK_COPY:          return OnStackCopy();
		case ID_STACK_PASTE:         return OnStackPaste();
		case ID_VIEW_RESET:          return OnViewReset();
		case ID_VIEW_SETTINGS:       return OnViewSettings();
		case ID_VIEW_SCRIPT:         return OnViewScript();
		case ID_BACKUP_SAVE:         return OnBackupSave();
		case ID_BACKUP_RESTORE:      return OnBackupRestore();
		case ID_BACKUP_DELETE:       return OnBackupDelete();
		case ID_OBJECT_LOAD:         return OnObjectLoad();
		case ID_OBJECT_SAVE:         return OnObjectSave();
		case ID_TOOL_MACRO_RECORD:   return OnToolMacroNew();
		case ID_TOOL_MACRO_PLAY:     return OnToolMacroPlay();
		case ID_TOOL_MACRO_STOP:     return OnToolMacroStop();
		case ID_TOOL_MACRO_SETTINGS: return OnToolMacroSettings();
		case ID_HELP_TOPICS:         return OnTopics();
		case ID_ABOUT:               return OnAbout();
		}
		// check if command ID belongs to MRU file area
		if (   (LOWORD(wParam) >= ID_FILE_MRU_FILE1)
			&& (LOWORD(wParam) <  ID_FILE_MRU_FILE1 + MruEntries()))
			return OnFileMruOpen(LOWORD(wParam));
		break;
	case WM_SYSCOMMAND:
		switch (wParam & 0xFFF0)
		{
		case SC_CLOSE: return OnFileExit();
		}
		break;
	case WM_INITMENUPOPUP: return OnPopupMenu((HMENU)wParam, LOWORD(lParam));
	case WM_RBUTTONDOWN:
	case WM_LBUTTONDOWN:   return OnLButtonDown(wParam, LOWORD(lParam), HIWORD(lParam));
	case WM_LBUTTONUP:     return OnLButtonUp(wParam, LOWORD(lParam), HIWORD(lParam));
	case WM_MOUSEMOVE:     return OnMouseMove(wParam, LOWORD(lParam), HIWORD(lParam));
	case WM_KEYUP:         return OnKeyUp((int)wParam, lParam);
	case WM_KEYDOWN:       return OnKeyDown((int)wParam, lParam);
	}
	return DefWindowProc(hWindow, uMsg, wParam, lParam);
}

int WINAPI WinMain(HINSTANCE hInst, HINSTANCE hPrevInst, LPTSTR lpCmdLine, int nCmdShow)
{
	MSG msg;
	WNDCLASS wc;
	RECT rc;
	DWORD dwThreadId;

	hApp = hInst;
	nArgc = __argc;						// no. of command line arguments
	ppArgv = (LPCTSTR*) __argv;			// command line arguments

	// running an instance of me?
	if ((hWnd = FindWindow(_T("CEmu48"),NULL)) != NULL)
	{
		// switch to it with hack putting a minimized window to the foreground
		SetForegroundWindow((HWND)(((DWORD)hWnd) | 0x01));
		return FALSE;					// quit
	}

	SHInitExtraControls();

	if (!QueryPerformanceFrequency(&lFreq))	// init high resolution counter
	{
		AbortMessage(
			_T("No high resolution timer available.\n")
			_T("This application will now terminate."));
		return FALSE;
	}
	QueryPerformanceCounter(&lAppStart);

	memset(&wc,0,sizeof(WNDCLASS));
	wc.lpfnWndProc = (WNDPROC)MainWndProc;
	wc.hInstance = hInst;
	wc.hIcon = LoadIcon(hInst, MAKEINTRESOURCE(IDI_EMU48));
	wc.hbrBackground = (HBRUSH)GetStockObject(WHITE_BRUSH);
	wc.lpszClassName = _T("CEmu48");

	if (!RegisterClass(&wc))
	{
		AbortMessage(
			_T("CEmu48 class registration failed.\n")
			_T("This application will now terminate."));
		return FALSE;
	}

	// Create window
	hWnd = CreateWindow(_T("CEmu48"), _T("Emu48"),
		WS_VISIBLE,
		CW_USEDEFAULT, CW_USEDEFAULT,
		CW_USEDEFAULT,CW_USEDEFAULT,
		NULL,NULL,hApp,NULL
		);

	if (hWnd == NULL)
	{
		AbortMessage(_T("Window creation failed."));
		return FALSE;
	}

	GetWindowRect(hWnd, &rc);				// get current size of top menu
	lrcTop = rc.top;

	// initialization
	szCurrentKml[0] = 0;					// no KML file selected
	ReadSettings();
	MruInit(4);								// init MRU entries

	// create auto event handle
	hEventShutdn = CreateEvent(NULL,FALSE,FALSE,NULL);
	if (hEventShutdn == NULL)
	{
		AbortMessage(_T("Event creation failed."));
		DestroyWindow(hWnd);
		return FALSE;
	}

	nState     = SM_RUN;					// init state must be <> nNextState
	nNextState = SM_INVALID;				// go into invalid state
	hThread = CreateThread(NULL, 0, (LPTHREAD_START_ROUTINE)&WorkerThread, NULL, 0, &dwThreadId);
	if (hThread == NULL)
	{
		CloseHandle(hEventShutdn);			// close event handle
		AbortMessage(_T("Thread creation failed."));
		DestroyWindow(hWnd);
		return FALSE;
	}
	while (nState!=nNextState) Sleep(0);	// wait for thread initialized

	SoundOpen(uWaveDevId);					// open waveform-audio output device

	_ASSERT(hWnd != NULL);
	_ASSERT(hWindowDC != NULL);

	if (nArgc >= 2)							// use decoded parameter line
		_tcsncpy(szBufferFilename,ppArgv[1],ARRAYSIZEOF(szBufferFilename));
	else									// use last document setting
		ReadLastDocument(szBufferFilename, ARRAYSIZEOF(szBufferFilename));

	if (szBufferFilename[0])				// given default document
	{
		TCHAR szTemp[MAX_PATH+8] = _T("Loading ");

		// remove path from title
		LPCTSTR szName = _tcsrchr(szBufferFilename,_T('\\'));
		lstrcat(szTemp, (szName != NULL) ? (szName + 1) : szBufferFilename);

		SetWindowTitle(szTemp);
		if (OpenDocument(szBufferFilename))
		{
			MruAdd(szCurrentFilename);
			ShowWindow(hWnd,nCmdShow);
			goto start;
		}
	}

	SetWindowTitle(_T("New Document"));
	ShowWindow(hWnd,nCmdShow);				// show emulator menu

	// no default document, ask for new one
	if (NewDocument()) SetWindowTitle(_T("Untitled"));

start:
	if (bStartupBackup) SaveBackup();		// make a RAM backup at startup
	if (pbyRom) SwitchToState(SM_RUN);

	while (GetMessage(&msg, NULL, 0, 0))
	{
		TranslateMessage(&msg);
		DispatchMessage(&msg);
	}

	SoundClose();							// close waveform-audio output device

	WriteLastDocument(szCurrentFilename);	// save last document setting
	WriteSettings();						// save emulation settings

	CloseHandle(hThread);					// close thread handle
	CloseHandle(hEventShutdn);				// close event handle
	_ASSERT(nState == SM_RETURN);			// emulation thread down?
	ResetDocument();
	ResetBackup();
	MruCleanup();
	_ASSERT(pbyRom == NULL);				// rom file unmapped
	_ASSERT(pKml == NULL);					// KML script not closed
	_ASSERT(szTitle == NULL);				// freed allocated memory
	_ASSERT(hPalette == NULL);				// freed resource memory

	return msg.wParam;
	UNREFERENCED_PARAMETER(lpCmdLine);
	UNREFERENCED_PARAMETER(hPrevInst);
}
